﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using WDC.Utility;

namespace WDC
{
    public partial class frmViewMaster : Form
    {
        DbConnection dbCon = null;
        public frmViewMaster()
        {
            dbCon = new DbConnection();
            InitializeComponent();
        }

        private void frmViewMaster_Load(object sender, EventArgs e)
        {

            dgItemMaster.DataSource = dbCon.FillItemMasterGrid();
            datagridStyleSheet();
        }

        private void datagridStyleSheet()
        {
            DataGridTableStyle ts = new DataGridTableStyle();
            ts.MappingName = "Table";

            DataGridTextBoxColumn column1 = new DataGridTextBoxColumn();
            column1.HeaderText = "Item Name";
            column1.MappingName = "item_name";
            column1.Width = 120;
            ts.GridColumnStyles.Add(column1);

            DataGridTextBoxColumn column2 = new DataGridTextBoxColumn();
            column2.HeaderText = "Item Code";
            column2.MappingName = "item_no";
            column2.Width = 120;
            ts.GridColumnStyles.Add(column2);

            DataGridTextBoxColumn column3 = new DataGridTextBoxColumn();
            column3.HeaderText = "Description";
            column3.MappingName = "description";
            column3.Width = 280;
            ts.GridColumnStyles.Add(column3);

            this.dgItemMaster.TableStyles.Add(ts);
        }

        private void btn_click_Click(object sender, EventArgs e)
        {
            frmChangeSetting frmShow = new frmChangeSetting();
            frmShow.Show();
            this.Hide();
        }

      
    }
}