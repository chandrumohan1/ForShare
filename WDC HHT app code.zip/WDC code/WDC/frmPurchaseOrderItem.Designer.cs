﻿namespace WDC
{
    partial class frmPurchaseOrderItem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.dgPurchaseOrderItem = new System.Windows.Forms.DataGrid();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_pass = new System.Windows.Forms.Button();
            this.btn_back = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lblPoNo = new System.Windows.Forms.Label();
            this.txtRemarks = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // dgPurchaseOrderItem
            // 
            this.dgPurchaseOrderItem.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.dgPurchaseOrderItem.GridLineColor = System.Drawing.SystemColors.ControlDarkDark;
            this.dgPurchaseOrderItem.Location = new System.Drawing.Point(0, 47);
            this.dgPurchaseOrderItem.Name = "dgPurchaseOrderItem";
            this.dgPurchaseOrderItem.Size = new System.Drawing.Size(240, 151);
            this.dgPurchaseOrderItem.TabIndex = 0;
            this.dgPurchaseOrderItem.DoubleClick += new System.EventHandler(this.dgPurchaseOrderItem_DoubleClick);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.DarkRed;
            this.label1.Location = new System.Drawing.Point(71, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 20);
            this.label1.Text = "Item Details";
            // 
            // btn_pass
            // 
            this.btn_pass.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btn_pass.Enabled = false;
            this.btn_pass.ForeColor = System.Drawing.Color.Black;
            this.btn_pass.Location = new System.Drawing.Point(85, 246);
            this.btn_pass.Name = "btn_pass";
            this.btn_pass.Size = new System.Drawing.Size(59, 20);
            this.btn_pass.TabIndex = 1;
            this.btn_pass.Text = "Pass";
            this.btn_pass.Click += new System.EventHandler(this.btn_pass_Click);
            // 
            // btn_back
            // 
            this.btn_back.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btn_back.ForeColor = System.Drawing.Color.Black;
            this.btn_back.Location = new System.Drawing.Point(162, 246);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(59, 20);
            this.btn_back.TabIndex = 3;
            this.btn_back.Text = "Back";
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(14, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(141, 20);
            this.label2.Text = "PO No -";
            // 
            // lblPoNo
            // 
            this.lblPoNo.Location = new System.Drawing.Point(71, 4);
            this.lblPoNo.Name = "lblPoNo";
            this.lblPoNo.Size = new System.Drawing.Size(92, 20);
            this.lblPoNo.Text = "N/A";
            // 
            // txtRemarks
            // 
            this.txtRemarks.Location = new System.Drawing.Point(71, 205);
            this.txtRemarks.Multiline = true;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.Size = new System.Drawing.Size(166, 36);
            this.txtRemarks.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(4, 219);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 20);
            this.label3.Text = "Remarks";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.MediumAquamarine;
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(14, 246);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(59, 20);
            this.button1.TabIndex = 11;
            this.button1.Text = "Fail";
            this.button1.Click += new System.EventHandler(this.btn_fail_Click);
            // 
            // frmPurchaseOrderItem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtRemarks);
            this.Controls.Add(this.lblPoNo);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btn_back);
            this.Controls.Add(this.btn_pass);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgPurchaseOrderItem);
            this.Menu = this.mainMenu1;
            this.Name = "frmPurchaseOrderItem";
            this.Text = " Purchase Order Items";
            this.Load += new System.EventHandler(this.frmPurchaseOrderItem_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGrid dgPurchaseOrderItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_pass;
        private System.Windows.Forms.Button btn_back;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblPoNo;
        private System.Windows.Forms.TextBox txtRemarks;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
    }
}