﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using WDC.Utility;

namespace WDC
{
    public partial class frmSynSummary : Form
    {
        WDCApiFunction oWDCApi = null;
        DataTable dtPO = new DataTable("POSyncHistory");
        DataTable dtSO = new DataTable("SOSyncHistory");
        DataTable dtStock = new DataTable("StockSyncHistory");
        DbConnection oDbConnection = null;
        public frmSynSummary()
        {
            oWDCApi = new WDCApiFunction();
            oDbConnection = new DbConnection();
            getBindPOTable();
            InitializeComponent();
        }

        public void getBindPOTable()
        {
            dtPO.Columns.Add("S.No", typeof(string));
            dtPO.Columns.Add("PO", typeof(string));
            dtPO.Columns.Add("Status", typeof(string));
            dtPO.Columns.Add("Message", typeof(string));
            dtPO.Columns["S.No"].AutoIncrement = true;
            dtPO.Columns["S.No"].AutoIncrementStep = 1;
            dtPO.Columns["S.No"].AutoIncrementSeed = 1;

            dtSO.Columns.Add("S.No", typeof(string));
            dtSO.Columns.Add("SO", typeof(string));
            dtSO.Columns.Add("Status", typeof(string));
            dtSO.Columns.Add("Message", typeof(string));
            dtSO.Columns["S.No"].AutoIncrement = true;
            dtSO.Columns["S.No"].AutoIncrementStep = 1;
            dtSO.Columns["S.No"].AutoIncrementSeed = 1;

            dtStock.Columns.Add("S.No", typeof(string));
            dtStock.Columns.Add("Stock", typeof(string));
            dtStock.Columns.Add("Status", typeof(string));
            dtStock.Columns.Add("Message", typeof(string));
            dtStock.Columns["S.No"].AutoIncrement = true;
            dtStock.Columns["S.No"].AutoIncrementStep = 1;
            dtStock.Columns["S.No"].AutoIncrementSeed = 1;
        }

        private void frmSynSummary_Load(object sender, EventArgs e)
        {
            BindPoDetils();
            BindSoDetils();
            BindStockDetils();
            string message = "Total " + CommonFunction.poCount + " PO Received \n Total " + CommonFunction.soCount + " SO Received \n Total  " + CommonFunction.stockCount + " Take Stock Received";
            lblMessage.Text = message;
        }

        public void BindPoDetils()
        {
            var getList = WDCApiFunction.listApiPORet.ToList();
            foreach (var data in getList)
            {
                //string OrderNo = "";
                //int getId = Convert.ToInt32(data.PO_ID);
                //var getOrderNo = DbConnection.listPoName.Where(a => a.id == getId).FirstOrDefault();
                //if (getOrderNo != null)
                //    OrderNo = getOrderNo.OrderNo;

                dtPO.Rows.Add(null, data.PO_Number, data.Status, data.Message);              
            }
            dgPoSyncDetails.DataSource = dtPO;
            
        }
        public void BindSoDetils()
        {
            var getList = WDCApiFunction.listApiSORet.ToList();
            foreach (var data in getList)
            {
                //string OrderNo = "";
                //int getId = Convert.ToInt32(data.SO_ID);
                //var getOrderNo = DbConnection.listSoName.Where(a => a.id == getId).FirstOrDefault();
                //if (getOrderNo != null)
                //    OrderNo = getOrderNo.OrderNo;

                dtSO.Rows.Add(null, data.SO_Number, data.Status, data.Message);

            }
            dgSoSyncDetails.DataSource = dtSO;

        }
        public void BindStockDetils()
        {
            var getList = WDCApiFunction.listApiStockRet.ToList();
            foreach (var data in getList)
            {
                //string StockName = "";
                //int getId = Convert.ToInt32(data.Stock_id);
                //var  getStock = DbConnection.listStockName.Where(a => a.id == getId).FirstOrDefault();
                //if (getStock != null)
                //    StockName = getStock.StockName;
                dtStock.Rows.Add(null, data.Sheet_Name, data.Status, data.Message);

            }
            dgStockSyncDetails.DataSource = dtStock;

        }
    }
}