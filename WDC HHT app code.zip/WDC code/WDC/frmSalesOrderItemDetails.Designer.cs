﻿namespace WDC
{
    partial class frmSalesOrderItemDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.lblOrderQuant = new System.Windows.Forms.Label();
            this.lblSelectPO = new System.Windows.Forms.Label();
            this.mainMenu2 = new System.Windows.Forms.MainMenu();
            this.btn_ok = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblSO = new System.Windows.Forms.Label();
            this.lblLocation = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dgScanDetails = new System.Windows.Forms.DataGrid();
            this.btndeleterow = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.button2 = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblOrderQuant
            // 
            this.lblOrderQuant.Location = new System.Drawing.Point(139, 101);
            this.lblOrderQuant.Name = "lblOrderQuant";
            this.lblOrderQuant.Size = new System.Drawing.Size(72, 20);
            this.lblOrderQuant.Text = "NA";
            // 
            // lblSelectPO
            // 
            this.lblSelectPO.Location = new System.Drawing.Point(139, -33);
            this.lblSelectPO.Name = "lblSelectPO";
            this.lblSelectPO.Size = new System.Drawing.Size(72, 20);
            this.lblSelectPO.Text = "NA";
            // 
            // btn_ok
            // 
            this.btn_ok.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btn_ok.Location = new System.Drawing.Point(134, 301);
            this.btn_ok.Name = "btn_ok";
            this.btn_ok.Size = new System.Drawing.Size(72, 34);
            this.btn_ok.TabIndex = 57;
            this.btn_ok.Text = "Save";
            this.btn_ok.Click += new System.EventHandler(this.btn_ok_click);
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(15, 99);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 20);
            this.label4.Text = "Order Qunatity";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(14, -33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 20);
            this.label1.Text = "Select PO";
            // 
            // lblSO
            // 
            this.lblSO.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.lblSO.Location = new System.Drawing.Point(14, 14);
            this.lblSO.Name = "lblSO";
            this.lblSO.Size = new System.Drawing.Size(99, 20);
            this.lblSO.Text = "SO";
            // 
            // lblLocation
            // 
            this.lblLocation.Location = new System.Drawing.Point(15, 70);
            this.lblLocation.Name = "lblLocation";
            this.lblLocation.Size = new System.Drawing.Size(191, 20);
            this.lblLocation.Text = "NA";
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(15, 47);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(99, 20);
            this.label8.Text = "Location";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.None;
            this.tabControl1.Location = new System.Drawing.Point(3, 129);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(221, 166);
            this.tabControl1.TabIndex = 91;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Location = new System.Drawing.Point(0, 0);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(221, 143);
            this.tabPage1.Text = "Add";
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(215, 137);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.dgScanDetails);
            this.tabPage2.Controls.Add(this.btndeleterow);
            this.tabPage2.Location = new System.Drawing.Point(0, 0);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(221, 143);
            this.tabPage2.Text = "View";
            // 
            // dgScanDetails
            // 
            this.dgScanDetails.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.dgScanDetails.Location = new System.Drawing.Point(0, 7);
            this.dgScanDetails.Name = "dgScanDetails";
            this.dgScanDetails.Size = new System.Drawing.Size(221, 110);
            this.dgScanDetails.TabIndex = 89;
            // 
            // btndeleterow
            // 
            this.btndeleterow.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btndeleterow.ForeColor = System.Drawing.Color.Black;
            this.btndeleterow.Location = new System.Drawing.Point(41, 123);
            this.btndeleterow.Name = "btndeleterow";
            this.btndeleterow.Size = new System.Drawing.Size(137, 20);
            this.btndeleterow.TabIndex = 88;
            this.btndeleterow.Text = "Delete selected row";
            this.btndeleterow.Visible = false;
            this.btndeleterow.Click += new System.EventHandler(this.btn_delete_row_click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(173, 10);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(49, 29);
            this.pictureBox2.Click += new System.EventHandler(this.btn_description_click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.MediumAquamarine;
            this.button2.Location = new System.Drawing.Point(18, 300);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(72, 34);
            this.button2.TabIndex = 99;
            this.button2.Text = "Back";
            this.button2.Click += new System.EventHandler(this.btn_close_click);
            // 
            // frmSalesOrderItemDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.lblLocation);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.lblSO);
            this.Controls.Add(this.lblOrderQuant);
            this.Controls.Add(this.lblSelectPO);
            this.Controls.Add(this.btn_ok);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Menu = this.mainMenu1;
            this.Name = "frmSalesOrderItemDetails";
            this.Text = " Sale Order Item Details";
            this.Load += new System.EventHandler(this.frmSalesOrderItemDetails_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblOrderQuant;
        private System.Windows.Forms.Label lblSelectPO;
        private System.Windows.Forms.MainMenu mainMenu2;
        private System.Windows.Forms.Button btn_ok;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblSO;
        private System.Windows.Forms.Label lblLocation;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btndeleterow;
        private System.Windows.Forms.DataGrid dgScanDetails;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button button2;
    }
}