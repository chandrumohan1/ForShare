﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlServerCe;
using WDC.Utility;

namespace WDC
{
    public partial class frmSettingDetails : Form
    {
        static public WDCApiFunction OwdcApi = null;
        static public DbConnection oDbConnection = null;
        public frmSettingDetails()
        {
            OwdcApi = new WDCApiFunction();
            oDbConnection = new DbConnection();          
            InitializeComponent();
        }

        private void frmSettingDetails_Load(object sender, EventArgs e)
        {
            pcblogo.Image = Resource1.IBS_Logo;

        }

        private void btnReceive_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                if (CommonFunction.login_id > 0)
                {
                    //OwdcApi.callPurchaseOrderApi(CommonFunction.login_id);
                    frmPurchaseOrder OfrmPurchaseOrder = new frmPurchaseOrder();
                    OfrmPurchaseOrder.Show();
                }
                else
                {
                    MessageBox.Show("Some error occured !!!");
                }
                
                Cursor.Current = Cursors.Default;

               

            }
            catch (Exception ex)
            {

                throw;
            }        
        }

        private void btndeliver_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                if (CommonFunction.login_id > 0)
                {
                   // OwdcApi.callSalesOrderApi(CommonFunction.login_id);
                    frmSalesOrder OfrmSalesOrder = new frmSalesOrder();
                    OfrmSalesOrder.Show();
                }
                else
                {
                    MessageBox.Show("Some error occured !!!");
                }

                Cursor.Current = Cursors.Default;
            }
            catch (Exception ex)
            {

                throw;
            }    
        }

        private void btn_stock_click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                if (CommonFunction.login_id > 0)
                {
                   // OwdcApi.callStockApi(CommonFunction.login_id);
                    frmStockCount ofrmStockCount = new frmStockCount();
                    ofrmStockCount.Show();
                }
                else
                {
                    MessageBox.Show("Some error occured !!!");
                }

                Cursor.Current = Cursors.Default;
            }
            catch (Exception ex)
            {

                throw;
            }    
        }

        private void btnSetting_Click(object sender, EventArgs e)
        {
            frmChangeSetting oFrmShow = new frmChangeSetting();
            oFrmShow.Show();
        }

        private void btnSync_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            //post api
            //oDbConnection.PostUserDetailsDataToSetver(); //sharad commenting
            bool ret1;
            bool ret = oDbConnection.PostPurchaseOrdersDataToSetver(out ret1);
            if (ret)
            {
                bool is_check =  oDbConnection.PostSalesOrdersDataToSetver();
                bool is_check1 = oDbConnection.PostStockDataToSetver();

                //call api
                OwdcApi.callGetStockDetailsApiForItemList();
                OwdcApi.callPurchaseOrderApi(CommonFunction.login_id);
                OwdcApi.callSalesOrderApi(CommonFunction.login_id);
                OwdcApi.callStockSheetApi(CommonFunction.login_id);
                //call master data with item list
                if (ret1 || is_check || is_check1)
                {
                    frmSynSummary ofrmSynSummary = new frmSynSummary();
                    ofrmSynSummary.Show();
                }
                else
                {
                    string message = "Total " + CommonFunction.poCount + " PO Received. \n Total " + CommonFunction.soCount + " SO Received. \n Total  " + CommonFunction.stockCount + " Take Stock Received.";
                   // MessageBox.Show("Sync Done!!", "Message");
                    MessageBox.Show(message, "Sync Message", MessageBoxButtons.OK, MessageBoxIcon.None, MessageBoxDefaultButton.Button1);
                }
               

               
            }
            else
            {
                MessageBox.Show("You seem to be offline. Please check", "Error");
            }
            Cursor.Current = Cursors.Default;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

       

      

       

       
    }
}