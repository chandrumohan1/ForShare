﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using WDC.Utility;
using System.Data.SqlServerCe;

namespace WDC
{
    public partial class frmLoginScreen : Form
    {
        public string conSTR = "Data Source=" +
           (System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase)) +
           "\\dbWDC.sdf;Persist Security Info=False";
        SqlCeConnection dbCon = null;
        SqlCeCommand dbCmd = null;
        CommonFunction oCommonfunction = null;
        public frmLoginScreen()
        {
            dbCon = new SqlCeConnection(conSTR);
            oCommonfunction = new CommonFunction();           
            InitializeComponent();
        }

        private void frmLoginScreen_Load(object sender, EventArgs e)
        {
            pbclogo.Image = Resource1.IBS_Logo;
        }

        private void btn_login_click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                string strUserName = txtUserName.Text.Trim(); //"baghel3349@gmail.com"; //"naresh";//
                string strPasword = txtPwd.Text.Trim(); //"7835909031"; //"12345";//// oCommonfunction.CalculateMD5Hash(txtPwd.Text.Trim());
                string dbquery = oCommonfunction.getDbQuery("Login");
                dbCmd = new SqlCeCommand(dbquery, dbCon);
                dbCmd.Parameters.Add("@Email", strUserName);
                dbCmd.Parameters.Add("@Password", strPasword);
                oCommonfunction.db_connection_open(dbCon);
                SqlCeDataReader dr = dbCmd.ExecuteReader();
                if (dr.Read())
                {
                    CommonFunction.login_id = Convert.ToInt32(dr["server_id"].ToString());
                    Cursor.Current = Cursors.Default;
                    frmSettingDetails OfrmSetting = new frmSettingDetails();
                    OfrmSetting.Show();
                    this.Hide();
                }
                else
                {
                    Cursor.Current = Cursors.Default;
                    MessageBox.Show("Username or Password are wrong.Please try again !");
                }

                oCommonfunction.db_connection_close(dbCon);

            }
            catch (Exception ex)
            {


            }
            finally
            {
                oCommonfunction.db_connection_close(dbCon);
            }
        }

        private void btn_change_server_location(object sender, EventArgs e)
        {
          
            frmServerLocation OfrmServerLocation = new frmServerLocation();
            OfrmServerLocation.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 Oform1 = new Form1();
            Oform1.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void btn_exit_click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        

      
        
    }
}