﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
//using Newtonsoft.Json;
using System.Net;
using System.Json;
using System.IO;
//using System.Runtime.Serialization.Json;
//using System.Runtime.Serialization;
using System.Diagnostics;
using System.Collections;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using WDC.Utility;
using System.Data.SqlServerCe;


namespace WDC
{



    public partial class frmServerLocation : Form
    {


        public string conSTR = "Data Source=" +
             (System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase)) +
             "\\dbWDC.sdf;Persist Security Info=False";
        SqlCeConnection dbCon = null;
        SqlCeCommand dbCmd = null;
        CommonFunction oCommonfunction = null;
        WDCApiFunction OwdcApi = null;

      



        public frmServerLocation()
        {

            dbCon = new SqlCeConnection(conSTR);
            oCommonfunction = new CommonFunction();
            OwdcApi = new WDCApiFunction();
           
            InitializeComponent();
        }

        private void frmServerLocation_Load(object sender, EventArgs e)
        {
            pbclogo.Image = Resource1.IBS_Logo;

        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            bool isValidForm = oCommonfunction.frmServerLocationValidation(txtServerPath.Text.Trim());
            if (isValidForm)
            {
                bool is_check = SaveServerIpAddress(txtServerPath.Text.Trim());
                if (is_check)
                {
                    Cursor.Current = Cursors.WaitCursor;

                    try
                    {
                        bool b = OwdcApi.callUserApi();
                        if (!b)
                        {
                            Cursor.Current = Cursors.Default;
                            MessageBox.Show("You seem to be offline. Please check", "Error");
                        }
                        else
                        {
                            OwdcApi.callGetStockDetailsApiForItemList();
                            Cursor.Current = Cursors.Default;
                            frmLoginScreen OfrmLogin = new frmLoginScreen();
                            OfrmLogin.Show();
                        }
                        
                        
                    }
                    catch (Exception ex)
                    {

                    }
                    finally
                    {
                        Cursor.Current = Cursors.Default;
                    }
                }

            }
            else
                MessageBox.Show("Enter server details");
        }


        public bool getServerPath()
        {
            bool is_check = false; 
              SqlCeDataReader dr = null;
            try
            {
                string query = oCommonfunction.getDbQuery("CheckServerDetails");
                dbCmd = new SqlCeCommand(query, dbCon);
                oCommonfunction.db_connection_open(dbCon);
                dr = dbCmd.ExecuteReader();
                if(dr.Read())
                {
                    is_check = true;
                    string getServerLocation = dr["server_path"].ToString();
                    CommonFunction.server_url = getServerLocation;
                }               
            }
            catch (Exception e)
            {
                string ex = e.Message.ToString();
            }
            finally
            {
                dbCmd.Dispose();
                oCommonfunction.db_connection_close(dbCon);
                dr.Close();
            }
            return is_check;
        }


        public bool SaveServerIpAddress(string strServerDetails)
        {
            bool is_check = false;
            try
            {
               
                string query = oCommonfunction.getDbQuery("CheckServerDetails");
                dbCmd = new SqlCeCommand(query, dbCon);
                oCommonfunction.db_connection_open(dbCon);
                SqlCeDataReader dr = dbCmd.ExecuteReader();
                if (dr.Read())
                {

                    string getServerLocation = dr["server_path"].ToString();
                    CommonFunction.server_url = getServerLocation;
                    dbCmd.Dispose();
                    dr.Dispose();
                    is_check = true;

                    if(!getServerLocation.Equals(strServerDetails))
                    {
                        is_check = AddServerDetails("UpdateServerDetails", strServerDetails);
                    }

                }
                else
                {
                    //add
                    dbCmd.Dispose();
                    dr.Dispose();
                    is_check = AddServerDetails("SaveServerDetails", strServerDetails);

                }

                

            }
            catch (Exception exc)
            {


            }
            finally
            {
                oCommonfunction.db_connection_close(dbCon);
            }
            return is_check;
        }





        public bool AddServerDetails(string strServerDetailsQueryInfo, string strServerDetails)
        {
            bool is_check = false;
            string query = oCommonfunction.getDbQuery(strServerDetailsQueryInfo);//update
            dbCmd = new SqlCeCommand(query, dbCon);
            dbCmd.Parameters.Add("@server_path", strServerDetails);
            int ret = dbCmd.ExecuteNonQuery();
            if (ret > 0)
            {
                CommonFunction.server_url = strServerDetails;
                is_check = true;
            }
            return is_check;
        }

    }

}


