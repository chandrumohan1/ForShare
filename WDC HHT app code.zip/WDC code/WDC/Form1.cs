﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlServerCe;
using WDC.Utility;

namespace WDC
{
    public partial class Form1 : Form
    {
       private static string conSTR = "Data Source=" +
         (System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase)) +
         "\\dbWDC.sdf;Persist Security Info=False";
        private static SqlCeConnection connection = new SqlCeConnection(conSTR);
      
        public Form1()
        {

           
            FillGrid();
            FillExceptionGrid();
            InitializeComponent();
        }

        public void FillGrid()
        {

            String query = @"SELECT * FROM tblUserDetails";
            SqlCeCommand cmd = new SqlCeCommand(query, connection);
            SqlCeDataAdapter Da = new SqlCeDataAdapter(cmd);
            DataTable dt = new DataTable();
            Da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                dataGrid1.DataSource = dt;
            }
        }

        public void FillExceptionGrid()
        {

            String query = @"SELECT * FROM tblExceptionHistory";
            SqlCeCommand cmd = new SqlCeCommand(query, connection);
            SqlCeDataAdapter Da = new SqlCeDataAdapter(cmd);
            DataTable dt = new DataTable();
            Da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                dataGrid2.DataSource = dt;
            }
        }
    }
}