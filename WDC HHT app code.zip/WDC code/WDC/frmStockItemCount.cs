﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using WDC.Utility;

namespace WDC
{
    public partial class frmStockItemCount : Form
    {
        //DbConnection OdbConnection = null;
        public frmStockItemCount()
        {
            //OdbConnection = new DbConnection();
            InitializeComponent();
        }

        private void frmStockItemCount_Load(object sender, EventArgs e)
        {
            showStockItemCount();
        }

        public void showStockItemCount()
        {
            DataTable table = new DataTable("Table");
            table.Columns.Add("Item_ID", typeof(string));
            table.Columns.Add("Item Code", typeof(string));
            table.Columns.Add("Scanned", typeof(string));
            table.Columns.Add("item_name", typeof(string));
            DataTable dt = frmSettingDetails.oDbConnection.getStockItemDetails(CommonFunction.Stock_Id);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                //item_no

                int stock_id = Convert.ToInt32(dt.Rows[i]["stock_id"]);
                int Item_ID = Convert.ToInt32(dt.Rows[i]["item_id"]);
                string item_code = Convert.ToString(dt.Rows[i]["item_no"]);
                string item_name = Convert.ToString(dt.Rows[i]["item_name"]);
                string quantity = Convert.ToString(dt.Rows[i]["rcd_quntity"]);
                string batch_no  = Convert.ToString(dt.Rows[i]["batch_no"]);
                int m_stock_type_id = Convert.ToInt32(dt.Rows[i]["m_stock_type_id"]);
                string rcd_quntity = Convert.ToString(dt.Rows[i]["rcd_quntity"]);
                if (m_stock_type_id >1)
                  quantity = Convert.ToString(dt.Rows[i]["total_quantity"]);

                table.Rows.Add(Item_ID, item_code, quantity, item_name);
            }
            dgStockItem.DataSource = table;
            datagridStyleSheet();
            txtRemarks.Text = CommonFunction.stock_remarks;
        }

        private void datagridStyleSheet()
        {
            DataGridTableStyle ts = new DataGridTableStyle();
            ts.MappingName = "Table";

            DataGridTextBoxColumn column1 = new DataGridTextBoxColumn();
            column1.HeaderText = "Item_ID";
            column1.MappingName = "Item_ID";
            column1.Width = -1;
            ts.GridColumnStyles.Add(column1);

            DataGridTextBoxColumn column2 = new DataGridTextBoxColumn();
            column2.HeaderText = "Item Code";
            column2.MappingName = "Item Code";
            column2.Width = 220;
            ts.GridColumnStyles.Add(column2);  
     
            DataGridTextBoxColumn column3 = new DataGridTextBoxColumn();
            column3.HeaderText = "Scanned";
            column3.MappingName = "Scanned";
            column3.Width = 120;
            ts.GridColumnStyles.Add(column3);

            DataGridTextBoxColumn column4 = new DataGridTextBoxColumn();
            column4.HeaderText = "item_name";
            column4.MappingName = "item_name";
            column4.Width = 0;
            ts.GridColumnStyles.Add(column4);
           this.dgStockItem.TableStyles.Add(ts);

        }

       

        private void dgStockItem_DoubleClick(object sender, EventArgs e)
        {
            int currentRowNo = Convert.ToInt32(this.dgStockItem.CurrentRowIndex.ToString());
            if (currentRowNo >= 0)
            {
                string get_item_id = (dgStockItem[currentRowNo, 0].ToString());
                CommonFunction.item_id = Convert.ToInt32(get_item_id);

                string item_code = (dgStockItem[currentRowNo, 3].ToString());
                frmStockItemDetails ofrmStockItem = new frmStockItemDetails();
                ofrmStockItem.Text =" "+item_code;
                ofrmStockItem.Show();
            }
        }

        private void btn_done_click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            bool is_check = frmSettingDetails.oDbConnection.UpdateStockOrder(2, txtRemarks.Text, CommonFunction.item_id, CommonFunction.Stock_Id);
            if (is_check)
            {
                MessageBox.Show("Done.");
                showForm();

            }
            else
                MessageBox.Show("Please try again.");
          
            Cursor.Current = Cursors.Default;
        }

        private void btn_back_click(object sender, EventArgs e)
        {
            showForm();
        }

        public void showForm()
        {
            frmStockCount ofrmStockCount = new frmStockCount();
            ofrmStockCount.Show();
            this.Hide();
        }

        
    }
}