﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlServerCe;
using WDC.Utility;

namespace WDC
{
    public partial class frmChangeSetting : Form
    {
        public string conSTR = "Data Source=" +
        (System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase)) +
        "\\dbWDC.sdf;Persist Security Info=False";
        SqlCeConnection dbCon = null;
        SqlCeCommand dbCmd = null;
        CommonFunction oCommonfunction = null;
        public frmChangeSetting()
        {
            dbCon = new SqlCeConnection(conSTR);           
            oCommonfunction = new CommonFunction();
            InitializeComponent();
        }
        private void frmChangeSetting_Load(object sender, EventArgs e)
        {
            lblServerUrl.Text = CommonFunction.server_url;
        }
       
        private void btn_Ok_Click(object sender, EventArgs e)
        {
            
            int count = 0;
            try
            {
                bool is_check = oCommonfunction.frmCheckChangePwdValidation(txtOldPwd.Text.Trim(), txtOldPwd.Text.Trim(), txtReTypePwd.Text.Trim());
                if (is_check)
                {
                    if (txtNewPwd.Text.Trim().Equals(txtReTypePwd.Text.Trim()))
                    {
                        string query = @"SELECT COUNT(*) FROM tblUserDetails WHERE Password='" + txtOldPwd.Text.Trim() + "' AND server_id =" + CommonFunction.login_id;
                        dbCmd = new SqlCeCommand(query, dbCon);
                        oCommonfunction.db_connection_open(dbCon);
                        count = (Int32)dbCmd.ExecuteScalar();
                        if (count > 0)
                        {
                            dbCmd.Dispose();
                            string updatequery = @"UPDATE  tblUserDetails SET Password='" + txtOldPwd.Text.Trim().Trim() + "',status=2 WHERE  server_id =" + CommonFunction.login_id;
                            SqlCeCommand dbCmd1 = new SqlCeCommand(updatequery, dbCon);
                            int ret = dbCmd1.ExecuteNonQuery();
                            if (ret > 0)
                            {

                                MessageBox.Show("password is saved successfully !!!");
                            }
                            else
                            {
                                MessageBox.Show("some error occured.Please try again !!!");
                            }

                            dbCmd1.Dispose();
                        }
                        else
                        {
                            dbCmd.Dispose();
                            MessageBox.Show("please enter valid old password !!!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Does not match New Password or Re-type Password !!!");
                    }
                }
                else
                {
                    MessageBox.Show("Please enter value !!!");
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
            finally
            {
                oCommonfunction.db_connection_close(dbCon);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmSettingDetails OfrmSetting = new frmSettingDetails();
            OfrmSetting.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //delete all data 
            if (frmSettingDetails.oDbConnection != null)
            {
                frmSettingDetails.oDbConnection.deleteAllData("DELETE FROM ItemDetails");
                frmSettingDetails.oDbConnection.deleteAllData("DELETE FROM tblPurchaseOrder");
                frmSettingDetails.oDbConnection.deleteAllData("DELETE FROM tblPurchaseOrderItem");
                frmSettingDetails.oDbConnection.deleteAllData("DELETE FROM tblSalesOrder");
                frmSettingDetails.oDbConnection.deleteAllData("DELETE FROM tblSalesOrderItem");
                frmSettingDetails.oDbConnection.deleteAllData("DELETE FROM tblStockCountSheet");
                frmSettingDetails.oDbConnection.deleteAllData("DELETE FROM tblStockItemCount");
                frmSettingDetails.oDbConnection.deleteAllData("DELETE FROM tblExceptionHistory");
                MessageBox.Show("Database has been deleted !!!");
            }
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            frmViewMaster obfrm = new frmViewMaster();
            obfrm.Show();
        }

       

       
    }
}