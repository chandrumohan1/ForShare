﻿namespace WDC
{
    partial class frmSalesOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.dgSalesOrder = new System.Windows.Forms.DataGrid();
            this.btn_back = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // dgSalesOrder
            // 
            this.dgSalesOrder.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.dgSalesOrder.Location = new System.Drawing.Point(0, 34);
            this.dgSalesOrder.Name = "dgSalesOrder";
            this.dgSalesOrder.Size = new System.Drawing.Size(240, 200);
            this.dgSalesOrder.TabIndex = 0;
            this.dgSalesOrder.DoubleClick += new System.EventHandler(this.dgSalesOrder_DoubleClick);
            // 
            // btn_back
            // 
            this.btn_back.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btn_back.Location = new System.Drawing.Point(85, 241);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(72, 20);
            this.btn_back.TabIndex = 1;
            this.btn_back.Text = "Back";
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.DarkRed;
            this.label1.Location = new System.Drawing.Point(60, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 20);
            this.label1.Text = "Sale Order Details";
            // 
            // frmSalesOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_back);
            this.Controls.Add(this.dgSalesOrder);
            this.Menu = this.mainMenu1;
            this.Name = "frmSalesOrder";
            this.Text = " Delivery (against SO)";
            this.Load += new System.EventHandler(this.frmSalesOrder_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGrid dgSalesOrder;
        private System.Windows.Forms.Button btn_back;
        private System.Windows.Forms.Label label1;
    }
}