﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using WDC.Utility;

namespace WDC
{
    public partial class frmPurchaseOrder : Form
    {
        //DbConnection OdbConnection = null;
        public frmPurchaseOrder()
        {
            //OdbConnection = new DbConnection();
            InitializeComponent();
        }

        private void frmPurchaseOrder_Load(object sender, EventArgs e)
        {
            showPurchaseOrderDeails();
        }

        public void showPurchaseOrderDeails()
        {

            DataTable table = new DataTable("Table");
            table.Columns.Add("Purchase Orders", typeof(string));
            table.Columns.Add("Order", typeof(string));
            table.Columns.Add("Rcd", typeof(string));
            //DataGridViewColumn ID_Column = dgPurchaseOrder.Columns[0];
            //ID_Column.Width = 200;
            DataTable dt = frmSettingDetails.oDbConnection.getPurchaseOrderDetails();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string PO_server_id = Convert.ToString(dt.Rows[i]["PO_server_id"]);
                string Vendor_Name = Convert.ToString(dt.Rows[i]["Vendor_Name"]);
                string purchase_order_no = Convert.ToString(dt.Rows[i]["purchase_order_no"]);
                string phone_status = Convert.ToString(dt.Rows[i]["phone_status"]);
                string printstatus = "";
                if (phone_status == "2")
                    printstatus = "Pass";
                else if (phone_status == "3")
                    printstatus = "Fail";

                string purchaseOrder = Vendor_Name + "(" + purchase_order_no + ")";
                int Count = frmSettingDetails.oDbConnection.getPurchaseOrderItemCount(Convert.ToInt32(PO_server_id));
                table.Rows.Add(purchaseOrder, Count, printstatus);
            }

            dgPurchaseOrder.DataSource = table;
            datagridStyleSheet();
            changeGridColor(table);
            
         
        }

      

        private void datagridStyleSheet()
        {
            DataGridTableStyle ts = new DataGridTableStyle();
            ts.MappingName = "Table";

            DataGridTextBoxColumn column1 = new DataGridTextBoxColumn();
            column1.HeaderText = "Purchase Orders";
            column1.MappingName = "Purchase Orders";
            column1.Width = 270;
            ts.GridColumnStyles.Add(column1);

            DataGridTextBoxColumn column2 = new DataGridTextBoxColumn();
            column2.HeaderText = "Order";
            column2.MappingName = "Order";
            column2.Width = 80;
            
            ts.GridColumnStyles.Add(column2);

            DataGridTextBoxColumn column3 = new DataGridTextBoxColumn();
            column3.HeaderText = "Rcd";
            column3.MappingName = "Rcd";
            column3.Width = 80;
            ts.GridColumnStyles.Add(column3);

            this.dgPurchaseOrder.TableStyles.Add(ts);
        }

        public void changeGridColor(DataTable dt)
        {
            DataGridTableStyle ts = new DataGridTableStyle();
            int index1 = -1;
            bool found = false;


            foreach (DataRow dr in dt.Rows)
            {
                index1++;
                string setStatus = Convert.ToString(dr[2].ToString());

                if (setStatus.Contains("Pass"))
                {
                    dgPurchaseOrder.Select(index1);
                    dgPurchaseOrder.SelectionBackColor = Color.Green;

                    // break;
                }
                else if (setStatus.Contains("Fail"))
                {
                    dgPurchaseOrder.Select(index1);
                    dgPurchaseOrder.SelectionBackColor = Color.Red;
                }


            }
        }

        

        private void button1_Click(object sender, EventArgs e)
        {
            frmSettingDetails OfrmSetting = new frmSettingDetails();
            OfrmSetting.Show();
            this.Hide();
        }

        private void dgPurchaseOrder_DoubleClick(object sender, EventArgs e)
        {
          int currentRowNo =Convert.ToInt32(this.dgPurchaseOrder.CurrentRowIndex.ToString());
          if(currentRowNo >= 0)
          {
              //get purchase order no....
              CommonFunction.Purchase_order_no = dgPurchaseOrder[currentRowNo, 0].ToString();
             
              frmPurchaseOrderItem OfrmPurchaseOrderItem = new frmPurchaseOrderItem();
              OfrmPurchaseOrderItem.Show();
          }
         

        }

   
      
    }
}