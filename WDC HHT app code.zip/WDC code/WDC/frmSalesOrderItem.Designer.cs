﻿namespace WDC
{
    partial class frmSalesOrderItem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.label1 = new System.Windows.Forms.Label();
            this.dgSalesOrderItem = new System.Windows.Forms.DataGrid();
            this.btn_pass = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lblSoNo = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtRemarks = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.DarkRed;
            this.label1.Location = new System.Drawing.Point(79, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 20);
            this.label1.Text = "Item Details";
            // 
            // dgSalesOrderItem
            // 
            this.dgSalesOrderItem.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.dgSalesOrderItem.Location = new System.Drawing.Point(-4, 47);
            this.dgSalesOrderItem.Name = "dgSalesOrderItem";
            this.dgSalesOrderItem.Size = new System.Drawing.Size(244, 144);
            this.dgSalesOrderItem.TabIndex = 1;
            this.dgSalesOrderItem.DoubleClick += new System.EventHandler(this.dgSalesOrderItem_DoubleClick);
            // 
            // btn_pass
            // 
            this.btn_pass.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btn_pass.Enabled = false;
            this.btn_pass.Location = new System.Drawing.Point(88, 240);
            this.btn_pass.Name = "btn_pass";
            this.btn_pass.Size = new System.Drawing.Size(66, 20);
            this.btn_pass.TabIndex = 3;
            this.btn_pass.Text = "Pass";
            this.btn_pass.Click += new System.EventHandler(this.btn_pass_click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.MediumAquamarine;
            this.button2.Location = new System.Drawing.Point(3, 240);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(72, 20);
            this.button2.TabIndex = 4;
            this.button2.Text = "Fail";
            this.button2.Click += new System.EventHandler(this.btn_fail_click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.MediumAquamarine;
            this.button3.Location = new System.Drawing.Point(162, 239);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(68, 20);
            this.button3.TabIndex = 5;
            this.button3.Text = "Back";
            this.button3.Click += new System.EventHandler(this.btn_back_click);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(11, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 20);
            this.label2.Text = "SO No -";
            // 
            // lblSoNo
            // 
            this.lblSoNo.Location = new System.Drawing.Point(75, 8);
            this.lblSoNo.Name = "lblSoNo";
            this.lblSoNo.Size = new System.Drawing.Size(139, 20);
            this.lblSoNo.Text = "N/A";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(7, 212);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 20);
            this.label3.Text = "Remarks";
            // 
            // txtRemarks
            // 
            this.txtRemarks.Location = new System.Drawing.Point(66, 198);
            this.txtRemarks.Multiline = true;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.Size = new System.Drawing.Size(171, 36);
            this.txtRemarks.TabIndex = 8;
            // 
            // frmSalesOrderItem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtRemarks);
            this.Controls.Add(this.lblSoNo);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btn_pass);
            this.Controls.Add(this.dgSalesOrderItem);
            this.Controls.Add(this.label1);
            this.Menu = this.mainMenu1;
            this.Name = "frmSalesOrderItem";
            this.Text = " Sale Order Items";
            this.Load += new System.EventHandler(this.frmSalesOrderItem_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGrid dgSalesOrderItem;
        private System.Windows.Forms.Button btn_pass;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblSoNo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtRemarks;
    }
}