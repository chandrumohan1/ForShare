﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using WDC.Utility;

namespace WDC
{
    public partial class frmStockCount : Form
    {
        CommonFunction oCommonFunction = null;
        //DbConnection OdbConnection = null;
        public frmStockCount()
        {
            oCommonFunction = new CommonFunction();
            //OdbConnection = new DbConnection();
            InitializeComponent();
        }

        private void frmStockCount_Load(object sender, EventArgs e)
        {
            showStockDeails();
        }

        public void showStockDeails()
        {

            DataTable table = new DataTable("Table");
            table.Columns.Add("Id", typeof(string));
            table.Columns.Add("Stock Count Sheets", typeof(string));
            table.Columns.Add("Status", typeof(string));
            DataTable dt = frmSettingDetails.oDbConnection.getStockDetails();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string stock_id = Convert.ToString(dt.Rows[i]["id"]);
                string name = Convert.ToString(dt.Rows[i]["name"]);
                string phone_status = Convert.ToString(dt.Rows[i]["phone_status"]);
                string printstatus = "";
                if (phone_status == "2")
                    printstatus = "Done";

                int QunatCount = frmSettingDetails.oDbConnection.getStockItemCount(Convert.ToInt32(stock_id));
                table.Rows.Add(stock_id, name, printstatus);
            }

            dgStockDetails.DataSource = table;
            datagridStyleSheet();
            changeGridColor(table);
        }

        private void datagridStyleSheet()
        {
            DataGridTableStyle ts = new DataGridTableStyle();
            ts.MappingName = "Table";

            DataGridTextBoxColumn column1 = new DataGridTextBoxColumn();
            column1.HeaderText = "Id";
            column1.MappingName = "Id";
            column1.Width = -1;
            ts.GridColumnStyles.Add(column1);

            DataGridTextBoxColumn column2 = new DataGridTextBoxColumn();
            column2.HeaderText = "Stock Count Sheets";
            column2.MappingName = "Stock Count Sheets";
            column2.Width = 200;
            ts.GridColumnStyles.Add(column2);

            DataGridTextBoxColumn column3 = new DataGridTextBoxColumn();
            column3.HeaderText = "Status";
            column3.MappingName = "Status";
            column3.Width = 100;
            ts.GridColumnStyles.Add(column3);

            this.dgStockDetails.TableStyles.Add(ts);
        }

        public void changeGridColor(DataTable dt)
        {
            DataGridTableStyle ts = new DataGridTableStyle();
            int index1 = -1;
            bool found = false;


            foreach (DataRow dr in dt.Rows)
            {
                index1++;
                string setStatus = Convert.ToString(dr[2].ToString());

                if (setStatus.Contains("Done"))
                {
                    dgStockDetails.Select(index1);
                    dgStockDetails.SelectionBackColor = Color.Green;

                    // break;
                }
               


            }
        }

       

        private void btn_close_click(object sender, EventArgs e)
        {
            frmSettingDetails ofrmSettingDetails = new frmSettingDetails();
            ofrmSettingDetails.Show();
            this.Hide();
        }

        private void dataGrid1_DoubleClick(object sender, EventArgs e)
        {

            int currentRowNo = Convert.ToInt32(this.dgStockDetails.CurrentRowIndex.ToString());
            if (currentRowNo >= 0)
            {
                //get 
                string strRowId  = dgStockDetails[currentRowNo, 0].ToString();
                CommonFunction.Stock_Id = Convert.ToInt32(strRowId);
                frmStockItemCount ofrmStockItem = new frmStockItemCount();
                ofrmStockItem.Show();
            }       

        }

        
    }
}