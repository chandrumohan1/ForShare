﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WDC
{
    public partial class frmSelectedCountSheet : Form
    {
        public frmSelectedCountSheet()
        {
            InitializeComponent();
        }

        private void btn_ok_click(object sender, EventArgs e)
        {

        }

        private void btn_close_click(object sender, EventArgs e)
        {

        }
    }
}