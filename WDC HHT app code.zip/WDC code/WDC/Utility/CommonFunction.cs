﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlTypes;
using System.Data.SqlClient;
using System.Data.SqlServerCe;
using Symbol.Barcode2;
using System.Data;


namespace WDC.Utility
{
    class CommonFunction
    {

        public string conSTR = "Data Source=" +
          (System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase)) +
          "\\dbWDC.sdf;Persist Security Info=False";
        SqlCeConnection dbCon = null;
        SqlCeCommand dbCmd = null;
        public static int login_id { get; set; }
        public static string Purchase_order_no { get; set; }
        public static string Sales_order_no { get; set; }
        public static string Po_item_code { get; set; }
        public static int item_id { get; set; }
        public static int Stock_Id { get; set; }
        public static int SO_ID { get; set; }
        public static string server_url { get; set; }
        public static string Po_remarks { get; set; }
        public static string so_remarks { get; set; }
        public static string stock_remarks { get; set; }

        //for total count 
        public static int poCount { get; set; }
        public static int soCount { get; set; }
        public static int stockCount { get; set; }
       

        public void db_connection_open(SqlCeConnection dbCon)
        {
            if(!dbCon.State.Equals("Open"))
               dbCon.Open();
         
        }
        public void db_connection_close(SqlCeConnection dbCon)
        {
            if(!dbCon.State.Equals("Close"))
                dbCon.Close();
        }

        public bool frmServerLocationValidation(string strServerLocation)
        {
            if ((!string.IsNullOrEmpty(strServerLocation)) && (strServerLocation.Length > 0))
             return true;
            else return false;
        }

        public bool frmCheckOneNoValidation(string value)
        {
            if ((!string.IsNullOrEmpty(value)) && (value.Length > 0))
                return true;
            else return false;
            
        }

        public bool frmCheckTwoNoValidation(string first_value ,string second_value)
        {
            if (((!string.IsNullOrEmpty(first_value)) && (first_value.Length > 0)) && (!string.IsNullOrEmpty(second_value)) && (second_value.Length > 0))
                return true;
            else return false;
        }


        public bool frmCheckChangePwdValidation(string first_value,string second_value,string third_value)
        {
            if (((!string.IsNullOrEmpty(first_value)) && (first_value.Length > 0)) && ((!string.IsNullOrEmpty(second_value)) && (second_value.Length > 0)) && ((!string.IsNullOrEmpty(third_value)) && (third_value.Length > 0)))
                return true;
            else
                return false;
        }

       

        public string CalculateMD5Hash(string input)
        {
            // step 1, calculate MD5 hash from input
            System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create();
            byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
            byte[] hash = md5.ComputeHash(inputBytes);
            // step 2, convert byte array to hex string
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < hash.Length; i++)
            {
                sb.Append(hash[i].ToString("x2"));
            }
            return sb.ToString();
        }

       


        public string getDbQuery(string queryType)
        {
            string Query = "";
            switch(queryType)
            {
               //for server details (Ip address)
                case "CheckServerDetails":
                    Query = @"SELECT * FROM tblServerDetails";
                    break;
                case "UpdateServerDetails":
                    Query = @"UPDATE  tblServerDetails SET server_path=@server_path";
                    break;
                case "SaveServerDetails":
                    Query = @"INSERT INTO tblServerDetails(server_path)
                             VALUES(@server_path)";
                    break;
              //for user
                case "CheckUser":
                    Query = @"SELECT * FROM tblUserDetails WHERE server_id=@server_id";
                    break;
                case "UpdateUser":
                    Query = @"UPDATE tblUserDetails SET UserName=@UserName,Password =@Password,status =@status
                             where server_id=@server_id";
                    break;
                case "SaveAllUser":
                    Query = @"INSERT INTO tblUserDetails (server_id,UserName,Password, Email,status)
                             VALUES(@server_id,@UserName,@Password, @Email,@status)";
                    break;
                    //for login
                case "Login":
                    Query = @"SELECT * FROM tblUserDetails WHERE Email=@Email and Password=@Password";
                    break;

                case "AddItemList":
                    Query = @"INSERT INTO ItemDetails (server_id,item_no,item_name
                            ,description,m_stock_type_id,location_id,sub_location_id,m_stock_unit_id
                            ,m_stock_status_id, recorder_label,current_stock,cost_per_item)
                             VALUES(@server_id,@item_no,@item_name
                             ,@description,@m_stock_type_id,@location_id,@sub_location_id,@m_stock_unit_id,@m_stock_status_id,
                            @recorder_label,@current_stock,@cost_per_item)";
                    break;
                    //purchase order

                case "AddPurchaseList":
                    Query = @"INSERT INTO tblPurchaseOrder (PO_server_id
                            ,purchase_order_no,date_of_purchase,expected_delivery_date,assigned_user
                            ,server_status,phone_status,Vendor_ID,Vendor_Name)
                             VALUES(@PO_server_id
                            ,@purchase_order_no,@date_of_purchase,@expected_delivery_date,@assigned_user
                            ,@server_status,@phone_status,@Vendor_ID,@Vendor_Name)";
                    break;

                case "AddPurchaseOrderItem":
                    Query = @"INSERT INTO tblPurchaseOrderItem (id
                            ,Item_ID,Item_Name,PO_ID,Quantity,Vender_ID,total_quantity)
                            VALUES(@id,@Item_ID,@Item_Name,@PO_ID,@Quantity,@Vender_ID,@total_quantity)";
                    break;
               
                 //sales order
                case "AddSalesOrderList":
                    Query = @"INSERT INTO tblSalesOrder (ID
                            ,name,Customer_ID,DateOfOrder,ExpectedDateOfDelivery
                            ,SalesOrderNo,Status,phone_status)
                             VALUES(@ID
                            ,@name,@Customer_ID,@DateOfOrder,@ExpectedDateOfDelivery
                            ,@SalesOrderNo,@Status,@phone_status)";
                    break;
                case "AddSalesOrderItem":
                    Query = @"INSERT INTO tblSalesOrderItem (ID,Item_ID,Item_Name,Quantity,
                              Cost_Per_Item,SO_ID,total_quantity)
                            VALUES(@ID,@Item_ID,@Item_Name,@Quantity,
                              @Cost_Per_Item,@SO_ID,@total_quantity)";
                    break;
                case "AddStockDetails":
                    Query = @"INSERT INTO tblStockCountSheet (id,name,status,phone_status)
                            VALUES(@id,@name,@status,@phone_status)";
                    break;
                case "AddStockItemDetails":
                    Query = @"INSERT INTO tblStockItemCount (item_id,stock_id,stock_sheet_id,total_quantity)
                            VALUES(@item_id,@stock_id,@stock_sheet_id,@total_quantity)";
                    break;
            
               //for testing  truncate table 
                case "TruncateTable":
                    Query = @"TRUNCATE TABLE tblUserDetails";
                    break;
                case "Exception":
                    Query = @"INSERT INTO tblExceptionHistory (exception,page)VALUES (@exception,@page)";
                    break;
                default:
                    Query = "";
                    break;
            }
            return Query;

        }

        public DataTable FillDynamicTable(string firstValue, string secondValue, int type, DataTable dynamicTable)
        {

            try
            {
                if (type == 2)
                {
                 
                    if (dynamicTable.Rows.Count == 0)
                    {
                          
                            dynamicTable.Columns.Add("S.No", typeof(Int32));
                            dynamicTable.Columns.Add("Batch No", typeof(string));
                            dynamicTable.Columns.Add("Quantity", typeof(string));
                            dynamicTable.Columns["S.No"].AutoIncrement = true;
                            dynamicTable.Columns["S.No"].AutoIncrementStep = 1;
                            dynamicTable.Columns["S.No"].AutoIncrementSeed = 1;
                       
                    }
                    dynamicTable.Rows.Add(null, firstValue, secondValue);
                }
                else if (type == 3)
                {
                    if (dynamicTable.Rows.Count == 0)
                    {
                        dynamicTable.Columns.Add("S.No", typeof(Int32));
                        dynamicTable.Columns.Add("Batch No", typeof(string));
                        dynamicTable.Columns.Add("Serial No", typeof(string));
                        dynamicTable.Columns["S.No"].AutoIncrement = true;
                        dynamicTable.Columns["S.No"].AutoIncrementStep = 1;
                        dynamicTable.Columns["S.No"].AutoIncrementSeed = 1;
                    }
                    dynamicTable.Rows.Add(null, firstValue, secondValue);
                }
                else if (type == 4)
                {
                    if (dynamicTable.Rows.Count == 0)
                    {
                        dynamicTable.Columns.Add("S.No", typeof(Int32));
                        dynamicTable.Columns.Add("Serial No", typeof(string));
                        dynamicTable.Columns["S.No"].AutoIncrement = true;
                        dynamicTable.Columns["S.No"].AutoIncrementStep = 1;
                        dynamicTable.Columns["S.No"].AutoIncrementSeed = 1;
                    }
                    dynamicTable.Rows.Add(null, secondValue);

                }
            }
            catch (Exception ex)
            {
                if (dynamicTable.Rows.Count ==0)
                  dynamicTable.Rows.Add(null, firstValue, secondValue);
               
            }
           // dgScanDetails.DataSource = dynamicTable;
            return dynamicTable;
        }


        public int concatenateString(out string firstValue, out string secondValue, int type, DataTable dynamicTable)
        {
            firstValue = "";
            secondValue = "";
            int total_quantity = dynamicTable.Rows.Count;
            for (int i = 0; i <= dynamicTable.Rows.Count - 1; i++)
            {
                DataRow dr = dynamicTable.Rows[i];
                if (type == 2)
                {
                    if (i == 0)
                    {
                        firstValue = Convert.ToString(dr["Batch No"]);
                        secondValue = Convert.ToString(dr["Quantity"]);
                        total_quantity = Convert.ToInt32(dr["Quantity"]);
                    }
                    else
                    {
                        firstValue += "#" + Convert.ToString(dr["Batch No"]);
                        secondValue += "#" + Convert.ToString(dr["Quantity"]);
                        total_quantity += Convert.ToInt32(dr["Quantity"]);
                    }


                }
                else if (type == 3)
                {
                    if (i == 0)
                    {

                        firstValue = Convert.ToString(dr["Batch No"]);
                        secondValue = Convert.ToString(dr["Serial No"]);
                    }
                    else
                    {
                        firstValue += "#" + Convert.ToString(dr["Batch No"]);
                        secondValue += "#" + Convert.ToString(dr["Serial No"]);
                    }

                }
                else if (type == 4)
                {
                    if (i == 0)
                    {
                        secondValue = Convert.ToString(dr["Serial No"]);
                    }
                    else
                    {
                        secondValue += "#" + Convert.ToString(dr["Serial No"]);
                    }
                }

            }//end for loop    
            return total_quantity;
        }


        public bool enabledPassButton(int quantity,int rcd_quantity)
        {
            if (rcd_quantity >= quantity)
                return true;
            else
                return false;
        }

        public bool enabledFailButton(int rcd_quantity)
        {
            if (rcd_quantity > 0)
                return true;
            else
                return false;
        }

        #region Barcode Scanning
        Barcode2 MyBarcode;
        public string BarcodeScan()
        {
            String scannedData = "";
            MyBarcode = new Barcode2();

            // MyBarcode = new Barcode2("SCN1");
            //  Device MyDevice = null;

            //for (int i = 0; i < Symbol.Barcode2.Devices.SupportedDevices.Length; i++)
            //{
            //    //if (Symbol.Barcode2.Devices.SupportedDevices[i].DeviceType == DEVICETYPES.INTERNAL_LASER1)
            //    {
            //        MyDevice = Symbol.Barcode2.Devices.SupportedDevices[i];
            //        break;
            //    }
            //}

            //if (MyDevice == null) return;

            // MyBarcode = new Barcode2(MyDevice);
            //  bool b1 = MyBarcode.IsEnabled;
            //  bool b= MyBarcode.DeviceInfo.IsAimModeSupported;
            // MyBarcode.Config.Reader.ReaderSpecific.ImagerSpecific.AimDuration = 500;

            // READER_TYPES r = MyBarcode.Config.Reader.ReaderType;
            //  Symbol.Barcode2.BEAM_WIDTH ii = MyBarcode.Config.Reader.ReaderSpecific.LaserSpecific.BeamWidth;
            //Barcode2 MyBarcode = new Barcode2();
            // MyBarcode.Enable();
            //  bool b2 = MyBarcode.IsEnabled;
            //  MyBarcode.OnScan += new Barcode2.OnScanHandler(symbolBarcode2_OnScan);
            //  MyBarcode.ScanBufferStart();

            //switch (MyBarcode.Config.Reader.ReaderType)
            //{
            //    case READER_TYPES.READER_TYPE_IMAGER:
            //        MyBarcode.Config.Reader.ReaderSpecific.ImagerSpecific.AimType = AIM_TYPE.AIM_TYPE_TRIGGER;
            //        break;
            //    case READER_TYPES.READER_TYPE_LASER:
            //        MyBarcode.Config.Reader.ReaderSpecific.LaserSpecific.AimType = AIM_TYPE.AIM_TYPE_TRIGGER;
            //        break;
            //}
            //MyBarcode.Config.Reader.Set();

            //MyBarcode.Config.TriggerMode = TRIGGERMODES.HARD;
            if (MyBarcode.Config.TriggerMode != TRIGGERMODES.SOFT_ALWAYS)
            {
                MyBarcode.Config.TriggerMode = TRIGGERMODES.SOFT_ALWAYS;
            }

            ScanData MyData = MyBarcode.ScanWait(5000); // 5 seconds timeout
            MyBarcode.ScanCancel();
            MyBarcode.Dispose();

            if (MyData.Result == Results.SUCCESS) // Barcode was scanned successfully
            {
                scannedData = MyData.Text;
            }
            if (MyData.Result == Results.E_SCN_READTIMEOUT)   // Barcode was not scanned within 5 secs
            {
                return "";// false;
            }


            return scannedData;


        }
        private void symbolBarcode2_OnScan(ScanDataCollection scancollection)
        {
            if (scancollection.GetFirst.Text == "0000000000")
            {
                // Turn off scanner and alert user
                //symbolBarcode2.ScanBufferStop();
                System.Threading.Thread t = new System.Threading.Thread(StopDelegate);
                t.Start();
            }
            else
            {
                // Process data and wait for next scan
            }
        }

        internal void StopDelegate()
        {
            MyBarcode.ScanBufferStop();
        }

        #endregion

        public void WriteExceptionLog(string exception,string page)
        {
            string exceptionQuery = getDbQuery("Exception");
            dbCmd = new SqlCeCommand(exceptionQuery, dbCon);
            dbCmd.Parameters.Add("@exception", exception);
            dbCmd.Parameters.Add("@page", page);
            dbCmd.ExecuteNonQuery();

        }


      

    }
}
