﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.IO;
using Newtonsoft.Json;

namespace WDC.Utility
{
    public class WDCApiFunction
    {
        //DbConnection OdbConnection = null;
        public static List<POApiResponse> listApiPORet = new List<POApiResponse>();
        public static List<SOApiResponse> listApiSORet = new List<SOApiResponse>();
        public static List<StockApiResponse> listApiStockRet = new List<StockApiResponse>();

        public WDCApiFunction()
        {
            //OdbConnection = new DbConnection(this);
        }


        public bool callUserApi()
        {
            bool ret = false;
            var request = WebRequest.Create(CommonFunction.server_url + "/WDCAPI/GetUsers"); //"http://finance.azibyte.com/WDCAPI/GetUsers");
            request.ContentType = "application/json"; //your contentType, Json, text,etc. -- or comment, for text
            request.Method = "GET"; //method, GET, POST, etc -- or comment for GET

            // string response = "[{\"Claims\":[],\"Logins\":[],\"Roles\":[],\"Photo\":\"Chrysanthemum20170607180408133.jpg\",\"Name\":\"Naresh Baghel\",\"Code\":\"SFT0022\",\"Is_for_Mobile_Device\":1,\"Is_Active\":1,\"Email\":\"naresh@softdew.co.in\",\"EmailConfirmed\":false,\"PasswordHash\":\"AGVGQ+rmKAONa/0WFdE7w0Q5RFgN2bb4nooW3WhFLxmH3EO1YmnurlBLkR6aOg2N8w==\",\"SecurityStamp\":\"633da25c-fd39-48eb-a70c-810906f945f5\",\"PhoneNumber\":null,\"PhoneNumberConfirmed\":false,\"TwoFactorEnabled\":false,\"LockoutEndDateUtc\":null,\"LockoutEnabled\":true,\"AccessFailedCount\":0,\"Id\":\"6\",\"UserName\":\"naresh@softdew.co.in\"},{\"Claims\":[],\"Logins\":[],\"Roles\":[],\"Photo\":null,\"Name\":\"Naresh Baghel\",\"Code\":\"SFT0021\",\"Is_for_Mobile_Device\":1,\"Is_Active\":1,\"Email\":\"n@h.com\",\"EmailConfirmed\":false,\"PasswordHash\":\"AJZHP73xDe7U13EICkEOD6zqjeRN8nrmWqtPQo5O1QWQ6WdoYJtMj0YjkrrSQGfGIA==\",\"SecurityStamp\":\"95ab8cf8-4d1e-4267-a729-143c5423199c\",\"PhoneNumber\":null,\"PhoneNumberConfirmed\":false,\"TwoFactorEnabled\":false,\"LockoutEndDateUtc\":null,\"LockoutEnabled\":true,\"AccessFailedCount\":0,\"Id\":\"9\",\"UserName\":\"n@h.com\"},{\"Claims\":[],\"Logins\":[],\"Roles\":[],\"Photo\":null,\"Name\":\"Naresh \",\"Code\":\"ATS001\",\"Is_for_Mobile_Device\":1,\"Is_Active\":1,\"Email\":\"baghel3349@gmail.com\",\"EmailConfirmed\":false,\"PasswordHash\":\"AEfx5oK+easabrzUHfk6adHh5+EGr2sDCd3MpEqxIcqOtLzhBY7cq9z0f8pOEdn7BQ==\",\"SecurityStamp\":\"f4762de7-de2c-442d-ac3c-70e1ac6b853c\",\"PhoneNumber\":null,\"PhoneNumberConfirmed\":false,\"TwoFactorEnabled\":false,\"LockoutEndDateUtc\":null,\"LockoutEnabled\":true,\"AccessFailedCount\":0,\"Id\":\"18\",\"UserName\":\"baghel3349@gmail.com\"}]";
            string response = ""; // "[{\"Claims\":[],\"Logins\":[],\"Roles\":[],\"Password\":\"12345\",\"Photo\":\"Chrysanthemum20170607180408133.jpg\",\"Name\":\"Naresh Baghel\",\"Code\":\"SFT0022\",\"Is_for_Mobile_Device\":1,\"Is_Active\":1,\"Email\":\"naresh@softdew.co.in\",\"EmailConfirmed\":false,\"PasswordHash\":\"AGVGQ+rmKAONa/0WFdE7w0Q5RFgN2bb4nooW3WhFLxmH3EO1YmnurlBLkR6aOg2N8w==\",\"SecurityStamp\":\"633da25c-fd39-48eb-a70c-810906f945f5\",\"PhoneNumber\":null,\"PhoneNumberConfirmed\":false,\"TwoFactorEnabled\":false,\"LockoutEndDateUtc\":null,\"LockoutEnabled\":true,\"AccessFailedCount\":0,\"Id\":\"6\",\"UserName\":\"naresh\"},{\"Claims\":[],\"Logins\":[],\"Roles\":[],\"Password\":\"7835909031\",\"Photo\":null,\"Name\":\"Naresh Baghel\",\"Code\":\"SFT0021\",\"Is_for_Mobile_Device\":1,\"Is_Active\":1,\"Email\":\"n@h.com\",\"EmailConfirmed\":false,\"PasswordHash\":\"AJZHP73xDe7U13EICkEOD6zqjeRN8nrmWqtPQo5O1QWQ6WdoYJtMj0YjkrrSQGfGIA==\",\"SecurityStamp\":\"95ab8cf8-4d1e-4267-a729-143c5423199c\",\"PhoneNumber\":null,\"PhoneNumberConfirmed\":false,\"TwoFactorEnabled\":false,\"LockoutEndDateUtc\":null,\"LockoutEnabled\":true,\"AccessFailedCount\":0,\"Id\":\"9\",\"UserName\":\"n@h.com\"},{\"Claims\":[],\"Logins\":[],\"Roles\":[],\"Password\":\"7835909031\",\"Photo\":null,\"Name\":\"Naresh \",\"Code\":\"ATS001\",\"Is_for_Mobile_Device\":1,\"Is_Active\":1,\"Email\":\"baghel3349@gmail.com\",\"EmailConfirmed\":false,\"PasswordHash\":\"AEfx5oK+easabrzUHfk6adHh5+EGr2sDCd3MpEqxIcqOtLzhBY7cq9z0f8pOEdn7BQ==\",\"SecurityStamp\":\"f4762de7-de2c-442d-ac3c-70e1ac6b853c\",\"PhoneNumber\":null,\"PhoneNumberConfirmed\":false,\"TwoFactorEnabled\":false,\"LockoutEndDateUtc\":null,\"LockoutEnabled\":true,\"AccessFailedCount\":0,\"Id\":\"18\",\"UserName\":\"baghel3349@gmail.com\"}]";
            try
            {
                
                using (WebResponse resp = request.GetResponse())
                {
                    if (resp == null)
                        new Exception("Response is null");

                    var re = resp.GetResponseStream();

                    //  if ((resp.s == HttpStatusCode.OK) && (resp.ContentLength > 0))
                    if (resp.ContentLength > 0)
                    {
                        string content;
                        using (StreamReader reader = new StreamReader(resp.GetResponseStream()))
                        {
                            response = reader.ReadToEnd();
                            if (frmSettingDetails.oDbConnection != null)
                                frmSettingDetails.oDbConnection.SaveUserDetails(response);
                            else
                            {
                                DbConnection OdbConnection = new DbConnection();
                                OdbConnection.SaveUserDetails(response);
                            }
                            ret = true;
                        }
                        //var reader = new StreamReader(resp.GetResponseStream());
                    }
                }
            }
            catch (Exception ee)
            {
                int aa = 0;
                aa = 0;
                string msg = ee.Message;
            }

            return ret;

        }

    

        public bool callPurchaseOrderApi(int userId)
        {
            bool ret = false;

            var request = WebRequest.Create(CommonFunction.server_url + "/WDCAPI/GetPurchaseOrder/" + userId);
            request.ContentType = "application/json"; 
            request.Method = "GET";


            string response = "";//[{\"ID\":1,\"Vendor_ID\":1,\"Vendor_Name\":\"Cole\",\"Purchase_Order_Number\":\"PO000123\",\"DateOfPurchase\":\"9/5/2017 12:00:00 AM\",\"ExpectedDateOfDelivery\":\"9/6/2017 12:00:00 AM\",\"Actual_Received_Date\":\"\",\"Assigned_User\":\"6\",\"Status\":\"1\",\"View_PurchaseOrder_Item\":[{\"ID\":1,\"Item_ID\":1,\"Item_Name\":\"ITEM A\",\"Vender_ID\":0,\"PO_ID\":1,\"Quantity\":5.0,\"Cost_Per_Item\":50.0}]},{\"ID\":2,\"Vendor_ID\":1,\"Vendor_Name\":\"Cole\",\"Purchase_Order_Number\":\"PO0001\",\"DateOfPurchase\":\"9/21/2017 12:00:00 AM\",\"ExpectedDateOfDelivery\":\"9/28/2017 12:00:00 AM\",\"Actual_Received_Date\":\"\",\"Assigned_User\":\"6\",\"Status\":\"1\",\"View_PurchaseOrder_Item\":[{\"ID\":2,\"Item_ID\":1,\"Item_Name\":\"ITEM A\",\"Vender_ID\":0,\"PO_ID\":2,\"Quantity\":2.0,\"Cost_Per_Item\":10.0},{\"ID\":3,\"Item_ID\":2,\"Item_Name\":\"ITEM B\",\"Vender_ID\":0,\"PO_ID\":2,\"Quantity\":2.0,\"Cost_Per_Item\":0.0},{\"ID\":4,\"Item_ID\":3,\"Item_Name\":\"ITEM C\",\"Vender_ID\":0,\"PO_ID\":2,\"Quantity\":2.0,\"Cost_Per_Item\":10.0},{\"ID\":5,\"Item_ID\":4,\"Item_Name\":\"ITEM D\",\"Vender_ID\":0,\"PO_ID\":2,\"Quantity\":1.0,\"Cost_Per_Item\":10.0}]}]";
            try
            {
                using (WebResponse resp = request.GetResponse())
                {
                    if(resp == null)
                        new Exception("Response is null");

                    var re = resp.GetResponseStream();

                    if (resp.ContentLength > 0)
                    {
                        using (StreamReader reader = new StreamReader(resp.GetResponseStream()))
                        {
                            response = reader.ReadToEnd();
                            if (frmSettingDetails.oDbConnection != null)
                                frmSettingDetails.oDbConnection.SavePurchaseOrderDetails(response);
                            else
                            {
                                DbConnection OdbConnection = new DbConnection();
                                OdbConnection.SavePurchaseOrderDetails(response);
                            }
                            ret = true;
                        }
                    }

                }
            }
            catch (Exception ee)
            {

            }
            return ret;
          
       }

        public bool callSalesOrderApi(int userId)
        {
            bool ret = false;
            var request = WebRequest.Create(CommonFunction.server_url + "/WDCAPI/GetSalesOrder/" + userId);
            request.ContentType = "application/json";
            request.Method = "GET";


            string response = "";//"[{\"ID\":3,\"name\":\"Softdew Tech Pvt Ltd\",\"Customer_ID\":1,\"DateOfOrder\":\"13/09/2017\",\"ExpectedDateOfDelivery\":\"30/09/2017\",\"SalesOrderNo\":\"SO0001258\",\"Actual_Delivery_Date\":null,\"Status\":\"1\",\"Assigned_User\":\"18\",\"View_SalesOrder_Item\":[{\"ID\":4,\"Item_ID\":2,\"Item_Name\":\"ITEM B\",\"Quantity\":50.0,\"Cost_Per_Item\":500.0,\"SO_ID\":3},{\"ID\":5,\"Item_ID\":6,\"Item_Name\":\"ITEM F\",\"Quantity\":85.0,\"Cost_Per_Item\":650.0,\"SO_ID\":3}]},{\"ID\":4,\"name\":\"Softdew Tech Pvt Ltd\",\"Customer_ID\":1,\"DateOfOrder\":\"28/09/2017\",\"ExpectedDateOfDelivery\":\"30/09/2017\",\"SalesOrderNo\":\"SO001\",\"Actual_Delivery_Date\":\"01/01/001\",\"Status\":\"1\",\"Assigned_User\":\"18\",\"View_SalesOrder_Item\":[{\"ID\":6,\"Item_ID\":1,\"Item_Name\":\"ITEM A\",\"Quantity\":2.0,\"Cost_Per_Item\":10.0,\"SO_ID\":4},{\"ID\":7,\"Item_ID\":3,\"Item_Name\":\"ITEM C\",\"Quantity\":1.0,\"Cost_Per_Item\":10.0,\"SO_ID\":4},{\"ID\":8,\"Item_ID\":7,\"Item_Name\":\"ITEM G\",\"Quantity\":2.0,\"Cost_Per_Item\":100.0,\"SO_ID\":4}]}]";
            try
            {
                using (WebResponse resp = request.GetResponse())
                {
                    if (resp == null)
                        new Exception("Response is null");
                    var re = resp.GetResponseStream();

                    if (resp.ContentLength > 0)
                    {
                        using (StreamReader reader = new StreamReader(resp.GetResponseStream()))
                        {
                            response = reader.ReadToEnd();
                            if (frmSettingDetails.oDbConnection != null)
                                frmSettingDetails.oDbConnection.SaveSalesOrderDetails(response);
                            else
                            {
                                DbConnection OdbConnection = new DbConnection();
                                OdbConnection.SaveSalesOrderDetails(response);
                            }
                            ret = true;
                        }
                    }

                }
            }
            catch (Exception ee)
            {

            }
            return ret;
            
        }


        public bool callStockSheetApi(int userId)
        {
            bool ret = false;
            //will change api
            var request = WebRequest.Create(CommonFunction.server_url + "/WDCAPI/GetStockCountSheet/" + userId);
            request.ContentType = "application/json";
            request.Method = "GET";


            string response = "";//"[{\"ID\":2,\"name\":\"abc\",\"Status\":\"1\",\"Items\":[{\"Item_ID\":1,\"Stock_ID\":2},{\"Item_ID\":3,\"Stock_ID\":2}]}]";
            try
            {
                using (WebResponse resp = request.GetResponse())
                {
                    if (resp == null)
                        new Exception("Response is null");
                    var re = resp.GetResponseStream();

                    if (resp.ContentLength > 0)
                    {
                        using (StreamReader reader = new StreamReader(resp.GetResponseStream()))
                        {
                            response = reader.ReadToEnd();
                            if (frmSettingDetails.oDbConnection != null)
                                frmSettingDetails.oDbConnection.SaveStockDetails(response);
                            else
                            {
                                DbConnection OdbConnection = new DbConnection();
                                OdbConnection.SaveStockDetails(response);
                            }
                            ret = true;
                        }
                    }

                }
            }
            catch (Exception ee)
            {

            }
            return ret;
            
        }

        public bool callGetStockDetailsApiForItemList()
        {
            bool ret = false;
            var request = WebRequest.Create(CommonFunction.server_url + "/WDCAPI/GetStockDetails");
            request.ContentType = "application/json";
            request.Method = "GET";


            string str_ItemResponse = "";//"[{\"ID\":1,\"Item_No\":\"A123\",\"Item_Name\":\"ITEM A\",\"Description\":null,\"m_Stock_type_ID\":1,\"Quantity\":\"200\",\"Serial_No\":\"NA\",\"Batch_No\":\"NA\",\"Location_ID\":null,\"Sub_Location_ID\":null,\"m_Stock_Unit_ID\":1,\"m_stock_status_id\":1,\"Reorder_Level\":50.0,\"Current_Stock\":65.0,\"Cost_per_Item\":0.0,\"Created_By\":1,\"Date_of_Creation\":\"2017-06-06T19:18:04\"},{\"ID\":2,\"Item_No\":\"B123\",\"Item_Name\":\"ITEM B\",\"Description\":\"\",\"m_Stock_type_ID\":1,\"Quantity\":\"100\",\"Serial_No\":\"NA\",\"Batch_No\":\"NA\",\"Location_ID\":0,\"Sub_Location_ID\":0,\"m_Stock_Unit_ID\":1,\"m_stock_status_id\":1,\"Reorder_Level\":50.0,\"Current_Stock\":60.0,\"Cost_per_Item\":0.0,\"Created_By\":1,\"Date_of_Creation\":\"2017-06-06T19:22:44\"},{\"ID\":3,\"Item_No\":\"C123\",\"Item_Name\":\"ITEM C\",\"Description\":\"\",\"m_Stock_type_ID\":1,\"Quantity\":\"45\",\"Serial_No\":\"NA\",\"Batch_No\":\"NA\",\"Location_ID\":0,\"Sub_Location_ID\":0,\"m_Stock_Unit_ID\":1,\"m_stock_status_id\":2,\"Reorder_Level\":50.0,\"Current_Stock\":0.0,\"Cost_per_Item\":0.0,\"Created_By\":1,\"Date_of_Creation\":\"2017-06-06T19:22:44\"},{\"ID\":4,\"Item_No\":\"D123\",\"Item_Name\":\"ITEM D\",\"Description\":\"\",\"m_Stock_type_ID\":1,\"Quantity\":\"25\",\"Serial_No\":\"NA\",\"Batch_No\":\"NA\",\"Location_ID\":0,\"Sub_Location_ID\":0,\"m_Stock_Unit_ID\":1,\"m_stock_status_id\":2,\"Reorder_Level\":50.0,\"Current_Stock\":0.0,\"Cost_per_Item\":0.0,\"Created_By\":1,\"Date_of_Creation\":\"2017-06-06T19:22:44\"},{\"ID\":5,\"Item_No\":\"E123\",\"Item_Name\":\"ITEM E\",\"Description\":\"\",\"m_Stock_type_ID\":1,\"Quantity\":\"200\",\"Serial_No\":\"NA\",\"Batch_No\":\"NA\",\"Location_ID\":0,\"Sub_Location_ID\":0,\"m_Stock_Unit_ID\":1,\"m_stock_status_id\":1,\"Reorder_Level\":50.0,\"Current_Stock\":0.0,\"Cost_per_Item\":0.0,\"Created_By\":1,\"Date_of_Creation\":\"2017-06-06T19:22:44\"},{\"ID\":6,\"Item_No\":\"F123\",\"Item_Name\":\"ITEM F\",\"Description\":\"\",\"m_Stock_type_ID\":1,\"Quantity\":\"100\",\"Serial_No\":\"NA\",\"Batch_No\":\"NA\",\"Location_ID\":0,\"Sub_Location_ID\":0,\"m_Stock_Unit_ID\":1,\"m_stock_status_id\":1,\"Reorder_Level\":50.0,\"Current_Stock\":0.0,\"Cost_per_Item\":0.0,\"Created_By\":1,\"Date_of_Creation\":\"2017-06-06T19:22:45\"},{\"ID\":7,\"Item_No\":\"G123\",\"Item_Name\":\"ITEM G\",\"Description\":null,\"m_Stock_type_ID\":1,\"Quantity\":\"45\",\"Serial_No\":\"NA\",\"Batch_No\":\"NA\",\"Location_ID\":null,\"Sub_Location_ID\":null,\"m_Stock_Unit_ID\":1,\"m_stock_status_id\":1,\"Reorder_Level\":50.0,\"Current_Stock\":0.0,\"Cost_per_Item\":0.0,\"Created_By\":1,\"Date_of_Creation\":\"2017-06-06T19:22:45\"},{\"ID\":8,\"Item_No\":\"H123\",\"Item_Name\":\"ITEM H\",\"Description\":\"\",\"m_Stock_type_ID\":1,\"Quantity\":\"25\",\"Serial_No\":\"NA\",\"Batch_No\":\"NA\",\"Location_ID\":0,\"Sub_Location_ID\":0,\"m_Stock_Unit_ID\":1,\"m_stock_status_id\":2,\"Reorder_Level\":50.0,\"Current_Stock\":0.0,\"Cost_per_Item\":0.0,\"Created_By\":1,\"Date_of_Creation\":\"2017-06-06T19:22:45\"}]";
            try
            {
                using (WebResponse resp = request.GetResponse())
                {
                    if (resp == null)
                        new Exception("Response is null");

                    var re = resp.GetResponseStream();

                    if (resp.ContentLength > 0)
                    {
                        using (StreamReader reader = new StreamReader(resp.GetResponseStream()))
                        {
                            str_ItemResponse = reader.ReadToEnd();
                            if (frmSettingDetails.oDbConnection != null)
                            {
                                frmSettingDetails.oDbConnection.SaveItemsList(str_ItemResponse);
                            }
                            else
                            {
                                DbConnection OdbConnection = new DbConnection();
                                OdbConnection.SaveItemsList(str_ItemResponse);
                            }
                        }
                    }
                }
            }
            catch (Exception ee)
            {

            }

            return ret;          

         }

        public void postUserApi(string json)
        {

            var request = WebRequest.Create(CommonFunction.server_url + "/WDCAPI/GetUsers");
            request.ContentType = "application/json"; //your contentType, Json, text,etc. -- or comment, for text
            request.Method = "GET"; //method, GET, POST, etc -- or comment for GET

            // string response = "[{\"Claims\":[],\"Logins\":[],\"Roles\":[],\"Photo\":\"Chrysanthemum20170607180408133.jpg\",\"Name\":\"Naresh Baghel\",\"Code\":\"SFT0022\",\"Is_for_Mobile_Device\":1,\"Is_Active\":1,\"Email\":\"naresh@softdew.co.in\",\"EmailConfirmed\":false,\"PasswordHash\":\"AGVGQ+rmKAONa/0WFdE7w0Q5RFgN2bb4nooW3WhFLxmH3EO1YmnurlBLkR6aOg2N8w==\",\"SecurityStamp\":\"633da25c-fd39-48eb-a70c-810906f945f5\",\"PhoneNumber\":null,\"PhoneNumberConfirmed\":false,\"TwoFactorEnabled\":false,\"LockoutEndDateUtc\":null,\"LockoutEnabled\":true,\"AccessFailedCount\":0,\"Id\":\"6\",\"UserName\":\"naresh@softdew.co.in\"},{\"Claims\":[],\"Logins\":[],\"Roles\":[],\"Photo\":null,\"Name\":\"Naresh Baghel\",\"Code\":\"SFT0021\",\"Is_for_Mobile_Device\":1,\"Is_Active\":1,\"Email\":\"n@h.com\",\"EmailConfirmed\":false,\"PasswordHash\":\"AJZHP73xDe7U13EICkEOD6zqjeRN8nrmWqtPQo5O1QWQ6WdoYJtMj0YjkrrSQGfGIA==\",\"SecurityStamp\":\"95ab8cf8-4d1e-4267-a729-143c5423199c\",\"PhoneNumber\":null,\"PhoneNumberConfirmed\":false,\"TwoFactorEnabled\":false,\"LockoutEndDateUtc\":null,\"LockoutEnabled\":true,\"AccessFailedCount\":0,\"Id\":\"9\",\"UserName\":\"n@h.com\"},{\"Claims\":[],\"Logins\":[],\"Roles\":[],\"Photo\":null,\"Name\":\"Naresh \",\"Code\":\"ATS001\",\"Is_for_Mobile_Device\":1,\"Is_Active\":1,\"Email\":\"baghel3349@gmail.com\",\"EmailConfirmed\":false,\"PasswordHash\":\"AEfx5oK+easabrzUHfk6adHh5+EGr2sDCd3MpEqxIcqOtLzhBY7cq9z0f8pOEdn7BQ==\",\"SecurityStamp\":\"f4762de7-de2c-442d-ac3c-70e1ac6b853c\",\"PhoneNumber\":null,\"PhoneNumberConfirmed\":false,\"TwoFactorEnabled\":false,\"LockoutEndDateUtc\":null,\"LockoutEnabled\":true,\"AccessFailedCount\":0,\"Id\":\"18\",\"UserName\":\"baghel3349@gmail.com\"}]";
            string response = "";//"[{\"Claims\":[],\"Logins\":[],\"Roles\":[],\"Password\":\"12345\",\"Photo\":\"Chrysanthemum20170607180408133.jpg\",\"Name\":\"Naresh Baghel\",\"Code\":\"SFT0022\",\"Is_for_Mobile_Device\":1,\"Is_Active\":1,\"Email\":\"naresh@softdew.co.in\",\"EmailConfirmed\":false,\"PasswordHash\":\"AGVGQ+rmKAONa/0WFdE7w0Q5RFgN2bb4nooW3WhFLxmH3EO1YmnurlBLkR6aOg2N8w==\",\"SecurityStamp\":\"633da25c-fd39-48eb-a70c-810906f945f5\",\"PhoneNumber\":null,\"PhoneNumberConfirmed\":false,\"TwoFactorEnabled\":false,\"LockoutEndDateUtc\":null,\"LockoutEnabled\":true,\"AccessFailedCount\":0,\"Id\":\"6\",\"UserName\":\"naresh\"},{\"Claims\":[],\"Logins\":[],\"Roles\":[],\"Password\":\"7835909031\",\"Photo\":null,\"Name\":\"Naresh Baghel\",\"Code\":\"SFT0021\",\"Is_for_Mobile_Device\":1,\"Is_Active\":1,\"Email\":\"n@h.com\",\"EmailConfirmed\":false,\"PasswordHash\":\"AJZHP73xDe7U13EICkEOD6zqjeRN8nrmWqtPQo5O1QWQ6WdoYJtMj0YjkrrSQGfGIA==\",\"SecurityStamp\":\"95ab8cf8-4d1e-4267-a729-143c5423199c\",\"PhoneNumber\":null,\"PhoneNumberConfirmed\":false,\"TwoFactorEnabled\":false,\"LockoutEndDateUtc\":null,\"LockoutEnabled\":true,\"AccessFailedCount\":0,\"Id\":\"9\",\"UserName\":\"n@h.com\"},{\"Claims\":[],\"Logins\":[],\"Roles\":[],\"Password\":\"7835909031\",\"Photo\":null,\"Name\":\"Naresh \",\"Code\":\"ATS001\",\"Is_for_Mobile_Device\":1,\"Is_Active\":1,\"Email\":\"baghel3349@gmail.com\",\"EmailConfirmed\":false,\"PasswordHash\":\"AEfx5oK+easabrzUHfk6adHh5+EGr2sDCd3MpEqxIcqOtLzhBY7cq9z0f8pOEdn7BQ==\",\"SecurityStamp\":\"f4762de7-de2c-442d-ac3c-70e1ac6b853c\",\"PhoneNumber\":null,\"PhoneNumberConfirmed\":false,\"TwoFactorEnabled\":false,\"LockoutEndDateUtc\":null,\"LockoutEnabled\":true,\"AccessFailedCount\":0,\"Id\":\"18\",\"UserName\":\"baghel3349@gmail.com\"}]";
            try
            {
                using (WebResponse resp = request.GetResponse())
                {
                    if (resp == null)
                        new Exception("Response is null");

                    if (resp.ContentLength > 0)
                    {
                        using (StreamReader reader = new StreamReader(resp.GetResponseStream()))
                        {
                            response = reader.ReadToEnd();
                            frmSettingDetails.oDbConnection.SaveUserDetails(response);
                        }
                    }

                }
            }
            catch (Exception ee)
            {

            }

         

        }

        public List<POApiResponse> postPurchaseOrderApi(string json)
        {
            bool ret = false;
           
            string response = "";
            try
            {

                var request = WebRequest.Create(CommonFunction.server_url + "/WDCAPI/PostPurchaseOrder/");
                request.ContentType = "application/json";
                request.Method = "POST";
                request.ContentLength = json.Length;

                using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                {

                    streamWriter.Write(json);
                    streamWriter.Flush();
                    streamWriter.Close();
                }

                using (WebResponse resp = request.GetResponse())
                {
                    if (resp == null)
                        new Exception("Response is null");

                    if (resp.ContentLength > 0)
                    {
                        using (StreamReader reader = new StreamReader(resp.GetResponseStream()))
                        {
                            response = reader.ReadToEnd();
                           // response = "[{\"PO_ID\":\"1\",\"Status\":\"true\"},{\"PO\":\"2\",\"status\":\"true\"}]";
                            listApiPORet = JsonConvert.DeserializeObject<List<POApiResponse>>(response);
                            //if(response == "true")
                            //{
                            //    ret = true;
                            //}
                            //else
                            //{
                            //    ret = false;
                            //}
                           
                        }
                    }

                }
            }
            catch (Exception ex1)
            {
                response = "[{\"PO_ID\":\"1\",\"Status\":\"true\",\"Message\":\"not applcable\"},{\"PO\":\"2\",\"status\":\"true\",\"Message\":\"not applcable\"}]";
                listApiPORet = JsonConvert.DeserializeObject<List<POApiResponse>>(response);
                response = "";
                int a = 0;
                a++;
                string aa = ex1.Message;
                throw;
            }

            return listApiPORet;
        }


        public List<SOApiResponse> postSalesOrderApi(string json)
        {
           
            bool ret = false;

            string response = "";
            try
            {

                var request = WebRequest.Create(CommonFunction.server_url + "/WDCAPI/PostSalesOrder/");
                request.ContentType = "application/json";
                request.Method = "POST";
                request.ContentLength = json.Length;

                using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                {

                    streamWriter.Write(json);
                    streamWriter.Flush();
                    streamWriter.Close();
                }

                using (WebResponse resp = request.GetResponse())
                {
                    if (resp == null)
                        new Exception("Response is null");

                    if(resp.ContentLength > 0)
                    {
                        using (StreamReader reader = new StreamReader(resp.GetResponseStream()))
                        {
                            response = reader.ReadToEnd();
                            listApiSORet = JsonConvert.DeserializeObject<List<SOApiResponse>>(response);
                            ret = true;
                        }
                    }

                }
            }
            catch (Exception ex1)
            {
                response = "[{\"SO_ID\":\"1\",\"Status\":\"true\",\"Message\":\"not applcable\"},{\"SO_ID\":\"2\",\"status\":\"true\",\"Message\":\"not applcable\"}]";
                listApiSORet = JsonConvert.DeserializeObject<List<SOApiResponse>>(response);

                int a = 0;
                a++;
                string aa = ex1.Message;
                throw;

            }

            return listApiSORet;
          
        }

        public List<StockApiResponse>  postStockOrderApi(string json)
        {

          
            bool ret = false;
            string response = "";
            try
            {

                var request = WebRequest.Create(CommonFunction.server_url + "/WDCAPI/PostStockCountSheet/");
                request.ContentType = "application/json";
                request.Method = "POST";
                request.ContentLength = json.Length;

                using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                {

                    streamWriter.Write(json);
                    streamWriter.Flush();
                    streamWriter.Close();
                }

                using (WebResponse resp = request.GetResponse())
                {
                    if (resp == null)
                        new Exception("Response is null");

                    if (resp.ContentLength > 0)
                    {
                        using (StreamReader reader = new StreamReader(resp.GetResponseStream()))
                        {
                            response = reader.ReadToEnd();
                            listApiStockRet = JsonConvert.DeserializeObject<List<StockApiResponse>>(response);
                            ret = true;
                        }
                    }

                }
            }
            catch (Exception ex1)
            {
                response = "[{\"Stock_id\":\"1\",\"Status\":\"true\",\"Message\":\"not applcable\"},{\"Stock_id\":\"2\",\"status\":\"true\",\"Message\":\"not applcable\"}]";
                listApiStockRet = JsonConvert.DeserializeObject<List<StockApiResponse>>(response);
                int a = 0;
                a++;
                string aa = ex1.Message;
                throw;

            }
            return listApiStockRet;
           
        }       
      
    }
}
