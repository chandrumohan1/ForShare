﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlServerCe;
using WDC.Utility;
using Newtonsoft.Json;
using System.Data;
using System.Globalization;

namespace WDC.Utility
{
    public class DbConnection
    {
        public string conSTR = "Data Source=" +
          (System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase)) +
          "\\dbWDC.sdf;Persist Security Info=False";
        SqlCeConnection dbCon = null;
        SqlCeCommand dbCmd = null;
        CommonFunction oCommonfunction = null;
       public static List<getPoName> listPoName = new List<getPoName>();
       public static List<getSoName> listSoName = new List<getSoName>();
       public static List<getStockName> listStockName = new List<getStockName>();
        //WDCApiFunction oWDCApi = null;
        int count = 0;
        public DbConnection()
        {
            //oWDCApi = obj; // new WDCApiFunction();
            dbCon = new SqlCeConnection(conSTR);
            oCommonfunction = new CommonFunction();
        }


        public void SaveUserDetails(string response)
        {
            if(response == "")
               return;
            try
            {
                var getUserDetails = JsonConvert.DeserializeObject<List<UserDetails>>(response);

                foreach (var Item in getUserDetails)
                {
                    if (Item == null)
                        continue;

                    //if details is already exist for server_id the user info will update 
                    string query = oCommonfunction.getDbQuery("CheckUser");
                    dbCmd = new SqlCeCommand(query, dbCon);
                    dbCmd.Parameters.Add("@server_id", Item.Id);
                    oCommonfunction.db_connection_open(dbCon);
                    SqlCeDataReader dr = dbCmd.ExecuteReader();
                    if (dr.Read())
                    {
                        dbCmd.Dispose();
                        dr.Dispose();

                        string userUpdatequery = oCommonfunction.getDbQuery("UpdateUser");
                        dbCmd = new SqlCeCommand(userUpdatequery, dbCon);
                        dbCmd.Parameters.Add("@server_id", Item.Id);
                        dbCmd.Parameters.Add("@UserName", Item.UserName);
                        dbCmd.Parameters.Add("@Password", Item.Password);
                        dbCmd.Parameters.Add("@Email", Item.Email);//status
                        dbCmd.Parameters.Add("@status",1);
                        int ret = dbCmd.ExecuteNonQuery();
                        if (ret < 1)
                        {
                            dbCmd.Dispose();
                            //throw "not Added";
                            oCommonfunction.WriteExceptionLog("ret = " + ret, "user is going to Update");
                        }
                        else
                        {
                            dbCmd.Dispose();
                        }
                    }
                    else
                    {
                        string userSavequery = oCommonfunction.getDbQuery("SaveAllUser");
                        dbCmd = new SqlCeCommand(userSavequery, dbCon);
                        dbCmd.Parameters.Add("@server_id", Item.Id);
                        dbCmd.Parameters.Add("@UserName", Item.UserName);
                        dbCmd.Parameters.Add("@Password", Item.Password);
                        dbCmd.Parameters.Add("@Email", Item.Email);
                        dbCmd.Parameters.Add("@status", 1);
                        int ret = dbCmd.ExecuteNonQuery();
                        if (ret < 1)
                        {
                            dbCmd.Dispose();
                            //write Exception
                            oCommonfunction.WriteExceptionLog("ret = " + ret, "user is going to Add");
                        }
                        else
                        {
                            dbCmd.Dispose();
                        }

                    }
                    oCommonfunction.db_connection_close(dbCon);
                }
            }
            catch (Exception ex)
            {

                string ExMessage = ex.InnerException.Message.ToString();
                throw;
            }

        }


        public void SaveItemsList(string response)
        {
            if(response == "")
                return;
            try
            {
                var getItemDetails = JsonConvert.DeserializeObject<ItemDetails>(response);

                //foreach (var Item in getItemDetails)
                {
                   // if (Item == null)
                     //   continue;

                    foreach(var getStock in getItemDetails.stock)
                    {
                        if (getStock == null)
                        continue;

                        string query = "SELECT COUNT(*) FROM ItemDetails WHERE server_id=" + getStock.ID;
                        dbCmd = new SqlCeCommand(query, dbCon);
                        oCommonfunction.db_connection_open(dbCon);
                        count = (Int32)dbCmd.ExecuteScalar();
                        dbCmd.Dispose();
                        if(count > 0)
                        {
                            oCommonfunction.db_connection_close(dbCon);
                            continue;
                        }


                        string add_item_details = oCommonfunction.getDbQuery("AddItemList");
                        string description = "";
                        if (getStock.Description == null && getStock.Description == "")
                            description = "";
                        else
                            description = getStock.Description;


                        int Location_ID = 0;
                        int SubLocation_Id = 0;

                        if (Convert.ToString(getStock.Location_ID) == null)
                            Location_ID = 0;
                        else
                            Location_ID = Convert.ToInt32(getStock.Location_ID);

                        if (Convert.ToString(getStock.Sub_Location_ID) == null)
                            SubLocation_Id = 0;
                        else
                            SubLocation_Id = Convert.ToInt32(getStock.Sub_Location_ID);


                        dbCmd = new SqlCeCommand(add_item_details, dbCon);
                        dbCmd.Parameters.Add("@server_id", Convert.ToInt32(getStock.ID));
                        dbCmd.Parameters.Add("@item_no", getStock.Item_No);
                        dbCmd.Parameters.Add("@item_name", getStock.Item_Name);
                        dbCmd.Parameters.Add("@description", description);
                        dbCmd.Parameters.Add("@m_stock_type_id", Convert.ToInt32(getStock.m_Stock_type_ID));
                      //  dbCmd.Parameters.Add("@quantity", getStock.Quantity);
                       // dbCmd.Parameters.Add("@serial_no", getStock.Serial_No);
                       // dbCmd.Parameters.Add("@batch_no", getStock.Batch_No);
                        dbCmd.Parameters.Add("@location_id", Location_ID);
                        dbCmd.Parameters.Add("@sub_location_id", SubLocation_Id);
                        dbCmd.Parameters.Add("@m_stock_unit_id", Convert.ToInt32(getStock.m_Stock_Unit_ID));
                        dbCmd.Parameters.Add("@m_stock_status_id", Convert.ToInt32(getStock.m_stock_status_id));
                        dbCmd.Parameters.Add("@recorder_label", Convert.ToInt32(getStock.Reorder_Level));
                        dbCmd.Parameters.Add("@current_stock", Convert.ToInt32(getStock.Current_Stock));
                        dbCmd.Parameters.Add("@cost_per_item", Convert.ToInt32(getStock.Cost_per_Item));
                        int ret = dbCmd.ExecuteNonQuery();
                        if (ret < 1)
                        {
                            dbCmd.Dispose();
                            oCommonfunction.WriteExceptionLog("ret = " + ret, "add item details ");
                        }
                        dbCmd.Dispose();
                        oCommonfunction.db_connection_close(dbCon);
                    }


                    foreach (var getLocation in getItemDetails.location)
                    {
                        if (getLocation == null)
                            continue;

                        string query = "SELECT COUNT(*) FROM tblLocationDetails WHERE ID=" + getLocation.ID;
                        dbCmd = new SqlCeCommand(query, dbCon);
                        oCommonfunction.db_connection_open(dbCon);
                        count = (Int32)dbCmd.ExecuteScalar();
                        dbCmd.Dispose();
                        if (count > 0)
                        {
                            oCommonfunction.db_connection_close(dbCon);
                            continue;
                        }


                        string add_location = "INSERT INTO tblLocationDetails (ID,Area,Parent_ID,Date_of_Creation)VALUES(@ID,@Area,@Parent_ID,@Date_of_Creation)";

                        DateTime dt = Convert.ToDateTime(getLocation.Date_of_Creation);
                      
                        dbCmd = new SqlCeCommand(add_location, dbCon);
                        dbCmd.Parameters.Add("@ID", Convert.ToInt32(getLocation.ID));
                        dbCmd.Parameters.Add("@Area", getLocation.Area);
                        dbCmd.Parameters.Add("@Parent_ID", getLocation.Parent_ID);
                        dbCmd.Parameters.Add("@Date_of_Creation", dt);
                        int ret = dbCmd.ExecuteNonQuery();
                        if (ret < 1)
                        {
                            dbCmd.Dispose();
                            oCommonfunction.WriteExceptionLog("ret = " + ret, "add item details ");
                        }
                        oCommonfunction.db_connection_close(dbCon);
                    }

                }
            }
            catch (Exception ex)
            {
                oCommonfunction.db_connection_close(dbCon);
                string ExMessage = ex.InnerException.Message.ToString();
                throw;
            }

        }


        public void SavePurchaseOrderDetails(string response)
        {
            if (response == "")
                return;

            try
            {
             
                var getPurchaseDetails = JsonConvert.DeserializeObject<List<PurchaseOrderDetails>>(response);

                foreach (var Item in getPurchaseDetails)
                {
                    if (Item == null)
                        continue;

                    CommonFunction.poCount = 0;

                    string query = "SELECT COUNT(*) FROM tblPurchaseOrder WHERE PO_server_id=" + Item.ID;
                    dbCmd = new SqlCeCommand(query, dbCon);
                    oCommonfunction.db_connection_open(dbCon);
                    count = (Int32)dbCmd.ExecuteScalar();
                    dbCmd.Dispose();
                    if (count == 0)
                    {
                        DateTime dtPurchase = new DateTime();
                        try
                        {
                            dtPurchase = DateTime.Parse(Item.DateOfPurchase);
                        }
                        catch (Exception e)
                        {
                            dtPurchase = DateTime.Now;
                        }
                        DateTime dtExpectedDate = new DateTime();
                        try
                        {
                            dtExpectedDate = DateTime.Parse(Item.ExpectedDateOfDelivery);
                        }
                        catch (Exception e)
                        {
                            dtExpectedDate = DateTime.Now;
                        }

                        string add_item_details = oCommonfunction.getDbQuery("AddPurchaseList");
                        dbCmd = new SqlCeCommand(add_item_details, dbCon);
                        dbCmd.Parameters.Add("@PO_server_id", Item.ID);
                        dbCmd.Parameters.Add("@purchase_order_no", Item.Purchase_Order_Number);
                        dbCmd.Parameters.Add("@date_of_purchase", dtPurchase);
                        dbCmd.Parameters.Add("@expected_delivery_date", dtExpectedDate);
                        dbCmd.Parameters.Add("@assigned_user", Item.Assigned_User);
                        dbCmd.Parameters.Add("@server_status", Item.Status);
                        dbCmd.Parameters.Add("@phone_status", 1);//pending
                        dbCmd.Parameters.Add("@Vendor_ID", Item.Vendor_Id);
                        dbCmd.Parameters.Add("@Vendor_Name", Item.Vendor_Name);
                        int ret = dbCmd.ExecuteNonQuery();
                        if(ret > 0)
                        {
                            dbCmd.Dispose();
                           /* getPoName obj = new getPoName();
                            obj.id =Convert.ToInt32(Item.ID);
                            obj.OrderNo = Item.Purchase_Order_Number;
                            listPoName.Add(obj);*/
                            CommonFunction.poCount++;
                        }
                        else
                        {
                            dbCmd.Dispose();
                            oCommonfunction.WriteExceptionLog("ret = " + ret, "add purchase order details ");
                        }
                        //add item list for this purchase order 
                        foreach (var getData in Item.View_PurchaseOrder_Item)
                        {
                            if (getData == null)
                                continue;

                            string add_purchaseitem_details = oCommonfunction.getDbQuery("AddPurchaseOrderItem");
                            dbCmd = new SqlCeCommand(add_purchaseitem_details, dbCon);
                            dbCmd.Parameters.Add("@id", getData.ID);
                            dbCmd.Parameters.Add("@Item_ID", getData.Item_ID);
                            dbCmd.Parameters.Add("@Item_Name", getData.Item_Name);
                            dbCmd.Parameters.Add("@PO_ID", getData.PO_ID);
                            dbCmd.Parameters.Add("@Quantity", getData.Quantity);
                            dbCmd.Parameters.Add("@Vender_ID", getData.Vender_ID);
                            dbCmd.Parameters.Add("@total_quantity","");
                            int ret1 = dbCmd.ExecuteNonQuery();
                            if (ret1 > 0)
                            {
                                dbCmd.Dispose();
                            }
                            else
                            {
                                dbCmd.Dispose();
                                oCommonfunction.WriteExceptionLog("ret = " + ret, "add purchase order item details ");
                            }
                        }
                    }

                   
                    oCommonfunction.db_connection_close(dbCon);
                   
                }
               
            }
            catch (Exception ex)
            {
                oCommonfunction.db_connection_close(dbCon);
                string ExMessage = ex.InnerException.Message.ToString();
                throw;
            }

        }

        public void SaveSalesOrderDetails(string response)
        {
            if (response == "")
                return;
            try
            {
                CommonFunction.soCount = 0;
                var getSalesOrderDetails = JsonConvert.DeserializeObject<List<SalesOrderDetails>>(response);

                foreach (var Item in getSalesOrderDetails)
                {
                    if (Item == null)
                        continue;
                    string query = "SELECT COUNT(*) FROM tblSalesOrder WHERE ID=" + Item.ID;
                    dbCmd = new SqlCeCommand(query, dbCon);
                    oCommonfunction.db_connection_open(dbCon);
                    count = (Int32)dbCmd.ExecuteScalar();
                    dbCmd.Dispose();
                    if(count == 0)
                    {
                        string str_dateofpurchase = Item.DateOfOrder;// +" 12:00:00 AM";
                        string str_expecteddate = Item.ExpectedDateOfDelivery + " 12:00:00 AM";
                        DateTime dt_date_of_order = DateTime.ParseExact(Item.DateOfOrder, "MM/dd/yyyy", CultureInfo.InvariantCulture);
                        DateTime dt_expected_date = DateTime.ParseExact(Item.ExpectedDateOfDelivery, "MM/dd/yyyy", CultureInfo.InvariantCulture);

                        string add_item_details = oCommonfunction.getDbQuery("AddSalesOrderList");
                        dbCmd = new SqlCeCommand(add_item_details, dbCon);
                        dbCmd.Parameters.Add("@ID", Item.ID);
                        dbCmd.Parameters.Add("@name", Item.name);
                        dbCmd.Parameters.Add("@Customer_ID", Item.Customer_ID);
                        dbCmd.Parameters.Add("@DateOfOrder", dt_date_of_order);
                        dbCmd.Parameters.Add("@ExpectedDateOfDelivery", dt_expected_date);
                        dbCmd.Parameters.Add("@SalesOrderNo", Item.SalesOrderNo);
                        dbCmd.Parameters.Add("@Status", Item.Status);
                        dbCmd.Parameters.Add("@phone_status", 1);//pending
                        dbCmd.Parameters.Add("@total_quantity","");//pending

                        int ret = dbCmd.ExecuteNonQuery();
                        if (ret > 0)
                        {
                            dbCmd.Dispose();
                          /*  getSoName obj = new getSoName();
                            obj.id = Convert.ToInt32(Item.ID);
                            obj.OrderNo = Item.SalesOrderNo;
                            listSoName.Add(obj);*/
                            CommonFunction.soCount++;

                        }
                        else
                        {
                            dbCmd.Dispose();
                            oCommonfunction.WriteExceptionLog("ret = " + ret, "add sales order details ");
                        }
                        //add item list for this purchase order 
                        foreach (var getData in Item.View_SalesOrder_Item)
                        {
                            if (getData == null)
                                continue;

                            string add_salesitem_details = oCommonfunction.getDbQuery("AddSalesOrderItem");
                            dbCmd = new SqlCeCommand(add_salesitem_details, dbCon);
                            dbCmd.Parameters.Add("@ID", getData.ID);
                            dbCmd.Parameters.Add("@Item_ID", getData.Item_ID);
                            dbCmd.Parameters.Add("@Item_Name", getData.Item_Name);
                            dbCmd.Parameters.Add("@Quantity", getData.Quantity);
                            dbCmd.Parameters.Add("@Cost_Per_Item", getData.Quantity);
                            dbCmd.Parameters.Add("@SO_ID", getData.SO_ID);
                            dbCmd.Parameters.Add("@total_quantity", "");
                            int ret1 = dbCmd.ExecuteNonQuery();
                            if (ret1 > 0)
                            {
                                dbCmd.Dispose();
                            }
                            else
                            {
                                dbCmd.Dispose();
                                oCommonfunction.WriteExceptionLog("ret = " + ret, "add sales order item details ");
                            }
                        }
                    }                   
                    oCommonfunction.db_connection_close(dbCon);

                }

            }
            catch (Exception ex)
            {
                oCommonfunction.db_connection_close(dbCon);
                string ExMessage = ex.InnerException.Message.ToString();
                throw;
            }

        }


        public void SaveStockDetails(string response)
        {
            if (response == "")
                return;
            try
            {
                
                var getStockDetails = JsonConvert.DeserializeObject<List<StockCountDetails>>(response);

                foreach (var Item in getStockDetails)
                {
                    if (Item == null)
                        continue;
                    CommonFunction.stockCount = 0;
                    string query = "SELECT COUNT(*) FROM tblStockCountSheet WHERE id=" + Item.ID;
                    dbCmd = new SqlCeCommand(query, dbCon);
                    oCommonfunction.db_connection_open(dbCon);
                    count = (Int32)dbCmd.ExecuteScalar();
                    dbCmd.Dispose();
                    if (count == 0)
                    {

                        string add_stock = oCommonfunction.getDbQuery("AddStockDetails");
                        dbCmd = new SqlCeCommand(add_stock, dbCon);
                        dbCmd.Parameters.Add("@id", Item.ID);
                        dbCmd.Parameters.Add("@name", Item.Name);
                        dbCmd.Parameters.Add("@status", Item.Status);
                        dbCmd.Parameters.Add("@phone_status", 1);//pending
                        int ret = dbCmd.ExecuteNonQuery();
                        if (ret > 0)
                        {
                            dbCmd.Dispose();
                          /*  getStockName obj = new getStockName();
                            obj.id = Convert.ToInt32(Item.ID);
                            obj.StockName = Item.Name;
                            listStockName.Add(obj);*/
                            CommonFunction.stockCount++;
                             
                        }
                        else
                        {
                            dbCmd.Dispose();
                            oCommonfunction.WriteExceptionLog("ret = " + ret, "add stock details ");
                        }
                        //add item list for this purchase order 
                        foreach (var getData in Item.Items)
                        {
                            if (getData == null)
                                continue;
                            //@ID,@item_id,@item_Name,@stock_id,@Qunatity,@Cost_Per_Item
                            string add_stock_item = oCommonfunction.getDbQuery("AddStockItemDetails");
                            dbCmd = new SqlCeCommand(add_stock_item, dbCon);
                            dbCmd.Parameters.Add("@item_id", getData.Item_ID);
                            dbCmd.Parameters.Add("@stock_id", getData.Stock_ID);
                            dbCmd.Parameters.Add("@stock_sheet_id",Item.ID);
                            dbCmd.Parameters.Add("@total_quantity", "");
                            int ret1 = dbCmd.ExecuteNonQuery();
                            if (ret1 > 0)
                            {
                                dbCmd.Dispose();
                            }
                            else
                            {
                                dbCmd.Dispose();
                                oCommonfunction.WriteExceptionLog("ret = " + ret, "add stock item details ");
                            }
                        }//end foreach
                    }//end if
                    oCommonfunction.db_connection_close(dbCon);

                }

            }
            catch (Exception ex)
            {
                oCommonfunction.db_connection_close(dbCon);
                string ExMessage = ex.InnerException.Message.ToString();
                throw;
            }

        }

        public DataTable getPurchaseOrderDetails()
        {
            DataTable dt = new DataTable();
            string str_purchase_query = @"SELECT tblPurchaseOrder.PO_server_id,tblPurchaseOrder.purchase_order_no,
                                            tblPurchaseOrder.date_of_purchase,tblPurchaseOrder.expected_delivery_date,tblPurchaseOrder.assigned_user
                                            ,tblPurchaseOrder.server_status, tblPurchaseOrder.phone_status,tblPurchaseOrder.Vendor_ID,
                                            tblPurchaseOrder.Vendor_Name FROM tblPurchaseOrder";

            dbCmd = new SqlCeCommand(str_purchase_query, dbCon);
            SqlCeDataAdapter Da = new SqlCeDataAdapter(dbCmd);
            oCommonfunction.db_connection_open(dbCon);
            SqlCeDataAdapter Sda = new SqlCeDataAdapter(dbCmd);
            Sda.Fill(dt);
            dbCmd.Dispose();
            oCommonfunction.db_connection_close(dbCon);
            return dt;
            
         }

        public DataTable getPurchaseOrderItemDetails(string purchase_order_no)
        {
            //get purchase order no details and find the id 
          
            DataTable dt = new DataTable();
            if(!string.IsNullOrEmpty(purchase_order_no))
            {
                

                string str_purchase_order_query = @"SELECT tblPurchaseOrder.PO_server_id,tblPurchaseOrder.purchase_order_no,
                                            tblPurchaseOrder.date_of_purchase,tblPurchaseOrder.expected_delivery_date,tblPurchaseOrder.assigned_user
                                            ,tblPurchaseOrder.server_status, tblPurchaseOrder.phone_status,tblPurchaseOrder.Vendor_ID,tblPurchaseOrder.remarks,
                                            tblPurchaseOrder.Vendor_Name FROM tblPurchaseOrder WHERE tblPurchaseOrder.Vendor_Name +'(' + tblPurchaseOrder.purchase_order_no +')' LIKE '%" + purchase_order_no + "%'";

                dbCmd = new SqlCeCommand(str_purchase_order_query, dbCon);
                oCommonfunction.db_connection_open(dbCon);
                SqlCeDataReader dr = dbCmd.ExecuteReader();
                if(dr.Read())
                {
                    //get purchase order id
                    int Po_id = Convert.ToInt32(dr["PO_server_id"].ToString());
                    CommonFunction.Po_remarks   = Convert.ToString(dr["remarks"].ToString());
                    dr.Dispose();                  
                    string get_item_query = @"SELECT tblPurchaseOrderItem.id ,tblPurchaseOrderItem.Item_ID
                                                 ,tblPurchaseOrderItem.Item_Name,tblPurchaseOrderItem.PO_ID
                                                 ,tblPurchaseOrderItem.Quantity,tblPurchaseOrderItem.Vender_ID
                                                 ,ItemDetails.server_id,ItemDetails.item_no,ItemDetails.item_name,ItemDetails.m_stock_type_id
                                                 ,tblPurchaseOrderItem.rcd_quntity,tblPurchaseOrderItem.batch_no,tblPurchaseOrderItem.serial_no
                                                  ,tblPurchaseOrderItem.total_quantity from tblPurchaseOrderItem INNER JOIN ItemDetails
                                                  ON tblPurchaseOrderItem.Item_ID = ItemDetails.server_id WHERE tblPurchaseOrderItem.PO_ID =" + Po_id;

                    dbCmd = new SqlCeCommand(get_item_query, dbCon);
                    SqlCeDataAdapter Sda = new SqlCeDataAdapter(dbCmd);
                    Sda.Fill(dt);
                    dbCmd.Dispose();
                    Sda.Dispose();
                }
                oCommonfunction.db_connection_close(dbCon);
            }
            return dt;

        }

        public int getPurchaseOrderItemCount(int PO_id)
        {
            int count = 0;
            string str_purchase_query = @"SELECT COUNT(*) FROM tblPurchaseOrderItem WHERE PO_ID =" + PO_id;
            dbCmd = new SqlCeCommand(str_purchase_query, dbCon);
            oCommonfunction.db_connection_open(dbCon);
            count = (Int32)dbCmd.ExecuteScalar();  
            oCommonfunction.db_connection_close(dbCon);
            return count;

        }

        public DataTable getStockDetails()
        {
            DataTable dt = new DataTable();
            string str_purchase_query = @"SELECT tblStockCountSheet.id,tblStockCountSheet.name
                                            ,tblStockCountSheet.status,tblStockCountSheet.phone_status 
                                            FROM tblStockCountSheet";

            dbCmd = new SqlCeCommand(str_purchase_query, dbCon);
            SqlCeDataAdapter Da = new SqlCeDataAdapter(dbCmd);
            oCommonfunction.db_connection_open(dbCon);
            SqlCeDataAdapter Sda = new SqlCeDataAdapter(dbCmd);
            Sda.Fill(dt);
            dbCmd.Dispose();
            oCommonfunction.db_connection_close(dbCon);
            return dt;

        }

        public DataTable getStockItemDetails(int Stock_id)
        {
            string str_query = @"SELECT tblStockCountSheet.id,tblStockCountSheet.name,
                                        tblStockCountSheet.status,tblStockCountSheet.phone_status,tblStockCountSheet.remarks
                                        FROM tblStockCountSheet WHERE tblStockCountSheet.id=" + Stock_id;

            dbCmd = new SqlCeCommand(str_query, dbCon);
            oCommonfunction.db_connection_open(dbCon);
            SqlCeDataReader dr = dbCmd.ExecuteReader();
            if (dr.Read())
            {
                CommonFunction.stock_remarks = Convert.ToString(dr["remarks"]);
            }
            dbCmd.Dispose();
            dr.Dispose();
           
            DataTable dt = new DataTable();
            string get_item_query = @"SELECT tblStockItemCount.item_id ,tblStockItemCount.quantity,tblStockItemCount.rcd_quntity
                                     ,tblStockItemCount.stock_id,tblStockItemCount.batch_no,tblStockItemCount.serial_no
                                     ,ItemDetails.server_id,ItemDetails.item_no,tblStockItemCount.total_quantity
                                     ,ItemDetails.item_name,ItemDetails.m_stock_type_id                                  
                                      from tblStockItemCount INNER JOIN ItemDetails
                                      ON tblStockItemCount.item_id = ItemDetails.server_id 
                                      WHERE tblStockItemCount.stock_sheet_id =" + Stock_id;

            dbCmd = new SqlCeCommand(get_item_query, dbCon);
            SqlCeDataAdapter Sda = new SqlCeDataAdapter(dbCmd);
            Sda.Fill(dt);
            dbCmd.Dispose();
            Sda.Dispose();
            oCommonfunction.db_connection_close(dbCon);
            return dt;

        }

        public int getStockItemCount(int Stock_id)
        {
            int count = 0;
            string str_stockItem_count = @"SELECT COUNT(*) FROM tblStockItemCount WHERE stock_id =" + Stock_id;
            dbCmd = new SqlCeCommand(str_stockItem_count, dbCon);
            oCommonfunction.db_connection_open(dbCon);
            count = (Int32)dbCmd.ExecuteScalar();
            oCommonfunction.db_connection_close(dbCon);
            return count;
         }


        public bool UpdatePurchaseOrder(int phone_status,string remarks,int purchase_order_id)
        {
            bool is_true = false;
            try
            {
                string updatePurchaseOrder = @"UPDATE tblPurchaseOrder SET phone_status =" + phone_status + ",remarks='"+remarks+"' WHERE PO_server_id =" + purchase_order_id;
                dbCmd = new SqlCeCommand(updatePurchaseOrder, dbCon);
                oCommonfunction.db_connection_open(dbCon);
                int ret = dbCmd.ExecuteNonQuery();
                if (ret > 0)
                {
                    dbCmd.Dispose();
                    is_true = true;
                }
                oCommonfunction.db_connection_close(dbCon);
            }
            catch (Exception ex)
            {
                dbCmd.Dispose();
                string errorMessage = ex.Message.ToString();
                oCommonfunction.db_connection_close(dbCon);
                
            }
            return is_true;
        }


        public DataTable getSalesOrderDetails()
        {
            DataTable dt = new DataTable();
            string sales_order_query = @"SELECT tblSalesOrder.ID,tblSalesOrder.name,
                                          tblSalesOrder.Customer_ID,tblSalesOrder.DateOfOrder,tblSalesOrder.ExpectedDateOfDelivery
                                          ,tblSalesOrder.SalesOrderNo, tblSalesOrder.Status,tblSalesOrder.phone_status
                                          FROM tblSalesOrder";

            dbCmd = new SqlCeCommand(sales_order_query, dbCon);
            SqlCeDataAdapter Da = new SqlCeDataAdapter(dbCmd);
            oCommonfunction.db_connection_open(dbCon);
            SqlCeDataAdapter Sda = new SqlCeDataAdapter(dbCmd);
            Sda.Fill(dt);
            dbCmd.Dispose();
            oCommonfunction.db_connection_close(dbCon);
            return dt;

        }

        public DataTable getSalesOrderItemDetails(string sales_order_no)
        {
            //get sales order no details and find the id 

            DataTable dt = new DataTable();
            if (!string.IsNullOrEmpty(sales_order_no))
            {



                string str_sales_order_query = @"SELECT tblSalesOrder.ID,tblSalesOrder.name,tblSalesOrder.remarks,
                                                  tblSalesOrder.Customer_ID,tblSalesOrder.DateOfOrder,tblSalesOrder.ExpectedDateOfDelivery
                                                  ,tblSalesOrder.SalesOrderNo, tblSalesOrder.Status,tblSalesOrder.phone_status
                                                  FROM tblSalesOrder WHERE  tblSalesOrder.name +'(' + tblSalesOrder.SalesOrderNo +')' LIKE '%" + sales_order_no + "%'";

                dbCmd = new SqlCeCommand(str_sales_order_query, dbCon);
                oCommonfunction.db_connection_open(dbCon);
                SqlCeDataReader dr = dbCmd.ExecuteReader();
                if(dr.Read())
                {
                    //get purchase order id
                    int SO_id = Convert.ToInt32(dr["ID"].ToString());
                    CommonFunction.so_remarks = Convert.ToString(dr["remarks"].ToString());
                    dr.Dispose();
                    string get_item_query = @"SELECT tblSalesOrderItem.id ,tblSalesOrderItem.Item_ID,tblSalesOrderItem.rcd_quntity
                                                 ,tblSalesOrderItem.Item_Name,tblSalesOrderItem.Cost_Per_Item,tblSalesOrderItem.total_quantity
                                                 ,tblSalesOrderItem.Quantity,tblSalesOrderItem.SO_ID,tblSalesOrderItem.batch_no
                                                 ,ItemDetails.server_id,ItemDetails.item_no,ItemDetails.item_name,ItemDetails.m_stock_type_id 
                                                  from tblSalesOrderItem INNER JOIN ItemDetails
                                                  ON tblSalesOrderItem.Item_ID = ItemDetails.server_id WHERE tblSalesOrderItem.SO_ID =" + SO_id;

                    dbCmd = new SqlCeCommand(get_item_query, dbCon);
                    SqlCeDataAdapter Da = new SqlCeDataAdapter(dbCmd);
                    SqlCeDataAdapter Sda = new SqlCeDataAdapter(dbCmd);
                    Sda.Fill(dt);
                    dbCmd.Dispose();
                    Sda.Dispose();
                }
                oCommonfunction.db_connection_close(dbCon);
            }
            return dt;

        }

        public int getSalesOrderItemCount(int SO_id)
        {
            int count = 0;
            string str_purchase_query = @"SELECT COUNT(*) FROM tblSalesOrderItem WHERE SO_ID =" + SO_id;
            dbCmd = new SqlCeCommand(str_purchase_query, dbCon);
            oCommonfunction.db_connection_open(dbCon);
            count = (Int32)dbCmd.ExecuteScalar();
            oCommonfunction.db_connection_close(dbCon);
            return count;
        }


        public bool UpdateSalesOrder(int phone_status,string remarks, int sales_order_id)
        {
            bool is_true = false;
            try
            {
                string updateSalesOrder = @"UPDATE tblSalesOrder SET phone_status =" + phone_status + ",remarks='" + remarks + "' WHERE ID =" + sales_order_id;
                dbCmd = new SqlCeCommand(updateSalesOrder, dbCon);
                oCommonfunction.db_connection_open(dbCon);
                int ret = dbCmd.ExecuteNonQuery();
                if (ret > 0)
                {
                    dbCmd.Dispose();
                    is_true = true;
                }
                oCommonfunction.db_connection_close(dbCon);
            }
            catch (Exception ex)
            {
                dbCmd.Dispose();
                string errorMessage = ex.Message.ToString();
                oCommonfunction.db_connection_close(dbCon);

            }
            return is_true;
        }

        public bool UpdateStockOrder(int phone_status, string remarks,int item_id, int stock_id)
        {
            bool is_true = false;
            try
            {
                string updateSalesOrder = @"UPDATE tblStockCountSheet SET phone_status =" + phone_status + ",remarks='" + remarks + "' WHERE id =" + stock_id ;
                dbCmd = new SqlCeCommand(updateSalesOrder, dbCon);
                oCommonfunction.db_connection_open(dbCon);
                int ret = dbCmd.ExecuteNonQuery();
                if (ret > 0)
                {
                    dbCmd.Dispose();
                    is_true = true;
                }
                oCommonfunction.db_connection_close(dbCon);
            }
            catch (Exception ex)
            {
                dbCmd.Dispose();
                string errorMessage = ex.Message.ToString();
                oCommonfunction.db_connection_close(dbCon);

            }
            return is_true;
        }

        //update item details
        public bool UpdateQunatity(string quant, int item_id, int po_id, int formtype, string scan_value)
        {
            bool is_check = false;
            string query = "";
            if(formtype == 1)
            {
                query = @"UPDATE tblPurchaseOrderItem SET  rcd_quntity ='" + quant + "',scan_value=@scan_value WHERE Item_ID=" + item_id + " AND PO_ID=" + po_id;
            }
            else if(formtype == 2)
            {
                query = @"UPDATE tblSalesOrderItem SET  rcd_quntity =" + quant + ",scan_value=@scan_value WHERE Item_ID=" + item_id + " AND SO_ID=" + po_id;
            }
            else if(formtype == 3)
            {
                query = @"UPDATE tblStockItemCount SET  quantity = " + quant + ",scan_value=@scan_value WHERE item_id=" + item_id + " AND stock_sheet_id=" + po_id;
            }
           
            dbCmd = new SqlCeCommand(query, dbCon);
            oCommonfunction.db_connection_open(dbCon);
            dbCmd.Parameters.Add("@scan_value", scan_value);
            int ret = dbCmd.ExecuteNonQuery();
            if(ret > 0)
            {
                is_check = true;
            }
            oCommonfunction.db_connection_close(dbCon);
            return is_check;
        }

        public bool UpdateItemwithBatchAndSerialNo(string batch_no, string serial_no, string total_quantity, int item_id, int po_id, int formtype, string scan_value)
        {
            bool is_check = false;
            string query = "";
            try
            {
                if(formtype == 1)
                {
                    query = @"UPDATE tblPurchaseOrderItem SET serial_no=@serial_no,batch_no=@batch_no,scan_value=@scan_value,total_quantity=@total_quantity WHERE Item_ID=" + item_id + " AND PO_ID=" + po_id; 
                }
                else if (formtype == 2)
                {
                    query = @"UPDATE tblSalesOrderItem SET serial_no=@serial_no,batch_no=@batch_no,scan_value=@scan_value,total_quantity=@total_quantity WHERE Item_ID=" + item_id + " AND SO_ID=" + po_id; 
                }
                else if (formtype == 3)
                {
                    query = @"UPDATE tblStockItemCount SET serial_no=@serial_no,batch_no=@batch_no,scan_value=@scan_value WHERE item_id=" + item_id + " AND stock_sheet_id=" + po_id; 
                }
                

               
                dbCmd = new SqlCeCommand(query, dbCon);
                oCommonfunction.db_connection_open(dbCon);
                dbCmd.Parameters.Add("@serial_no", serial_no);
                dbCmd.Parameters.Add("@batch_no", batch_no);
                dbCmd.Parameters.Add("@scan_value", scan_value);
                dbCmd.Parameters.Add("@total_quantity", total_quantity);
                int ret = dbCmd.ExecuteNonQuery();
                if (ret > 0)
                {
                    is_check = true;
                }
            }
            catch (Exception ex)
            {

                throw;
            }
            finally
            {
                oCommonfunction.db_connection_close(dbCon);
            }

            return is_check;
        }

        public bool UpdateItemwithSerialNo(string serial_no,string total_quantity, int item_id, int po_id, int formtype, string scan_value)
        {
            bool is_check = false;
            string query = "";
            try
            {
                
                 if (formtype == 1)
                 {
                     query = @"UPDATE tblPurchaseOrderItem SET serial_no=@serial_no,scan_value=@scan_value,total_quantity=@total_quantity WHERE Item_ID=" + item_id + " AND PO_ID=" + po_id;
                 }
                 else if (formtype == 2)
                 {
                     query = @"UPDATE tblSalesOrderItem SET serial_no=@serial_no,scan_value=@scan_value,total_quantity=@total_quantity WHERE Item_ID=" + item_id + " AND SO_ID=" + po_id;
                 }
                 else if (formtype == 3)
                 {
                     query = @"UPDATE tblStockItemCount SET serial_no=@serial_no,scan_value=@scan_value,total_quantity=@total_quantity WHERE item_id=" + item_id + " AND stock_sheet_id=" + po_id;
                 }
                
                dbCmd = new SqlCeCommand(query, dbCon);
                oCommonfunction.db_connection_open(dbCon);
                dbCmd.Parameters.Add("@serial_no", serial_no);
                dbCmd.Parameters.Add("@scan_value", scan_value);
                dbCmd.Parameters.Add("@total_quantity", total_quantity);
                int ret = dbCmd.ExecuteNonQuery();
                if (ret > 0)
                {
                    is_check = true;
                }
            }
            catch (Exception ex)
            {

                throw;
            }
            finally
            {
                oCommonfunction.db_connection_close(dbCon);
            }
            return is_check;
        }

        public bool UpdateItemwithBatchNo(string batch_no, int item_id, int po_id, int formtype, string scan_value)
        {
            bool is_check = false;
            string query = "";
            try
            {                
                if(formtype == 1)
                {
                    query = @"UPDATE tblPurchaseOrderItem SET batch_no=@batch_no,scan_value=@scan_value  WHERE Item_ID=" + item_id + " AND PO_ID=" + po_id;
                }
                else if(formtype == 2)
                {
                    query = @"UPDATE tblSalesOrderItem SET batch_no=@batch_no,scan_value=@scan_value  WHERE Item_ID=" + item_id + " AND SO_ID=" + po_id;
                }
                else if(formtype == 3)
                {
                    query = @"UPDATE tblStockItemCount SET batch_no=@batch_no,scan_value=@scan_value,total_quantity=@total_quantity  WHERE item_id=" + item_id + " AND stock_sheet_id=" + po_id;
                }
                
                dbCmd = new SqlCeCommand(query, dbCon);
                oCommonfunction.db_connection_open(dbCon);
                dbCmd.Parameters.Add("@scan_value", scan_value);
                dbCmd.Parameters.Add("@batch_no", batch_no);
                int ret = dbCmd.ExecuteNonQuery();
                if (ret > 0)
                {
                    is_check = true;
                }
            }
            catch (Exception ex)
            {

                throw;
            }
            finally
            {
                oCommonfunction.db_connection_close(dbCon);
            }

            return is_check;
        }

        public bool UpdateItemwithBatchNoOrQuantity(string batch_no, string quant, string total_quantity, int item_id, int po_id, int formtype, string scan_value)
        {
            bool is_check = false;
            string query = "";
            try
            {
               
                if (formtype == 1)
                {
                    query = @"UPDATE tblPurchaseOrderItem SET rcd_quntity=@quant,batch_no=@batch_no,scan_value=@scan_value,total_quantity=@total_quantity  WHERE Item_ID=" + item_id + " AND PO_ID=" + po_id;
                }
                else if (formtype == 2)
                {
                    query = @"UPDATE tblSalesOrderItem SET rcd_quntity=@quant,batch_no=@batch_no,scan_value=@scan_value,total_quantity=@total_quantity  WHERE Item_ID=" + item_id + " AND SO_ID=" + po_id;
                }
                else if (formtype == 3)
                {
                    query = @"UPDATE tblStockItemCount SET quantity=@quant,batch_no=@batch_no,scan_value=@scan_value,total_quantity=@total_quantity  WHERE item_id=" + item_id + " AND stock_sheet_id=" + po_id;
                }
               
                dbCmd = new SqlCeCommand(query, dbCon);
                oCommonfunction.db_connection_open(dbCon);
                dbCmd.Parameters.Add("@batch_no", batch_no);
                dbCmd.Parameters.Add("@quant", quant);
                dbCmd.Parameters.Add("@scan_value", scan_value);
                dbCmd.Parameters.Add("@total_quantity", total_quantity);
                int ret = dbCmd.ExecuteNonQuery();
                if (ret > 0)
                {
                    is_check = true;
                }
            }
            catch (Exception ex)
            {

                throw;
            }
            finally
            {
                oCommonfunction.db_connection_close(dbCon);
            }

            return is_check;
        }

        public void PostUserDetailsDataToSetver()
        {
            try
            {
                List<UserDetails> listUserDetails = new List<UserDetails>();
                string UserQuery = @"SELECT * from tblUserDetails WHERE status=2 AND server_id =" + CommonFunction.login_id;
                dbCmd = new SqlCeCommand(UserQuery, dbCon);
                oCommonfunction.db_connection_open(dbCon);
                SqlCeDataReader dr = dbCmd.ExecuteReader();
                while (dr.Read())
                {
                    UserDetails oUserDetails = new UserDetails();
                    oUserDetails.Id = Convert.ToString(dr["server_id"]);
                    oUserDetails.UserName = Convert.ToString(dr["UserName"]);
                    oUserDetails.Password = Convert.ToString(dr["Password"]);
                    listUserDetails.Add(oUserDetails);
                }
                dbCmd.Dispose();
                dr.Dispose();
                if(listUserDetails.Count > 0)
                {
                    string serialisedData = JsonConvert.SerializeObject(listUserDetails);
                    frmSettingDetails.OwdcApi.postUserApi(serialisedData);                   
                }
               
               
            }
            catch (Exception ex)
            { }
            finally
            {
                oCommonfunction.db_connection_close(dbCon);
            } 
        }
        public bool PostPurchaseOrdersDataToSetver(out bool ret1)
        {
            bool ret = true;
            ret1 = false;

            //string[] delarr = new string[500];
            try
            {
                List<PurchaseOrderDetails> ListPurchaseOrder = new List<PurchaseOrderDetails>();
                string Query = @"SELECT * FROM tblPurchaseOrder WHERE phone_status !=1";
                dbCmd = new SqlCeCommand(Query, dbCon);
                oCommonfunction.db_connection_open(dbCon);
                SqlCeDataReader dr = dbCmd.ExecuteReader();
                int cnt = 0;
                while (dr.Read())
                {
                    dbCmd.Dispose();
                    PurchaseOrderDetails oPurchaseOrder = new PurchaseOrderDetails();
                    oPurchaseOrder.ID = Convert.ToString(dr["PO_server_id"]);
                    oPurchaseOrder.Purchase_Order_Number = Convert.ToString(dr["purchase_order_no"]);
                    oPurchaseOrder.DateOfPurchase = Convert.ToString(dr["date_of_purchase"]);
                    oPurchaseOrder.ExpectedDateOfDelivery = Convert.ToString(dr["expected_delivery_date"]);
                    oPurchaseOrder.Assigned_User = Convert.ToString(dr["assigned_user"]);
                    oPurchaseOrder.Status = Convert.ToString(dr["server_status"]);
                    oPurchaseOrder.Phone_Status = Convert.ToString(dr["phone_status"]);
                    oPurchaseOrder.Vendor_Id = Convert.ToString(dr["Vendor_ID"]);
                    oPurchaseOrder.Vendor_Name = Convert.ToString(dr["Vendor_Name"]);
                    oPurchaseOrder.Remarks = Convert.ToString(dr["remarks"]);
                    oPurchaseOrder.Actual_Received_Date = "";
                   
                    string item_query = @"SELECT * FROM tblPurchaseOrderItem WHERE PO_ID=" + oPurchaseOrder.ID;
                    SqlCeCommand dbCmd1 = new SqlCeCommand(item_query, dbCon);
                    SqlCeDataReader dr1 = dbCmd1.ExecuteReader();
                    oPurchaseOrder.View_PurchaseOrder_Item = new List<PurchaseOrderItem>();

                    while (dr1.Read())
                    {
                        
                        PurchaseOrderItem oPurchaseOrderItem = new PurchaseOrderItem();
                        oPurchaseOrderItem.ID = Convert.ToString(dr1["id"]);
                        oPurchaseOrderItem.Item_ID = Convert.ToString(dr1["Item_ID"]);
                        oPurchaseOrderItem.Item_Name = Convert.ToString(dr1["Item_Name"]);
                        oPurchaseOrderItem.PO_ID = Convert.ToString(dr1["PO_ID"]);
                        oPurchaseOrderItem.Quantity = Convert.ToString(dr1["Quantity"]);
                        oPurchaseOrderItem.Vender_ID = Convert.ToString(dr1["Vender_ID"]);
                        oPurchaseOrderItem.Rcd_Quntity = Convert.ToString(dr1["rcd_quntity"]);
                        oPurchaseOrderItem.Batch_No = Convert.ToString(dr1["batch_no"]);
                        oPurchaseOrderItem.Serial_No = Convert.ToString(dr1["serial_no"]);
                        oPurchaseOrderItem.Scan_Value = Convert.ToString(dr1["scan_value"]);
                        oPurchaseOrderItem.Cost_Per_Item = "";
                        oPurchaseOrder.View_PurchaseOrder_Item.Add(oPurchaseOrderItem);
                    }
                    dbCmd1.Dispose();
                    dr1.Dispose();
                    ListPurchaseOrder.Add(oPurchaseOrder);

                    //delete po from table 
                    //string  Po_query = "DELETE FROM tblPurchaseOrder  WHERE PO_server_id =" + oPurchaseOrder.ID;
                    //delarr[cnt] = Po_query;
                    //string Po_item_query = "DELETE FROM tblPurchaseOrderItem  WHERE PO_ID =" + oPurchaseOrder.ID;
                    //cnt++;
                    //delarr[cnt] = Po_item_query;
                    //cnt++;
                }
                dr.Dispose();
                if (ListPurchaseOrder.Count > 0)
                {
                    string serialisedData = JsonConvert.SerializeObject(ListPurchaseOrder);
                    List<POApiResponse> ListPO = frmSettingDetails.OwdcApi.postPurchaseOrderApi(serialisedData);
                    foreach (var data in ListPO)
                    {
                        if (data == null)
                            continue;

                        ret1 = true;
                        
                        if (data.Status)
                        {
                            string Po_query = "DELETE FROM tblPurchaseOrder  WHERE PO_server_id =" + data.PO_ID;
                            bool b1 = UpdateDataFromTable(Po_query);
                        }
                        else
                        {
                            string Po_query = "UPDATE tblPurchaseOrder  SET phone_status=1 WHERE PO_server_id =" + data.PO_ID;
                            bool b1 = UpdateDataFromTable(Po_query);
                        }
                    }
                    /* if (ret)
                  {
                      bool b1 = DeleteDataHistoryAfterPostData(delarr, cnt);
                  }
                  else
                  {

                  }*/
                  
                }              
            }
            catch (Exception ex)
            {


            }
            finally
            {
                oCommonfunction.db_connection_close(dbCon);
            }
            return ret;
        }

        public bool PostSalesOrdersDataToSetver()
        {
            //string[] delarr = new string[500];
            bool ret = false;
            try
            {
                List<SalesOrderDetails> ListSalesOrder = new List<SalesOrderDetails>();
                string Query = @"SELECT * FROM tblSalesOrder  WHERE phone_status !=1";
                dbCmd = new SqlCeCommand(Query, dbCon);
                oCommonfunction.db_connection_open(dbCon);
                SqlCeDataReader dr = dbCmd.ExecuteReader();
                int cnt = 0;
                while (dr.Read())
                {
                    dbCmd.Dispose();

                    SalesOrderDetails oSalesOrder = new SalesOrderDetails();
                    oSalesOrder.ID = Convert.ToString(dr["ID"]);
                    oSalesOrder.SalesOrderNo = Convert.ToString(dr["SalesOrderNo"]);
                    oSalesOrder.DateOfOrder = Convert.ToString(dr["DateOfOrder"]);
                    oSalesOrder.ExpectedDateOfDelivery = Convert.ToString(dr["ExpectedDateOfDelivery"]);
                    oSalesOrder.name = Convert.ToString(dr["name"]);
                    oSalesOrder.Status = Convert.ToString(dr["Status"]);
                    oSalesOrder.Phone_Status = Convert.ToString(dr["phone_status"]);
                    oSalesOrder.Customer_ID = Convert.ToString(dr["Customer_ID"]);
                    oSalesOrder.Actual_Delivery_Date = "";
                    oSalesOrder.Assigned_User = "";

                    string item_query = @"SELECT * FROM tblSalesOrderItem WHERE SO_ID=" + oSalesOrder.ID;
                    SqlCeCommand dbCmd1 = new SqlCeCommand(item_query, dbCon);
                    SqlCeDataReader dr1 = dbCmd1.ExecuteReader();
                    oSalesOrder.View_SalesOrder_Item = new List<SalesOrderItem>();

                    while (dr1.Read())
                    {

                        SalesOrderItem oSalesOrderItem = new SalesOrderItem();
                        oSalesOrderItem.ID = Convert.ToString(dr1["id"]);
                        oSalesOrderItem.Item_ID = Convert.ToString(dr1["Item_ID"]);
                        oSalesOrderItem.Item_Name = Convert.ToString(dr1["Item_Name"]);
                        oSalesOrderItem.SO_ID = Convert.ToString(dr1["SO_ID"]);
                        oSalesOrderItem.Quantity = Convert.ToString(dr1["Quantity"]);
                        oSalesOrderItem.Delivered_Quntity = Convert.ToString(dr1["rcd_quntity"]);
                        oSalesOrderItem.Batch_No = Convert.ToString(dr1["batch_no"]);
                        oSalesOrderItem.Serial_No = Convert.ToString(dr1["serial_no"]);
                        oSalesOrderItem.Scan_Value = Convert.ToString(dr1["scan_value"]);
                        oSalesOrderItem.Cost_Per_Item = "";
                        oSalesOrder.View_SalesOrder_Item.Add(oSalesOrderItem);
                    }
                    dbCmd1.Dispose();
                    dr1.Dispose();
                    ListSalesOrder.Add(oSalesOrder);
                    //delete so from table 
                    //string So_query = "DELETE FROM tblSalesOrder  WHERE ID =" + oSalesOrder.ID;
                    //delarr[cnt] = So_query;
                    //cnt++;
                    //string So_item_query = "DELETE FROM tblSalesOrderItem  WHERE SO_ID =" + oSalesOrder.ID;
                    //delarr[cnt] = So_item_query;
                    //cnt++;
                    
                  
                    
                }
                dr.Dispose();
                if (ListSalesOrder.Count > 0)
                {
                    
                    string serialisedData = JsonConvert.SerializeObject(ListSalesOrder);
                    List<SOApiResponse> ListSO = frmSettingDetails.OwdcApi.postSalesOrderApi(serialisedData);
                    foreach (var data in ListSO)
                    {

                        if (data == null)
                            continue;

                        ret = true;

                        if (data.Status)
                        {
                            string So_query = "DELETE FROM tblSalesOrder  WHERE ID =" + data.SO_ID;
                            bool b1 = UpdateDataFromTable(So_query);
                        }
                        else
                        {
                            string So_query = "UPDATE tblSalesOrder SET phone_status=1 WHERE ID =" + data.SO_ID;
                            bool b1 = UpdateDataFromTable(So_query);
                        }
                    }
                 
                }
                
            }
            catch (Exception ex)
            {

               // ret = false;
            }
            finally
            {
                oCommonfunction.db_connection_close(dbCon);
            }

            return ret;

        }

        public bool PostStockDataToSetver()
        {
           // string[] delarr = new string[500];
            bool ret = false;

            try
            {
                List<StockCountDetails> ListStockCount = new List<StockCountDetails>();
                string Query = @"SELECT * FROM tblStockCountSheet  WHERE phone_status !=1";
                dbCmd = new SqlCeCommand(Query, dbCon);
                oCommonfunction.db_connection_open(dbCon);
                SqlCeDataReader dr = dbCmd.ExecuteReader();

                int cnt = 0;
                int upnt = 0;
                while (dr.Read())
                {
                    dbCmd.Dispose();
                    StockCountDetails oStock = new StockCountDetails();
                    oStock.ID = Convert.ToString(dr["id"]);
                    oStock.Name = Convert.ToString(dr["name"]);
                    oStock.Status = Convert.ToString(dr["status"]);
                    oStock.Phone_Status = Convert.ToString(dr["phone_status"]);
                    string item_query = @"SELECT * FROM tblStockItemCount WHERE stock_sheet_id=" + oStock.ID;
                    SqlCeCommand dbCmd1 = new SqlCeCommand(item_query, dbCon);
                    SqlCeDataReader dr1 = dbCmd1.ExecuteReader();
                    oStock.Items = new List<Items>();
                    while (dr1.Read())
                    {
                        Items oItems = new Items();
                        oItems.Item_ID = Convert.ToString(dr1["item_id"]);
                        oItems.Stock_ID = Convert.ToString(dr1["stock_id"]);
                        oItems.Quntity = Convert.ToString(dr1["quantity"]);
                        oItems.Batch_No = Convert.ToString(dr1["batch_no"]);
                        oItems.Serial_No = Convert.ToString(dr1["serial_no"]);
                        oItems.Scan_Value = Convert.ToString(dr1["scan_value"]);
                        oStock.Items.Add(oItems);
                    }
                    dbCmd1.Dispose();
                    dr1.Dispose();
                    ListStockCount.Add(oStock);

                    //delete so from table 
                   /* string stock_query = "DELETE FROM tblStockCountSheet  WHERE id =" + oStock.ID;
                    delarr[cnt] = stock_query;
                    cnt++;
                    string stock_item_query = "DELETE FROM tblStockItemCount  WHERE stock_sheet_id =" + oStock.ID;
                    delarr[cnt] = stock_item_query;
                    cnt++;  */            

                    
                   
                }//end while
                dr.Dispose();
                if (ListStockCount.Count > 0)
                {
                    
                    string serialisedData = JsonConvert.SerializeObject(ListStockCount);
                    List<StockApiResponse> ListStock = frmSettingDetails.OwdcApi.postStockOrderApi(serialisedData);
                    foreach (var data in ListStock)
                    {
                        if (data == null)
                            continue;

                        ret = true;

                        if (data.Status)
                        {
                            string stock_query = "DELETE FROM tblStockCountSheet  WHERE id =" + data.Stock_id;
                            bool b1 = UpdateDataFromTable(stock_query);
                        }
                        else
                        {
                            string stock_query = "UPDATE tblStockCountSheet SET phone_status=1 WHERE id =" + data.Stock_id;
                            bool b1 = UpdateDataFromTable(stock_query);
                        }
                    }
                }
                
            }
            catch (Exception ex)
            {


            }
            finally
            {
                oCommonfunction.db_connection_close(dbCon);
            }

            return ret;

        }


        public bool DeleteDataHistoryAfterPostData(string[] delarr,int cnt)
        {
            bool ret = false;
            for (int i = 0; i < cnt; i++)
            {
                if (delarr[i] == null || delarr[i] == "")
                    break;
                try
                {
                   ret =  DeleteDataFromTable(delarr[i]);
                }
                catch (Exception er)
                {

                }
            }

            return ret;
        }

        public bool UpdateDataFromTable(string strQuery)
        {
            bool is_check = false;
            string query = strQuery;
            SqlCeCommand dbCmd2 = new SqlCeCommand(query, dbCon);
            int ret = dbCmd2.ExecuteNonQuery();
            if (ret > 0)
            {
                is_check = true;
            }
            dbCmd2.Dispose();
            return is_check;
        }
         


        public bool DeleteDataFromTable(string strQuery)
        {
            bool is_check = false;
            string query = strQuery;
            SqlCeCommand dbCmd2 = new SqlCeCommand(query, dbCon);
            int ret = dbCmd2.ExecuteNonQuery();
            if(ret > 0)
            {
                is_check = true;
            }
            dbCmd2.Dispose();
            return is_check;
        }

        public bool deleteAllData(string query)
        {
            bool ret = false;
            try
            {
               
                oCommonfunction.db_connection_open(dbCon);
                ret = DeleteDataFromTable(query);
                oCommonfunction.db_connection_close(dbCon);
            }
            catch (Exception)
            {

                ret = false;
            }
            return ret;
        }

        public DataTable FillItemMasterGrid()
        {
            String query = @"SELECT ItemDetails.item_name
                                   ,ItemDetails.item_no
                                   ,ItemDetails.description
                                    FROM ItemDetails";
            SqlCeCommand cmd = new SqlCeCommand(query, dbCon);
            SqlCeDataAdapter Da = new SqlCeDataAdapter(cmd);
            DataTable dt = new DataTable("Table");
            Da.Fill(dt);
            return dt;           
        }


       

   }
}
