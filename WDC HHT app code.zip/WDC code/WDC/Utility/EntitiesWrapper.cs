﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;

namespace WDC.Utility
{
    class EntitiesWrapper
    {

    }
   

    public class UserDetails
    {
        public string Id { get; set; }
        public string UserName { get; set; }
        public string PasswordHash { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }
    }

    public class ItemDetails
    {
        public List<stock> stock { get; set; }
        public List<location> location { get; set; }
    }

    public class stock
    {
        public string ID { get; set; }
      //  public string Batch_No { get; set; }
        public string Cost_per_Item { get; set; }
        public string Created_By { get; set; }
        public string Current_Stock { get; set; }
        public string Date_of_Creation { get; set; }
        public string Description { get; set; }
        public string Item_Name { get; set; }
        public string Item_No { get; set; }
        public string Location_ID { get; set; }
        public string Sub_Location_ID { get; set; }
        public string m_stock_status_id { get; set; }
        public string m_Stock_type_ID { get; set; }
        public string m_Stock_Unit_ID { get; set; }
       // public string Quantity { get; set; }
        public string Reorder_Level { get; set; }
       // public string Serial_No { get; set; }
    }
    public class location
    {
        public string ID { get; set; }
        public string Area { get; set; }
        public string Parent_ID { get; set; }
        public string Date_of_Creation { get; set; }
    }

    public class PurchaseOrderDetails
    {
        public string ID { get; set; }
        public string Purchase_Order_Number { get; set; }
        public string Actual_Received_Date { get; set; }
        public string Assigned_User { get; set; }
        public string DateOfPurchase { get; set; }
        public string ExpectedDateOfDelivery { get; set; }
        public string Status { get; set; }
        public string Phone_Status { get; set; }
        public string Vendor_Name { get; set; }
        public string Vendor_Id { get; set; }
        public string Remarks { get; set; }
        public List<PurchaseOrderItem> View_PurchaseOrder_Item { get; set; }
    }

    public class PurchaseOrderItem
    {
        public string ID { get; set; }
        public string Cost_Per_Item { get; set; }
        public string Item_ID   { get; set; }
        public string Item_Name { get; set; }
        public string PO_ID { get; set; }
        public string Quantity { get; set; }
        public string Vender_ID { get; set; }
        public string Rcd_Quntity { get; set; }
        public string Batch_No { get; set; }
        public string Serial_No  { get; set; }
        public string Scan_Value { get; set; }
    }
    
    public class SalesOrderDetails
    {
        public string ID { get; set; }
        public string SalesOrderNo { get; set; }
        public string Actual_Delivery_Date { get; set; }
        public string Assigned_User { get; set; } 
        public string DateOfOrder { get; set; }
        public string ExpectedDateOfDelivery { get; set; }
        public string Status { get; set; }
        public string Phone_Status { get; set; }
        public string name  { get; set; }
        public string Customer_ID { get; set; }
        public List<SalesOrderItem> View_SalesOrder_Item { get; set; }
    }
    public class SalesOrderItem
    {
        public string ID { get; set; }
        public string Cost_Per_Item { get; set; }
        public string Item_ID { get; set; }
        public string Item_Name { get; set; }
        public string SO_ID  { get; set; }
        public string Quantity { get; set; }
        public string Delivered_Quntity { get; set; }
        public string Batch_No { get; set; }
        public string Serial_No { get; set; }
        public string Scan_Value { get; set; }
    }

    public class StockCountDetails
    {
        public string ID { get; set; }
        public string Name { get; set; }
        public string Status { get; set; }
        public string Phone_Status { get; set; }
        public List<Items> Items { get; set; }
    }
    public class Items
    {
        public string Item_ID { get; set; }
        public string Stock_ID { get; set; }
        public string Quntity { get; set; }
        public string Batch_No { get; set; }
        public string Serial_No { get; set; }
        public string Scan_Value { get; set; }
    }





    //api responses classes
    public class POApiResponse
    {
        public string PO_ID { get; set; }
        public string PO_Number { get; set; }
        public bool Status { get; set; }
        public string Message { get; set; }
    }

    public class SOApiResponse
    {
        public string SO_ID { get; set; }
        public string SO_Number { get; set; }
        public bool Status { get; set; }
        public string Message { get; set; }
    }

    public class StockApiResponse
    {
        public string Stock_id { get; set; }
        public string Sheet_Name { get; set; }
        public bool Status { get; set; }
        public string Message { get; set; }
    }


    //temporary classes which will be removed when naresh will add name (Po,so,stock) in api 
    public class getPoName
    {
        public int id { get; set; }
        public string OrderNo { get; set; }
    }
    public class getSoName
    {
        public int id { get; set; }
        public string OrderNo { get; set; }
    }
    public class getStockName
    {
        public int id { get; set; }
        public string StockName { get; set; }
    }
}
