﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using WDC.Utility;
using System.Data.SqlServerCe;
using Symbol.Barcode2;

namespace WDC
{
    public partial class frmItemDetails : Form
    {
        public string conSTR = "Data Source=" +
          (System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase)) +
          "\\dbWDC.sdf;Persist Security Info=False";
        bool  isBtnBack = false;
        SqlCeConnection dbCon = null;
        SqlCeCommand dbCmd = null;
        //DbConnection oDbConnection = null;
        CommonFunction oCommonFunction = null;
        int gl_po_id = 0;
        int gl_Poitem_id = 0;
        int gl_m_stock_type_id = 0;
        int gl_item_details_id = 0;
        int set_quantity = 0;
        string gl_description = "";

        TextBox txtBatchNo = new TextBox();
        TextBox txtQuant = new TextBox();
        Label lblBathNo = new Label();
        Label lblQuntNo = new Label();
        TextBox txtSerialNo = new TextBox();
        Button btnAdd = new Button();
        Button btnClear = new Button();
        Button btnScanSerialNo = new Button();
        DataTable dynamicTable = new DataTable();
             
        public frmItemDetails()
        {
            dbCon = new SqlCeConnection(conSTR);           
            //oDbConnection = new DbConnection();
            oCommonFunction = new CommonFunction();
            //txtQuant.KeyPress += new KeyPressEventHandler(txtBatchNo_KeyPress);
            InitializeComponent();
        }

        private void frmItemDetails_Load(object sender, EventArgs e)
        {
           ShowItemInformation();
           //btn_close.Focus();
          
           pictureBox2.Image = Resource1.view_detail;
           pictureBox2.Focus();            
        }

       

        public void ShowItemInformation()
        {
            try
            {

                string str_purchase_order_query = @"SELECT tblPurchaseOrder.PO_server_id,tblPurchaseOrder.purchase_order_no,
                                            tblPurchaseOrder.date_of_purchase,tblPurchaseOrder.expected_delivery_date,tblPurchaseOrder.assigned_user
                                            ,tblPurchaseOrder.server_status, tblPurchaseOrder.phone_status,tblPurchaseOrder.Vendor_ID,
                                            tblPurchaseOrder.Vendor_Name FROM tblPurchaseOrder WHERE  tblPurchaseOrder.Vendor_Name +'(' + tblPurchaseOrder.purchase_order_no +')' LIKE '%" + CommonFunction.Purchase_order_no + "%'";

                dbCmd = new SqlCeCommand(str_purchase_order_query, dbCon);
                oCommonFunction.db_connection_open(dbCon);
                SqlCeDataReader dr = dbCmd.ExecuteReader();
                if (dr.Read())
                {
                    gl_po_id = Convert.ToInt32(dr["PO_server_id"].ToString());
                    lblSelectPO.Text = Convert.ToString(dr["purchase_order_no"]);
                    dbCmd.Dispose();
                    dr.Dispose();

                    string query = @"SELECT tblPurchaseOrderItem.Quantity
                                    ,tblPurchaseOrderItem.id
                               ,tblPurchaseOrderItem.scan_value
                               ,tblPurchaseOrderItem.rcd_quntity,ItemDetails.item_no
                                ,ItemDetails.item_name,ItemDetails.description
                                ,ItemDetails.m_stock_type_id ,tblPurchaseOrderItem.serial_no
                                ,ItemDetails.server_id
                                ,tblPurchaseOrderItem.batch_no,cl.Area as Location,pl.Area as Sublocation FROM  tblPurchaseOrderItem  
                                INNER JOIN ItemDetails  
                               ON tblPurchaseOrderItem.Item_ID = ItemDetails.server_id
                               INNER JOIN tblLocationDetails AS cl
                               ON cl.ID = ItemDetails.location_id
                               INNER JOIN tblLocationDetails AS pl
                               ON pl.id = ItemDetails.sub_location_id
                                WHERE ItemDetails.server_id ='" + CommonFunction.item_id + "' AND tblPurchaseOrderItem.PO_ID =" + gl_po_id;

                    SqlCeCommand dbCmd1 = new SqlCeCommand(query, dbCon);
                    SqlCeDataReader dr1 = dbCmd1.ExecuteReader();
                    if (dr1.Read())
                    {
                        string[] arr_batch_no = null;
                        string[] arr_serial_no = null;
                        string[] arr_rcd_quantity = null;

                        gl_Poitem_id = Convert.ToInt32(dr1["id"]);                       
                        string item_no = Convert.ToString(dr1["item_no"]);
                        string description = Convert.ToString(dr1["description"]);
                        string Quantity = Convert.ToString(dr1["Quantity"]);
                        set_quantity = Convert.ToInt32(Quantity);
                        string rcd_quntity = Convert.ToString(dr1["rcd_quntity"]);
                        int m_stock_type_id =  Convert.ToInt32(dr1["m_stock_type_id"].ToString());
                        //txtScan.Text = Convert.ToString(dr1["scan_value"].ToString());
                        string Batch_no = Convert.ToString(dr1["batch_no"].ToString());
                        string serial_no = Convert.ToString(dr1["serial_no"].ToString());
                        if(!string.IsNullOrEmpty(Batch_no))
                        {
                            arr_batch_no = new string[100];
                            arr_batch_no = Batch_no.Split('#');
                        }
                        if(!string.IsNullOrEmpty(serial_no))
                        {
                            arr_serial_no = new string[100];
                            arr_serial_no = serial_no.Split('#');
                        }
                        if (!string.IsNullOrEmpty(rcd_quntity) && !rcd_quntity.Contains("0"))
                        {
                            arr_rcd_quantity = new string[100];
                            arr_rcd_quantity = rcd_quntity.Split('#'); 
                        }
                        
                        lblLocation.Text = Convert.ToString(dr1["Location"].ToString());
                        if(!string.IsNullOrEmpty(Convert.ToString(dr1["Sublocation"].ToString())))
                        {
                            lblLocation.Text = Convert.ToString(dr1["Location"].ToString()) + "/" + Convert.ToString(dr1["Sublocation"].ToString());
                        }

                        lblOrderQuant.Text = Quantity;
                         //lblRcdQuant.Text = rcd_quntity;
                        if (string.IsNullOrEmpty(description))
                            description = "discription is not applicable";

                        gl_description = description.Trim();
                       // lblSelectItem.Text = item_no;// CommonFunction.Po_item_code;
                        gl_m_stock_type_id = m_stock_type_id;
                        gl_item_details_id = Convert.ToInt32(dr1["server_id"]);
                        //show or hide label or textbox by stock type
                        switch (m_stock_type_id)
                        {
                            case 1:
                                showFormbyCondition(1);
                                break;
                            case 2:
                                showFormbyCondition(2);
                                if(arr_batch_no != null && arr_rcd_quantity != null)
                                {
                                    if(arr_batch_no.Length > 0 && arr_rcd_quantity.Length > 0)
                                    {
                                        getDynamicTable(arr_batch_no, arr_rcd_quantity, 2);
                                    }
                                }
                                
                                break;
                            case 3:
                                showFormbyCondition(3);
                                if(arr_batch_no != null && arr_serial_no != null)
                                {
                                    if(arr_batch_no.Length > 0 && arr_serial_no.Length > 0)
                                    {
                                        getDynamicTable(arr_batch_no, arr_serial_no, 3);
                                    }
                                }
                                
                                break;
                            case 4:
                                showFormbyCondition(4);
                                if(arr_serial_no != null)
                                {
                                    if(arr_serial_no.Length > 0)
                                    {
                                        getDynamicTable(arr_batch_no, arr_serial_no, 4);
                                    }
                                }
                                break;
                        }
                        dbCmd1.Dispose();
                        dr1.Dispose();

                    }
                }
            }
            catch (Exception ex1)
            {
                string str = ex1.Message.ToString();
                MessageBox.Show(str);

            }
            finally
            {
                oCommonFunction.db_connection_close(dbCon);
            }
        }

       

      
        
       
        private void btnAdd_click(object sender, EventArgs e)
        {
            bool is_valid = false;
            bool is_valid_value = false;
            isBtnBack = true;
            if(dynamicTable.Rows.Count < set_quantity)
            {
                switch(gl_m_stock_type_id)
                {
                    case 2:
                        is_valid = oCommonFunction.frmCheckTwoNoValidation(txtBatchNo.Text,txtQuant.Text.Trim());
                        if (is_valid)
                        {
                            is_valid_value = is_check_valid_number(txtBatchNo.Text);
                            if (!is_valid_value)
                            {
                                dgScanDetails.DataSource = oCommonFunction.FillDynamicTable(txtBatchNo.Text, txtQuant.Text, 2, dynamicTable);
                                MessageBox.Show("Added.", "Message", MessageBoxButtons.OK, MessageBoxIcon.None, MessageBoxDefaultButton.Button1);
                            }
                            else
                                MessageBox.Show("Reocord is already exist!", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);

                        }
                        else
                        {
                            MessageBox.Show("Enter Batch No and Quantity", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                        }                       
                        break;
                    case 3:
                        is_valid = oCommonFunction.frmCheckTwoNoValidation(txtBatchNo.Text, txtSerialNo.Text.Trim());
                        if (is_valid)
                        {
                            bool is_valid_batch_no= is_check_valid_number(txtBatchNo.Text);
                            bool is_valid_serial_no = is_check_valid_number(txtSerialNo.Text);
                            if ((!is_valid_batch_no) && (!is_valid_serial_no))
                            {
                                dgScanDetails.DataSource = oCommonFunction.FillDynamicTable(txtBatchNo.Text, txtSerialNo.Text, 3, dynamicTable);
                                MessageBox.Show("Added.", "Message", MessageBoxButtons.OK, MessageBoxIcon.None, MessageBoxDefaultButton.Button1);
                            }
                            else
                            {
                                MessageBox.Show("Batch No and Serial No is already exist !", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                            }
                        }
                        else
                        {
                            MessageBox.Show("Enter Batch No and Serial No", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                        } 
                                                                 
                        break;
                    case 4:
                        is_valid = oCommonFunction.frmCheckOneNoValidation(txtSerialNo.Text.Trim());
                        if (is_valid)
                        {
                            bool is_valid_serial_no = is_check_valid_number(txtSerialNo.Text);
                            if (!is_valid_serial_no)
                            {
                                dgScanDetails.DataSource = oCommonFunction.FillDynamicTable("", txtSerialNo.Text, 4, dynamicTable);
                                MessageBox.Show("Added.", "Message", MessageBoxButtons.OK, MessageBoxIcon.None, MessageBoxDefaultButton.Button1);
                            }
                            else
                            {
                                MessageBox.Show("Serial No and already exist!", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                            }
                            
                        }
                        else
                        {
                            MessageBox.Show("Enter Serial No", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
                        }
                        
                       break;
                }
            }
            else
            {
              //  MessageBox.Show("Dot Net Perls is super.","Important Note",MessageBoxButtons.OK,MessageBoxIcon.Exclamation,MessageBoxDefaultButton.Button1);
                MessageBox.Show("Can not add record more than quantity", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }
            
        }

        private void btnClear_click(object sender, EventArgs e)
        {
            txtBatchNo.Text = "";
            txtQuant.Text = "";
        }

        private void btn_close_click(object sender, EventArgs e)
        {
            if ((dynamicTable.Rows.Count > 0) && isBtnBack)
            {
                DialogResult dialogResult = MessageBox.Show("Are you sure? You have unsaved items captured.", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.None, MessageBoxDefaultButton.Button1);
                if (dialogResult == DialogResult.Yes )
                {
                    showForm();
                }
                else if (dialogResult == DialogResult.No)
                {
                    //
                }
            }
            else
            {
                showForm();
            }

        }
        public void getDynamicTable(string[] arrFirst,string[] arrSecond,int type)
        {
            if(type == 2)
            {
               //Batch no and qunatity
                if (arrFirst.Length > 0 && arrSecond.Length > 0)
                {
                    dynamicTable.Columns.Add("S.No", typeof(Int32));
                    dynamicTable.Columns.Add("Batch No", typeof(string));
                    dynamicTable.Columns.Add("Quantity", typeof(string));
                    dynamicTable.Columns["S.No"].AutoIncrement = true;
                    dynamicTable.Columns["S.No"].AutoIncrementStep = 1;
                    dynamicTable.Columns["S.No"].AutoIncrementSeed = 1;
                }
               
                for (int i = 0; i <= arrFirst.Length - 1; i++)
                {
                    if (string.IsNullOrEmpty(arrFirst[i]))
                        break;

                    //for (int j = 0; j <= arrSecond.Length - 1; j++)
                    {
                        dynamicTable.Rows.Add(null, arrFirst[i], arrSecond[i]);
                    }                     
                }
                dgScanDetails.DataSource = dynamicTable;

            }
            else if(type == 3)
            {
                //batch no and serial no
                if (arrFirst.Length > 0 && arrSecond.Length > 0)
                {
                    dynamicTable.Columns.Add("S.No", typeof(Int32));
                    dynamicTable.Columns.Add("Batch No", typeof(string));
                    dynamicTable.Columns.Add("Serial No", typeof(string));
                    dynamicTable.Columns["S.No"].AutoIncrement = true;
                    dynamicTable.Columns["S.No"].AutoIncrementStep = 1;
                    dynamicTable.Columns["S.No"].AutoIncrementSeed = 1;
                }

                for (int i = 0; i <= arrFirst.Length - 1; i++)
                {
                    if (string.IsNullOrEmpty(arrFirst[i]))
                        break;

                    //for (int j = 0; j <= arrSecond.Length - 1; j++)
                    {
                        dynamicTable.Rows.Add(null, arrFirst[i], arrSecond[i]);
                    }
                }

                dgScanDetails.DataSource = dynamicTable;

            }
            else if(type == 4)
            {
                //serial no
                if (arrSecond.Length > 0)
                {
                    dynamicTable.Columns.Add("S.No", typeof(Int32));
                    dynamicTable.Columns.Add("Serial No", typeof(string));
                    dynamicTable.Columns["S.No"].AutoIncrement = true;
                    dynamicTable.Columns["S.No"].AutoIncrementStep = 1;
                    dynamicTable.Columns["S.No"].AutoIncrementSeed = 1;
                }

                for (int j = 0; j <= arrSecond.Length - 1; j++)
                {
                    if (string.IsNullOrEmpty(arrSecond[j]))
                        break;

                    dynamicTable.Rows.Add(null,arrSecond[j]);
                }
                dgScanDetails.DataSource = dynamicTable;
            }
        }
      

        private void btn_ok_click(object sender, EventArgs e)
        {

            bool is_check = false;
            bool is_valid = false;
            string txtQunat = "";
            string txtBatch_no = "";
            string txtSerial_no = "";
            int total_quantity = 0;

            if (dynamicTable.Rows.Count > 0)
            {
                switch (gl_m_stock_type_id)
                {
                    case 1:

                        //check quantity is valid or empty
                        is_valid = oCommonFunction.frmCheckOneNoValidation(txtQuant.Text.Trim());
                        if (is_valid)
                        {
                            is_check = frmSettingDetails.oDbConnection.UpdateQunatity(txtQuant.Text.Trim(), CommonFunction.item_id, gl_po_id, 1, "");
                            if (is_check)
                            {
                                MessageBox.Show("Your captured items are saved successfully.");
                                showForm();
                            }
                        }
                        else
                        {
                            MessageBox.Show("Please enter quantity !!!");
                        }
                        break;
                    case 2:

                        total_quantity = oCommonFunction.concatenateString(out txtBatch_no, out txtQunat, 2, dynamicTable);
                        // is_valid = oCommonFunction.frmCheckTwoNoValidation(txtQunat.Trim(), txtBatch_no.Trim());
                        //if (is_valid)
                        {
                            is_check = frmSettingDetails.oDbConnection.UpdateItemwithBatchNoOrQuantity(txtBatch_no, txtQunat,Convert.ToString(total_quantity), CommonFunction.item_id, gl_po_id, 1, "");
                            if (is_check)
                            {
                                MessageBox.Show("Your captured items are saved successfully.");
                                showForm();
                            }

                        }
                        // else
                        {
                            //txtQuant.BackColor = Color.Red;
                            //txtBatchNo.BackColor = Color.Red;
                            //MessageBox.Show("Please enter quantity or batch no. !!!");
                        }

                        break;
                    case 3:

                        total_quantity = oCommonFunction.concatenateString(out txtBatch_no, out txtSerial_no, 3, dynamicTable);
                        //is_valid = oCommonFunction.frmCheckTwoNoValidation(txtBatchNo.Text.Trim(), "");
                        // if (is_valid)
                        {
                            is_check = frmSettingDetails.oDbConnection.UpdateItemwithBatchAndSerialNo(txtBatch_no, txtSerial_no, Convert.ToString(total_quantity), CommonFunction.item_id, gl_po_id, 1, "");
                            if (is_check)
                            {
                                MessageBox.Show("Your captured items are saved successfully.");
                                showForm();
                            }
                        }
                        // else
                        {
                            // txtBatchNo.BackColor = Color.Red;
                            //txtSerialNo.BackColor = Color.Red;
                            // MessageBox.Show("Please enter batch no. or serial no. !!!");
                        }

                        break;
                    case 4:
                        total_quantity = oCommonFunction.concatenateString(out txtBatch_no, out txtSerial_no, 4, dynamicTable);
                        // is_valid = true;// oCommonFunction.frmCheckOneNoValidation(txtSerialNo.Text.Trim());
                        // if (is_valid)
                        {
                            is_check = frmSettingDetails.oDbConnection.UpdateItemwithSerialNo(txtSerial_no, Convert.ToString(total_quantity), CommonFunction.item_id, gl_po_id, 1, "");
                            if (is_check)
                            {
                                MessageBox.Show("Your captured items are saved successfully.");
                                showForm();
                            }
                        }
                        //  else
                        {
                            //txtSerialNo.ForeColor = Color.Red;
                            // MessageBox.Show("Please enter serial no.!!!");
                        }

                        break;
                }
            }//end if
            else
            {
                MessageBox.Show("Please enter values.!!!");
            }
           
                
        }


     
     
        public DataTable FillDynamicTable(string firstValue, string secondValue,int type)
        {
         
            if (type == 2)
            {
                if (dynamicTable.Rows.Count == 0)
                {
                    dynamicTable.Columns.Add("S.No", typeof(Int32));
                    dynamicTable.Columns.Add("Batch No", typeof(string));
                    dynamicTable.Columns.Add("Quantity", typeof(string));
                    dynamicTable.Columns["S.No"].AutoIncrement = true;
                    dynamicTable.Columns["S.No"].AutoIncrementStep = 1;
                    dynamicTable.Columns["S.No"].AutoIncrementSeed = 1;
                }
                dynamicTable.Rows.Add(null, firstValue, secondValue);
            }
            else if (type == 3)
            {
                if (dynamicTable.Rows.Count == 0)
                {
                    dynamicTable.Columns.Add("S.No", typeof(Int32));
                    dynamicTable.Columns.Add("Batch No", typeof(string));
                    dynamicTable.Columns.Add("Serial No", typeof(string));
                    dynamicTable.Columns["S.No"].AutoIncrement = true;
                    dynamicTable.Columns["S.No"].AutoIncrementStep = 1;
                    dynamicTable.Columns["S.No"].AutoIncrementSeed = 1;
                }
                dynamicTable.Rows.Add(null, firstValue, secondValue);
            }
            else if (type == 4)
            {
                if (dynamicTable.Rows.Count == 0)
                {
                    dynamicTable.Columns.Add("S.No", typeof(Int32));
                    dynamicTable.Columns.Add("Serial No", typeof(string));
                    dynamicTable.Columns["S.No"].AutoIncrement = true;
                    dynamicTable.Columns["S.No"].AutoIncrementStep = 1;
                    dynamicTable.Columns["S.No"].AutoIncrementSeed = 1;
                }
                dynamicTable.Rows.Add(null,secondValue);                

            }
            dgScanDetails.DataSource = dynamicTable;
            return dynamicTable;
        }


        public bool is_check_valid_number(string Value)
        {

            DataColumn[] columns = dynamicTable.Columns.Cast<DataColumn>().ToArray();
            bool anyFieldContainsPepsi = dynamicTable.AsEnumerable()
                .Any(row => columns.Any(col => row[col].ToString() == Value));
            return anyFieldContainsPepsi;
        }

        public void concatenateString(out string firstValue,out string secondValue,int type)
        {
            firstValue = "";
            secondValue = "";
                for (int i = 0; i <= dynamicTable.Rows.Count - 1; i++)
                {
                    DataRow dr = dynamicTable.Rows[i];
                    if(type==2)
                    {
                        if (i == 0)
                        {
                            firstValue = Convert.ToString(dr["Batch No"]);
                            secondValue = Convert.ToString(dr["Quantity"]);
                        }
                        else
                        {
                            firstValue += "#" + Convert.ToString(dr["Batch No"]);
                            secondValue += "#" + Convert.ToString(dr["Quantity"]);
                        }
                       
                       
                    }
                    else if (type == 3)
                    {
                        if(i==0)
                        {

                            firstValue = Convert.ToString(dr["Batch No"]);
                            secondValue = Convert.ToString(dr["Serial No"]);
                        }
                       else
                        {
                            firstValue += "#" + Convert.ToString(dr["Batch No"]);
                            secondValue += "#" + Convert.ToString(dr["Serial No"]);
                        }
                    }
                    else if (type == 4)
                    {
                        if (i == 0)
                        {
                            secondValue = Convert.ToString(dr["Serial No"]);
                        }
                        else
                        {
                            secondValue += "#" + Convert.ToString(dr["Serial No"]);
                        }                  
                    }                  

                }//end for loop        
        }

        public void showForm()
        {
            frmPurchaseOrderItem ofrmPurchaseOrderItem = new frmPurchaseOrderItem();
            ofrmPurchaseOrderItem.Show();
            this.Hide();
        }
       
       
        private void txtQuant_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar >= '0' && e.KeyChar <= '9') //The  character represents a backspace
            {
                txtQuant.BackColor = Color.White;
                e.Handled = false; //Do not reject the input
            }
            else
            {
                txtQuant.BackColor = Color.Red;
                e.Handled = true; //Reject the input
            }
        }

        private void btn_delete_row_click(object sender, EventArgs e)
        {
            int currentRowNo = Convert.ToInt32(this.dgScanDetails.CurrentRowIndex.ToString());
            string get_batch_no = (dgScanDetails[currentRowNo, 0].ToString());

            for (int i = dynamicTable.Rows.Count - 1; i >= 0; i--)
            {
                DataRow dr = dynamicTable.Rows[i];
                string batch_no = dr["S.No"].ToString();
                if(batch_no.Contains(get_batch_no))
                    dr.Delete();
            }
            dgScanDetails.DataSource = dynamicTable;
        }


        private void btnScanSerialNo_click(object sender, EventArgs e)
        {
            //Random rnd = new Random();
            //int a1 = rnd.Next(1000, 10000);
            // txtSerialNo.Text = "abcdef" + a1; // dgScanDetails.CurrentRowIndex;

            txtSerialNo.Text = oCommonFunction.BarcodeScan();
        }

        public void showFormbyCondition1(int type_id)
        {


            if (type_id == 1)
            {
                lblQuntNo.Text = "Quantity";
                lblQuntNo.Width = 96;
                lblQuntNo.Height = 20;
                lblQuntNo.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
                lblQuntNo.Location = new Point(16, 23);
                //text quant
                txtQuant.Width = 50;
                txtQuant.Height = 20;
                txtQuant.Location = new Point(121, 14);
                panel1.Controls.Add(lblQuntNo);
                panel1.Controls.Add(txtQuant);

            }
            else if (type_id == 2)
            {
                lblBathNo.Text = "Batch No";
                lblBathNo.Width = 96;
                lblBathNo.Height = 20;
                lblBathNo.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold); ;
                lblBathNo.Location = new Point(16, 23);

                //txtBatchNo.Text = "";
                txtBatchNo.Width = 90;
                txtBatchNo.Height = 20;
                txtBatchNo.Location = new Point(121, 14);

                lblQuntNo.Text = "Quantity";
                lblQuntNo.Width = 96;
                lblQuntNo.Height = 20;
                lblQuntNo.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
                lblQuntNo.Location = new Point(17, 59);

                //txtQuant.Text = "dasfdasf";
                txtQuant.Width = 50;
                txtQuant.Height = 20;
                txtQuant.Location = new Point(124, 58);
                this.txtQuant.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQuant_KeyPress);

                btnAdd.BackColor = System.Drawing.Color.MediumAquamarine;
                btnAdd.ForeColor = System.Drawing.Color.Black;
                btnAdd.Location = new System.Drawing.Point(118, 105);
                btnAdd.Name = "button1";
                btnAdd.Size = new System.Drawing.Size(72, 20);
                btnAdd.TabIndex = 10;
                btnAdd.Text = "Add";
                btnAdd.Click += new System.EventHandler(this.btnAdd_click);
                // 
                // button2
                // 

                btnClear.BackColor = System.Drawing.Color.MediumAquamarine;
                btnClear.ForeColor = System.Drawing.Color.Black;
                btnClear.Location = new System.Drawing.Point(11, 105);
                btnClear.Name = "button2";
                btnClear.Size = new System.Drawing.Size(72, 20);
                btnClear.TabIndex = 11;
                btnClear.Text = "Clear";
                btnClear.Click += new System.EventHandler(this.btnClear_click);
                //
                panel1.Controls.Add(lblBathNo);
                panel1.Controls.Add(txtBatchNo);
                panel1.Controls.Add(lblQuntNo);
                panel1.Controls.Add(txtQuant);
                panel1.Controls.Add(btnAdd);
                panel1.Controls.Add(btnClear);
            }
            else if (type_id == 3)
            {
                lblBathNo.Text = "Batch No";
                lblBathNo.Width = 96;
                lblBathNo.Height = 20;
                lblBathNo.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold); ;
                lblBathNo.Location = new Point(16, 23);

                txtBatchNo.Width = 90;
                txtBatchNo.Height = 20;
                txtBatchNo.Location = new Point(121, 14);


                txtSerialNo.Width = 105;
                txtSerialNo.Height = 20;
                // txtSerialNo.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
                txtSerialNo.Location = new Point(17, 59);

                //scan serial no.....
                btnScanSerialNo.BackColor = System.Drawing.Color.YellowGreen;
                btnScanSerialNo.ForeColor = System.Drawing.Color.Black;
                btnScanSerialNo.Location = new System.Drawing.Point(125, 58);
                btnScanSerialNo.Name = "button1";
                btnScanSerialNo.Size = new System.Drawing.Size(50, 25);
                btnScanSerialNo.TabIndex = 10;
                btnScanSerialNo.Text = "Scan";
                btnScanSerialNo.Click += new System.EventHandler(this.btnScanSerialNo_click);

                //back color
                btnAdd.BackColor = System.Drawing.Color.MediumAquamarine;
                btnAdd.ForeColor = System.Drawing.Color.Black;
                btnAdd.Location = new System.Drawing.Point(118, 105);
                btnAdd.Name = "button1";
                btnAdd.Size = new System.Drawing.Size(72, 20);
                btnAdd.TabIndex = 10;
                btnAdd.Text = "Add";
                btnAdd.Click += new System.EventHandler(this.btnAdd_click);

                // 
                // button2
                // 
                btnClear.BackColor = System.Drawing.Color.MediumAquamarine;
                btnClear.ForeColor = System.Drawing.Color.Black;
                btnClear.Location = new System.Drawing.Point(11, 105);
                btnClear.Name = "button2";
                btnClear.Size = new System.Drawing.Size(72, 20);
                btnClear.TabIndex = 11;
                btnClear.Text = "Clear";
                btnClear.Click += new System.EventHandler(this.btnClear_click);
                //
                panel1.Controls.Add(lblBathNo);
                panel1.Controls.Add(txtBatchNo);
                panel1.Controls.Add(txtSerialNo);
                panel1.Controls.Add(btnScanSerialNo);
                panel1.Controls.Add(btnAdd);
                panel1.Controls.Add(btnClear);

            }
            else if (type_id == 4)
            {


                txtSerialNo.Width = 105;
                txtSerialNo.Height = 20;
                // txtSerialNo.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
                txtSerialNo.Location = new Point(17, 59);

                //scan serial no.....
                btnScanSerialNo.BackColor = System.Drawing.Color.YellowGreen;
                btnScanSerialNo.ForeColor = System.Drawing.Color.Black;
                btnScanSerialNo.Location = new System.Drawing.Point(125, 58);
                btnScanSerialNo.Name = "button1";
                btnScanSerialNo.Size = new System.Drawing.Size(50, 25);
                btnScanSerialNo.TabIndex = 10;
                btnScanSerialNo.Text = "Scan";
                btnScanSerialNo.Click += new System.EventHandler(this.btnScanSerialNo_click);

                //back color
                btnAdd.BackColor = System.Drawing.Color.MediumAquamarine;
                btnAdd.ForeColor = System.Drawing.Color.Black;
                btnAdd.Location = new System.Drawing.Point(118, 105);
                btnAdd.Name = "button1";
                btnAdd.Size = new System.Drawing.Size(72, 20);
                btnAdd.TabIndex = 10;
                btnAdd.Text = "Add";
                btnAdd.Click += new System.EventHandler(this.btnAdd_click);

                // 
                // button2
                // 
                btnClear.BackColor = System.Drawing.Color.MediumAquamarine;
                btnClear.ForeColor = System.Drawing.Color.Black;
                btnClear.Location = new System.Drawing.Point(11, 105);
                btnClear.Name = "button2";
                btnClear.Size = new System.Drawing.Size(72, 20);
                btnClear.TabIndex = 11;
                btnClear.Text = "Clear";
                btnClear.Click += new System.EventHandler(this.btnClear_click);


                //panel ...................

                panel1.Controls.Add(txtSerialNo);
                panel1.Controls.Add(btnScanSerialNo);
                panel1.Controls.Add(btnAdd);
                panel1.Controls.Add(btnClear);
            }


        }
        public void showFormbyCondition(int type_id)
        {
            if (type_id == 1)
            {
                tabControl1.TabPages.RemoveAt(1);
                lblQuntNo.Text = "Quantity";
                lblQuntNo.Width = 130;
                lblQuntNo.Height = 40;
                lblQuntNo.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
                lblQuntNo.Location = new Point(70, 123);
                //text quant
                txtQuant.Width = 100;
                txtQuant.Height = 40;
                txtQuant.Location = new Point(200, 123);
                panel1.Controls.Add(lblQuntNo);
                panel1.Controls.Add(txtQuant);

            }
            else if (type_id == 2)
            {
                lblBathNo.Text = "Batch No";
                lblBathNo.Width = 130;
                lblBathNo.Height = 40;
                lblBathNo.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold); ;
                lblBathNo.Location = new Point(20, 23);

                //txtBatchNo.Text = "";
                txtBatchNo.Width = 150;
                txtBatchNo.Height = 20;
                txtBatchNo.Location = new Point(150, 23);

                lblQuntNo.Text = "Quantity";
                lblQuntNo.Width = 96;
                lblQuntNo.Height = 40;
                lblQuntNo.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
                lblQuntNo.Location = new Point(20, 100);

                //txtQuant.Text = "dasfdasf";
                txtQuant.Width = 100;
                txtQuant.Height = 20;
                txtQuant.Location = new Point(150, 100);
                this.txtQuant.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQuant_KeyPress);

                btnAdd.BackColor = System.Drawing.Color.MediumAquamarine;
                btnAdd.ForeColor = System.Drawing.Color.Black;
                btnAdd.Location = new System.Drawing.Point(50, 180);
                btnAdd.Name = "button1";
                btnAdd.Size = new System.Drawing.Size(72, 40);
                btnAdd.TabIndex = 10;
                btnAdd.Text = "Add";
                btnAdd.Click += new System.EventHandler(this.btnAdd_click);
                // 
                // button2
                // 

                btnClear.BackColor = System.Drawing.Color.MediumAquamarine;
                btnClear.ForeColor = System.Drawing.Color.Black;
                btnClear.Location = new System.Drawing.Point(160, 180);
                btnClear.Name = "button2";
                btnClear.Size = new System.Drawing.Size(72, 40);
                btnClear.TabIndex = 11;
                btnClear.Text = "Clear";
                btnClear.Click += new System.EventHandler(this.btnClear_click);
                //
                panel1.Controls.Add(lblBathNo);
                panel1.Controls.Add(txtBatchNo);
                panel1.Controls.Add(lblQuntNo);
                panel1.Controls.Add(txtQuant);
                panel1.Controls.Add(btnAdd);
                panel1.Controls.Add(btnClear);
            }
            else if (type_id == 3)
            {
                lblBathNo.Text = "Batch No";
                lblBathNo.Width = 130;
                lblBathNo.Height = 40;
                lblBathNo.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold); ;
                lblBathNo.Location = new Point(20, 23);


                txtBatchNo.Width = 150;
                txtBatchNo.Height = 20;
                txtBatchNo.Location = new Point(150, 23);


                txtSerialNo.Width = 220;
                txtSerialNo.Height = 40;
                // txtSerialNo.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
                txtSerialNo.Location = new Point(20, 100);

                //scan serial no.....
                btnScanSerialNo.BackColor = System.Drawing.Color.YellowGreen;
                btnScanSerialNo.ForeColor = System.Drawing.Color.Black;
                btnScanSerialNo.Location = new System.Drawing.Point(270, 100);
                btnScanSerialNo.Name = "button1";
                btnScanSerialNo.Size = new System.Drawing.Size(80, 40);
                btnScanSerialNo.TabIndex = 10;
                btnScanSerialNo.Text = "Scan";
                btnScanSerialNo.Click += new System.EventHandler(this.btnScanSerialNo_click);

                //back color
                btnAdd.BackColor = System.Drawing.Color.MediumAquamarine;
                btnAdd.ForeColor = System.Drawing.Color.Black;
                btnAdd.Location = new System.Drawing.Point(50, 180);
                btnAdd.Name = "button1";
                btnAdd.Size = new System.Drawing.Size(72, 40);
                btnAdd.TabIndex = 10;
                btnAdd.Text = "Add";
                btnAdd.Click += new System.EventHandler(this.btnAdd_click);

                // 
                // button2
                // 
                btnClear.BackColor = System.Drawing.Color.MediumAquamarine;
                btnClear.ForeColor = System.Drawing.Color.Black;
                btnClear.Location = new System.Drawing.Point(160, 180);
                btnClear.Name = "button2";
                btnClear.Size = new System.Drawing.Size(72, 40);
                btnClear.TabIndex = 11;
                btnClear.Text = "Clear";
                btnClear.Click += new System.EventHandler(this.btnClear_click);
                //
                panel1.Controls.Add(lblBathNo);
                panel1.Controls.Add(txtBatchNo);
                panel1.Controls.Add(txtSerialNo);
                panel1.Controls.Add(btnScanSerialNo);
                panel1.Controls.Add(btnAdd);
                panel1.Controls.Add(btnClear);

            }
            else if (type_id == 4)
            {


                txtSerialNo.Width = 220;
                txtSerialNo.Height = 40;
                // txtSerialNo.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
                txtSerialNo.Location = new Point(20, 100);

                //scan serial no.....
                btnScanSerialNo.BackColor = System.Drawing.Color.YellowGreen;
                btnScanSerialNo.ForeColor = System.Drawing.Color.Black;
                btnScanSerialNo.Location = new System.Drawing.Point(270, 100);
                btnScanSerialNo.Name = "button1";
                btnScanSerialNo.Size = new System.Drawing.Size(80, 40);
                btnScanSerialNo.TabIndex = 10;
                btnScanSerialNo.Text = "Scan";
                btnScanSerialNo.Click += new System.EventHandler(this.btnScanSerialNo_click);

                //back color
                btnAdd.BackColor = System.Drawing.Color.MediumAquamarine;
                btnAdd.ForeColor = System.Drawing.Color.Black;
                btnAdd.Location = new System.Drawing.Point(50, 180);
                btnAdd.Name = "button1";
                btnAdd.Size = new System.Drawing.Size(72, 40);
                btnAdd.TabIndex = 10;
                btnAdd.Text = "Add";
                btnAdd.Click += new System.EventHandler(this.btnAdd_click);

                // 
                // button2
                // 
                btnClear.BackColor = System.Drawing.Color.MediumAquamarine;
                btnClear.ForeColor = System.Drawing.Color.Black;
                btnClear.Location = new System.Drawing.Point(160, 180);
                btnClear.Name = "button2";
                btnClear.Size = new System.Drawing.Size(72, 40);
                btnClear.TabIndex = 11;
                btnClear.Text = "Clear";
                btnClear.Click += new System.EventHandler(this.btnClear_click);


                //panel ...................

                panel1.Controls.Add(txtSerialNo);
                panel1.Controls.Add(btnScanSerialNo);
                panel1.Controls.Add(btnAdd);
                panel1.Controls.Add(btnClear);
            }


        }

        private void btn_description_click(object sender, EventArgs e)
        {
            MessageBox.Show(gl_description, "Description", MessageBoxButtons.OK, MessageBoxIcon.Asterisk, MessageBoxDefaultButton.Button1);
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex == 0)
            {
                //to be done
            }
            else if (tabControl1.SelectedIndex == 1)
            {
                if (dynamicTable.Rows.Count > 0)
                {
                    btndeleterow.Visible = true;
                }
                else
                {
                    btndeleterow.Visible = false;
                }
            }
            else
            {

            }

        }

       
    }
}