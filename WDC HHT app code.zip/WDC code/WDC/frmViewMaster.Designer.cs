﻿namespace WDC
{
    partial class frmViewMaster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.dgItemMaster = new System.Windows.Forms.DataGrid();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_click = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // dgItemMaster
            // 
            this.dgItemMaster.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.dgItemMaster.Location = new System.Drawing.Point(0, 34);
            this.dgItemMaster.Name = "dgItemMaster";
            this.dgItemMaster.Size = new System.Drawing.Size(237, 200);
            this.dgItemMaster.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(50, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 20);
            this.label1.Text = "View Items Details";
            // 
            // btn_click
            // 
            this.btn_click.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btn_click.Location = new System.Drawing.Point(83, 239);
            this.btn_click.Name = "btn_click";
            this.btn_click.Size = new System.Drawing.Size(59, 27);
            this.btn_click.TabIndex = 13;
            this.btn_click.Text = "Back";
            this.btn_click.Click += new System.EventHandler(this.btn_click_Click);
            // 
            // frmViewMaster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.btn_click);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgItemMaster);
            this.Menu = this.mainMenu1;
            this.Name = "frmViewMaster";
            this.Text = "View Item Master";
            this.Load += new System.EventHandler(this.frmViewMaster_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGrid dgItemMaster;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_click;
    }
}