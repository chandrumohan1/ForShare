﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using WDC.Utility;

namespace WDC
{
    public partial class frmSalesOrder : Form
    {
        //DbConnection OdbConnection = null;
        public frmSalesOrder()
        {
            //OdbConnection = new DbConnection();
            InitializeComponent();
        }

        private void frmSalesOrder_Load(object sender, EventArgs e)
        {
            showSalesOrderDeails();
        }


        public void showSalesOrderDeails()
        {
            DataTable table = new DataTable("Table");
            table.Columns.Add("Sale Order", typeof(string));
            table.Columns.Add("Order", typeof(string));
            table.Columns.Add("Rcd", typeof(string));
            DataTable dt = frmSettingDetails.oDbConnection.getSalesOrderDetails();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string SO_Id = Convert.ToString(dt.Rows[i]["ID"]);
                string name = Convert.ToString(dt.Rows[i]["name"]);
                string sales_order_no = Convert.ToString(dt.Rows[i]["SalesOrderNo"]);
                string purchaseOrder = name + "(" + sales_order_no + ")";
                int Count = frmSettingDetails.oDbConnection.getSalesOrderItemCount(Convert.ToInt32(SO_Id));
                string phone_status = Convert.ToString(dt.Rows[i]["phone_status"]);
                string printstatus = "";
                if (phone_status == "2")
                    printstatus = "Pass";
                else if (phone_status == "3")
                    printstatus = "Fail";
                table.Rows.Add(purchaseOrder, Count, printstatus);
            }
            dgSalesOrder.DataSource = table;
            datagridStyleSheet();
            changeGridColor(table);

        }

        private void datagridStyleSheet()
        {
            DataGridTableStyle ts = new DataGridTableStyle();
            ts.MappingName = "Table";

            DataGridTextBoxColumn column1 = new DataGridTextBoxColumn();
            column1.HeaderText = "Sale Order";
            column1.MappingName = "Sale Order";
            column1.Width =290;
            ts.GridColumnStyles.Add(column1);

            DataGridTextBoxColumn column2 = new DataGridTextBoxColumn();
            column2.HeaderText = "Order";
            column2.MappingName = "Order";
            column2.Width = 70;
            ts.GridColumnStyles.Add(column2);

            DataGridTextBoxColumn column3 = new DataGridTextBoxColumn();
            column3.HeaderText = "Rcd";
            column3.MappingName = "Rcd";
            column3.Width = 60;
            ts.GridColumnStyles.Add(column3);           
            this.dgSalesOrder.TableStyles.Add(ts);
        }

        public void changeGridColor(DataTable dt)
        {
            DataGridTableStyle ts = new DataGridTableStyle();
            int index1 = -1;
            bool found = false;


            foreach (DataRow dr in dt.Rows)
            {
                index1++;
                string setStatus = Convert.ToString(dr[2].ToString());

                if (setStatus.Contains("Pass"))
                {
                    dgSalesOrder.Select(index1);
                    dgSalesOrder.SelectionBackColor = Color.Green;

                    // break;
                }
                else if (setStatus.Contains("Fail"))
                {
                    dgSalesOrder.Select(index1);
                    dgSalesOrder.SelectionBackColor = Color.Red;
                }


            }
        }

       

        private void btn_back_Click(object sender, EventArgs e)
        {
            frmSettingDetails OfrmSetting = new frmSettingDetails();
            OfrmSetting.Show();
            this.Hide();
        }

        private void dgSalesOrder_DoubleClick(object sender, EventArgs e)
        {
            int currentRowNo = Convert.ToInt32(this.dgSalesOrder.CurrentRowIndex.ToString());
            if (currentRowNo >= 0)
            {
                //get sales order no....
                CommonFunction.Sales_order_no = dgSalesOrder[currentRowNo, 0].ToString();
                frmSalesOrderItem OfrmSalesOrderItem = new frmSalesOrderItem();
                OfrmSalesOrderItem.Show();
            }
        }

       
    }
}