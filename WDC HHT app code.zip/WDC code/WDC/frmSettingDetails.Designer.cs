﻿namespace WDC
{
    partial class frmSettingDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.btnSync = new System.Windows.Forms.Button();
            this.btnSetting = new System.Windows.Forms.Button();
            this.btnStatus = new System.Windows.Forms.Button();
            this.btndeliver = new System.Windows.Forms.Button();
            this.btnReceive = new System.Windows.Forms.Button();
            this.pcblogo = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnSync
            // 
            this.btnSync.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnSync.ForeColor = System.Drawing.Color.Black;
            this.btnSync.Location = new System.Drawing.Point(15, 214);
            this.btnSync.Name = "btnSync";
            this.btnSync.Size = new System.Drawing.Size(97, 35);
            this.btnSync.TabIndex = 9;
            this.btnSync.Text = "Sync";
            this.btnSync.Click += new System.EventHandler(this.btnSync_Click);
            // 
            // btnSetting
            // 
            this.btnSetting.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnSetting.ForeColor = System.Drawing.Color.Black;
            this.btnSetting.Location = new System.Drawing.Point(131, 157);
            this.btnSetting.Name = "btnSetting";
            this.btnSetting.Size = new System.Drawing.Size(97, 37);
            this.btnSetting.TabIndex = 8;
            this.btnSetting.Text = "Settings";
            this.btnSetting.Click += new System.EventHandler(this.btnSetting_Click);
            // 
            // btnStatus
            // 
            this.btnStatus.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnStatus.ForeColor = System.Drawing.Color.Black;
            this.btnStatus.Location = new System.Drawing.Point(15, 157);
            this.btnStatus.Name = "btnStatus";
            this.btnStatus.Size = new System.Drawing.Size(97, 37);
            this.btnStatus.TabIndex = 7;
            this.btnStatus.Text = "Stock Take";
            this.btnStatus.Click += new System.EventHandler(this.btn_stock_click);
            // 
            // btndeliver
            // 
            this.btndeliver.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btndeliver.ForeColor = System.Drawing.Color.Black;
            this.btndeliver.Location = new System.Drawing.Point(131, 101);
            this.btndeliver.Name = "btndeliver";
            this.btndeliver.Size = new System.Drawing.Size(97, 37);
            this.btndeliver.TabIndex = 6;
            this.btndeliver.Text = "Delivery ";
            this.btndeliver.Click += new System.EventHandler(this.btndeliver_Click);
            // 
            // btnReceive
            // 
            this.btnReceive.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnReceive.ForeColor = System.Drawing.Color.Black;
            this.btnReceive.Location = new System.Drawing.Point(15, 101);
            this.btnReceive.Name = "btnReceive";
            this.btnReceive.Size = new System.Drawing.Size(97, 37);
            this.btnReceive.TabIndex = 5;
            this.btnReceive.Text = "Receipts";
            this.btnReceive.Click += new System.EventHandler(this.btnReceive_Click);
            // 
            // pcblogo
            // 
            this.pcblogo.Location = new System.Drawing.Point(74, 7);
            this.pcblogo.Name = "pcblogo";
            this.pcblogo.Size = new System.Drawing.Size(100, 50);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.MediumAquamarine;
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(131, 214);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(97, 35);
            this.button1.TabIndex = 10;
            this.button1.Text = "Exit";
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(13, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(234, 27);
            this.label3.Text = "Warehouse Data Capture";
            // 
            // frmSettingDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.ClientSize = new System.Drawing.Size(240, 268);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pcblogo);
            this.Controls.Add(this.btnSetting);
            this.Controls.Add(this.btnStatus);
            this.Controls.Add(this.btndeliver);
            this.Controls.Add(this.btnReceive);
            this.Controls.Add(this.btnSync);
            this.Menu = this.mainMenu1;
            this.Name = "frmSettingDetails";
            this.Text = " Home";
            this.Load += new System.EventHandler(this.frmSettingDetails_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnSync;
        private System.Windows.Forms.Button btnSetting;
        private System.Windows.Forms.Button btnStatus;
        private System.Windows.Forms.Button btndeliver;
        private System.Windows.Forms.Button btnReceive;
        private System.Windows.Forms.PictureBox pcblogo;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
    }
}