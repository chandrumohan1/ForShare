﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using WDC.Utility;

namespace WDC
{
    public partial class frmSalesOrderItem : Form
    {
        DbConnection OdbConnection = null;
        CommonFunction oCommonFunction = null;
        int Sales_order_id = 0;

        public frmSalesOrderItem()
        {
            OdbConnection = new DbConnection();
            oCommonFunction = new CommonFunction();
            InitializeComponent();
        }

        private void frmSalesOrderItem_Load(object sender, EventArgs e)
        {
            char[] separators = { '(', ')' };
            string[] poArr = CommonFunction.Sales_order_no.Split(separators);
            lblSoNo.Text = poArr[1].Trim();
            showSalesOrderItemDeails();
        }
        

        public void showSalesOrderItemDeails()
        {
            DataTable table = new DataTable("Table");
            table.Columns.Add("Item_ID", typeof(string));
            table.Columns.Add("Item Code", typeof(string));
            table.Columns.Add("Order", typeof(string));
            table.Columns.Add("Delvd", typeof(string));
            table.Columns.Add("Item_Name", typeof(string));
            DataTable dt = OdbConnection.getSalesOrderItemDetails(CommonFunction.Sales_order_no.Trim());
            for(int i = 0; i < dt.Rows.Count; i++)
            {
                //SO_ID,Item_Name
                Sales_order_id = Convert.ToInt32(dt.Rows[i]["SO_ID"]);
                CommonFunction.SO_ID = Sales_order_id;
                string item_id = Convert.ToString(dt.Rows[i]["item_id"]);
                string Item_no = Convert.ToString(dt.Rows[i]["item_no"]);
                string Item_Name = Convert.ToString(dt.Rows[i]["Item_Name"]);
                string Quantity = Convert.ToString(dt.Rows[i]["Quantity"]);
                string rcd_quantity = Convert.ToString(dt.Rows[i]["rcd_quntity"]);
                int m_stock_type_id = Convert.ToInt32(dt.Rows[i]["m_stock_type_id"]);
                if (m_stock_type_id > 1)
                    rcd_quantity = Convert.ToString(dt.Rows[i]["total_quantity"]);


                if (string.IsNullOrEmpty(rcd_quantity))
                    rcd_quantity = "0";

                bool is_pass = oCommonFunction.enabledPassButton(Convert.ToInt32(Quantity), Convert.ToInt32(rcd_quantity));
                if (is_pass)
                    btn_pass.Enabled = is_pass;

                table.Rows.Add(item_id, Item_no, Quantity, rcd_quantity, Item_Name);
            }
            txtRemarks.Text = CommonFunction.so_remarks;
            dgSalesOrderItem.DataSource = table;
            datagridStyleSheet();
        }

        private void datagridStyleSheet()
        {
            DataGridTableStyle ts = new DataGridTableStyle();
            ts.MappingName = "Table";

            DataGridTextBoxColumn column1 = new DataGridTextBoxColumn();
            column1.HeaderText = "Item_ID";
            column1.MappingName = "Item_ID";
            column1.Width = -1;
            ts.GridColumnStyles.Add(column1);

            DataGridTextBoxColumn column2 = new DataGridTextBoxColumn();
            column2.HeaderText = "Item Code";
            column2.MappingName = "Item Code";
            column2.Width = 200;
            ts.GridColumnStyles.Add(column2);

            DataGridTextBoxColumn column3 = new DataGridTextBoxColumn();
            column3.HeaderText = "Order";
            column3.MappingName = "Order";
            column3.Width = 70;
            ts.GridColumnStyles.Add(column3);

            DataGridTextBoxColumn column4 = new DataGridTextBoxColumn();
            column4.HeaderText = "Delvd";
            column4.MappingName = "Delvd";
            column4.Width = 70;
            ts.GridColumnStyles.Add(column4);

            DataGridTextBoxColumn column5 = new DataGridTextBoxColumn();
            column5.HeaderText = "Item_Name";
            column5.MappingName = "Item_Name";
            column5.Width = 0;
            ts.GridColumnStyles.Add(column5);

            this.dgSalesOrderItem.TableStyles.Add(ts);
        }

        private void btn_pass_click(object sender, EventArgs e)
        {
            //Pass phone_status =2
            Cursor.Current = Cursors.WaitCursor;
            if (Sales_order_id > 0)
            {
                bool is_check = OdbConnection.UpdateSalesOrder(2,txtRemarks.Text, Sales_order_id);
                if (is_check)
                {
                    MessageBox.Show("PO is delivered OK !!! !!!");
                    showForm();

                }
                else
                    MessageBox.Show("Please try again. !!!");
            }
            else
                MessageBox.Show("Please try again. !!!");
            Cursor.Current = Cursors.Default;
        }

        private void btn_fail_click(object sender, EventArgs e)
        {
            //Fail phone_status =3
            Cursor.Current = Cursors.WaitCursor;
            bool is_valid = oCommonFunction.frmCheckOneNoValidation(txtRemarks.Text.Trim());
            if (is_valid)
            {
                if (Sales_order_id > 0)
                {
                    bool is_check = OdbConnection.UpdateSalesOrder(3, txtRemarks.Text.Trim(), Sales_order_id);
                    if (is_check)
                    {
                        MessageBox.Show("Order is marked as Failed !!!");
                        showForm();

                    }
                    else
                        MessageBox.Show("Please try again. !!!");
                }
                else
                    MessageBox.Show("Please try again. !!!");
            }
            else
            {
                MessageBox.Show("Please enter remarks", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1);
            }
           
            Cursor.Current = Cursors.Default;

        }

        private void btn_back_click(object sender, EventArgs e)
        {
            showForm();
        }
        public void showForm()
        {
            frmSalesOrder OfrmSaleOrder = new frmSalesOrder();
            OfrmSaleOrder.Show();
            this.Hide();
        }

        private void dgSalesOrderItem_DoubleClick(object sender, EventArgs e)
        {

            int currentRowNo = Convert.ToInt32(this.dgSalesOrderItem.CurrentRowIndex.ToString());
            if (currentRowNo >= 0)
            {
                //get sales order no....
                string get_item_id = (dgSalesOrderItem[currentRowNo, 0].ToString());
                CommonFunction.item_id = Convert.ToInt32(get_item_id);

                string item_name = (dgSalesOrderItem[currentRowNo, 4].ToString());
             

                frmSalesOrderItemDetails OfrmItemDetails = new frmSalesOrderItemDetails();
                OfrmItemDetails.Text = " " + item_name;
                OfrmItemDetails.Show();
            }
        }  

       
    }
}