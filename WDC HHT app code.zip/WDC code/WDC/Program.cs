﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Data.SqlServerCe;

namespace WDC
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [MTAThread]
        static void Main()
        {

            //check if server details is already exist or not...
            try
            {
                frmServerLocation OfrmServerLocation = new frmServerLocation();
                bool is_check = OfrmServerLocation.getServerPath();
                if (!is_check)
                {
                    Application.Run(OfrmServerLocation); //new frmServerLocation());
                }
                else
                {
                    // Cursor.Current = Cursors.WaitCursor;
                    // OfrmServerLocation.callUserApi();
                    // Cursor.Current = Cursors.Default;
                    Application.Run(new frmLoginScreen());
                }

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }
        }
    }
}