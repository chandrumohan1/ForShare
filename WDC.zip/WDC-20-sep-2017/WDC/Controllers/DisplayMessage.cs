﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WDC.Controllers
{
    public class DisplayMessage
    {
        public static string ErrorMessage = "Some error occurs,kindly contact admin.";
        public static string DataSave = "Data has been saved successfully.";
        public static string VendorCreated = "Vendor  has been created successfully.";
        public static string VendorUpdated = "Vendor details has been updated successfully.";
        public static string VendorDeleted = "Vendor has been deleted successfully.";
        public static string StockCreated = "Stock  has been created successfully.";
        public static string StockUpdated = "Stock  has been updated successfully.";
        public static string StockDeleted = "Stock has been deleted successfully.";
        public static string VendorProductCreated = "Item  has been created successfully.";
        public static string VendorProductUpdated = "Item  has been updated successfully.";
        public static string VendorProductDeleted = "Item has been deleted successfully.";
        public static string CustomerCreated = "Customer has been created successfully.";
        //Manage Unit Message
        public static string UnitCreated = "Unit  has been created successfully.";
        public static string UnitUpdated = "Unit  has been updated successfully.";
        public static string UnitDeleted = "Unit has been deleted successfully.";
        //Location Message
        public static string LocationCreated = "Location  has been created successfully.";
        public static string LocationUpdated = "Location  has been updated successfully.";
        public static string LocationDeleted = "Location has been deleted successfully.";
        public static string ReportSentOnMail = "Report has been sent to given email";
        public static string NoRecord = "No record found.";
        public static string SelectExport = "Select Export type!";
    }
}