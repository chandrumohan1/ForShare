﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WDC.Models;

namespace WDC.Controllers
{
    public class HomeController : Controller
    {
        ApplicationDbContext m_db = new ApplicationDbContext();
        public ActionResult Index()
        {
            ShowDasboard dasboard = new ShowDasboard();
            dasboard.Employees = m_db.Users.Where(a => a.Id != "1").Where(a => a.Is_Active == 1).Count();
            dasboard.Stocks = m_db.stock_details.Where(a=>a.m_stock_status_id!=4).Count();
            dasboard.Vendor = m_db.Vendor_Details.Count();
            dasboard.Items = m_db.Vendor_Products.Count();
            dasboard.Reorder_Level = m_db.stock_details.Where(a => a.Reorder_Level >= a.Current_Stock).Count();
            return View(dasboard);
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}