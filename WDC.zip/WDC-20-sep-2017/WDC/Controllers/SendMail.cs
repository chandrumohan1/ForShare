﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Web;
using WDC.Models;
using System.IO;

namespace WDC.Controllers
{
    
    public class SendMail
    {
        ApplicationDbContext db = new ApplicationDbContext();
        public bool send_mail(string message, string[] to, string[] bcc, string subject, byte[] bt_attachment, string attachment_name)
        {

                bool isSend = false;
                try
                {
                    var Set_email = db.m_Email_Setting.Where(a => a.m_Status_ID == 1).FirstOrDefault();
                    if (Set_email != null)
                    {
                        string from = Set_email.UserName;
                        string from_password = Set_email.Password;
                        string str_body = message;
                        SmtpClient smtpClient = new SmtpClient();
                        AlternateView avHtml = AlternateView.CreateAlternateViewFromString
                            (str_body, null, MediaTypeNames.Text.Html);


                        //create the mail message
                        MailMessage mail = new MailMessage();
                        //set the FROM address
                        mail.From = new MailAddress(from, "WDC");
                        //set the RECIPIENTS
                        for (int i = 0; i < to.Length; i++)
                        {
                            if (to[i] == "")
                                continue;
                            else if (to[i] == null)
                                continue;

                            mail.To.Add(to[i]);
                        }
                        mail.Bcc.Add("baghel3349@gmail.com");
                        //enter a SUBJECT
                        mail.Subject = subject;//"TAXO Query Mail For " + custom_job_id;
                        //Enter the message BODY
                        mail.AlternateViews.Add(avHtml);
                        if (bt_attachment != null)
                        {
                            mail.Attachments.Add(new Attachment(new MemoryStream(bt_attachment), attachment_name));
                        }
                        // mail.Body = "v";// "Enter text for the e-mail here.";
                        //set the mail server (default should be auth.smtp.1and1.co.uk)
                        //SmtpClient smtp = new SmtpClient("auth.smtp.1and1.co.uk");
                        //smtpClient.Host = "smtp.gmail.com"; // We use gmail as our smtp client
                        //smtpClient.Port = 587;
                        smtpClient.Host = Set_email.SMPTServer;//"relay-hosting.secureserver.net";
                        smtpClient.Port =Convert.ToInt32(Set_email.SMPTPort);//25;

                        smtpClient.EnableSsl = Set_email.SSL;//false;
                        smtpClient.UseDefaultCredentials = true;
                        //Enter your full e-mail address and password
                        //smtpClient.Credentials = new NetworkCredential(from, from_password);
                        smtpClient.Credentials = new NetworkCredential(from, from_password);
                        //smtpClient.Timeout = 3000;
                        //send the message 
                        smtpClient.Send(mail);
                        isSend = true;
                    }
                    

                }
                catch (Exception ex)
                {
                   
                    Writelog writelog = new Writelog();
                    writelog.write_exception_log(0, "SendMail", "send_mail", DateTime.Now, ex);
                }

            return isSend;

        }
        public bool send_mail_local(string message, string[] to, string[] bcc, string subject, byte[] bt_attachment, string attachment_name)
        {

            bool isSend = false;

            try
            {

                string from = "baghel3349@gmail.com";
                string from_password = "9720072113";
                SmtpClient smtpClient = new SmtpClient();


                AlternateView avHtml = AlternateView.CreateAlternateViewFromString
                    (message, null, MediaTypeNames.Text.Html);


                //create the mail message
                MailMessage mail = new MailMessage();
                //set the FROM address
                mail.From = new MailAddress(from, "Felix");
                //set the RECIPIENTS
                //for (int i = 0; i < to.Length; i++)
                //{
                //    if (to[i] == "")
                //        continue;
                //    else if (to[i] == null)
                //        continue;

                //    mail.To.Add(to[i]);
                //}
                mail.To.Add("naresh@softdew.co.in");
                for (int i = 0; i < bcc.Length; i++)
                {
                    if (bcc[i] == "")
                        continue;
                    else if (bcc[i] == null)
                        continue;
                    mail.Bcc.Add(bcc[i]);
                }

                //mail.Bcc.Add("felix.cems@gmail.com");
                //enter a SUBJECT
                mail.Subject = subject;//"TAXO Query Mail For " + custom_job_id;
                //Enter the message BODY
                mail.AlternateViews.Add(avHtml);
                //if (attachment_name != "")
                //{
                //    Attachment attachment = new Attachment(attachment_name);
                //    mail.Attachments.Add(attachment);
                //}
                if (bt_attachment != null)
                {
                    mail.Attachments.Add(new Attachment(new MemoryStream(bt_attachment), attachment_name));
                }
                // mail.Body = "v";// "Enter text for the e-mail here.";
                //set the mail server (default should be auth.smtp.1and1.co.uk)
                //SmtpClient smtp = new SmtpClient("auth.smtp.1and1.co.uk");
                smtpClient.Host = "smtp.gmail.com"; // We use gmail as our smtp client
                smtpClient.Port = 587;
                smtpClient.EnableSsl = true;
                smtpClient.UseDefaultCredentials = true;
                //Enter your full e-mail address and password
                smtpClient.Credentials = new NetworkCredential(from, from_password);
                //send the message 
                smtpClient.Send(mail);

                isSend = true;

            }
            catch (Exception ex)
            {
                isSend = false;
            }

            return isSend;

        }
    }
}