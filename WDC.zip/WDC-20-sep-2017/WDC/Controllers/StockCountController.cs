﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WDC.Models;
using Microsoft.AspNet.Identity;
using System.Data;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin.Security;
using System.Globalization;
using System.Data.Entity.Infrastructure;
namespace WDC.Controllers
{
    public class StockCountController : Controller
    {
        ApplicationDbContext m_db = new ApplicationDbContext();
        comman_function cf = null;
        Writelog writelog = null;
        public static List<stock_details> Lst_stock_details = new List<stock_details>();
        #region Create Stock Sheet
        public ActionResult CreateStockCountSheet()
        { 
            return View();
        }
       

        public PartialViewResult PartialCreateStockSheet(int SheetID)
        {
            cf = new comman_function();
            ViewData["SalesListItem"] = cf.GetSalesItemList(0);
            try
            {
                if (SheetID == 0)
                    Lst_stock_details.Clear();

            }
            catch (Exception ex)
            {
                writelog = new Writelog();
                writelog.write_exception_log(0, "StockCountController", "PartialCreateStockSheet", DateTime.Now, ex);
            }
            return PartialView(Lst_stock_details);
        }
        public JsonResult GetStockItem(int ItemID)
        {
            var getStock = m_db.stock_details.Where(a => a.ID == ItemID).FirstOrDefault();
            return Json(getStock, JsonRequestBehavior.AllowGet);

        }
        public JsonResult AddStockItem(int ItemID)
        {
            var getStock = m_db.stock_details.Where(a => a.ID == ItemID).FirstOrDefault();
            var match = Lst_stock_details.FirstOrDefault(p => p.ID == getStock.ID);
            if (match == null)
            {
                Lst_stock_details.Add(getStock);
                return Json("1", JsonRequestBehavior.AllowGet);
            }
            else
                return Json("2", JsonRequestBehavior.AllowGet);
            

        }
       
        public JsonResult DeleteStockSheetItem(int RowID)
        {
            float Status = 0;
            try
            {
                var itemToRemove = Lst_stock_details.Single(r => r.ID == RowID);
                Lst_stock_details.Remove(itemToRemove);
                Status = 1;
            }
            catch { }
            return Json(Status, JsonRequestBehavior.AllowGet);
        }
        public JsonResult SaveStockSheet(string SheetName)
        {
            float Status = 0;
            try
            {
                if (Lst_stock_details.Count > 0)
                {
                    tbl_Stock_Count_Details obStockCountDetails = new tbl_Stock_Count_Details();
                    obStockCountDetails.Stock_Name = SheetName;
                    obStockCountDetails.User_Assigned_ID = 0;
                    obStockCountDetails.m_Status_ID = 1;
                    obStockCountDetails.Date_of_Creation = DateTime.Now;
                    m_db.tbl_Stock_Count_Details.Add(obStockCountDetails);
                    m_db.SaveChanges();
                    foreach (var item in Lst_stock_details)
                    {
                        tbl_Stock_Count_Item_Details obStockSheetItems = new tbl_Stock_Count_Item_Details();
                        obStockSheetItems.tbl_Stock_Count_Details_ID = obStockCountDetails.ID;
                        obStockSheetItems.Stock_Item_ID =Convert.ToInt32(item.ID);
                        obStockSheetItems.Date_of_Creation = DateTime.Now; ;
                        m_db.tbl_Stock_Count_Item_Details.Add(obStockSheetItems);
                        m_db.SaveChanges();
                    }

                    Status = 1;
                }
                else
                    Status = 2;
            }
            catch { }
            return Json(Status, JsonRequestBehavior.AllowGet);
        }
        #endregion
        #region View Stock
        public ActionResult ViewStockCountSheet(int? ddl_AssignedUsers, string txtSheetName)
        {
            cf = new comman_function();
            List<SelectListItem> lst_Employee = cf.GetHHTEmployeeList();
            List<SelectListItem> lst_AllEmployee = cf.GetAllHHTEmployeeList();
            //List<SelectListItem> lst_SOStatus = cf.GetAllSalesOrderStatus();
            ViewData["AllEmployeeList"] = lst_AllEmployee;
            ViewData["EmployeeList"] = lst_Employee;
            List<View_Stock_Count_Details> lst_count_sheet = new List<View_Stock_Count_Details>();
            var GetStockSheet = m_db.tbl_Stock_Count_Details.OrderByDescending(a=>a.ID).ToList();
            if (GetStockSheet != null && ddl_AssignedUsers != null && ddl_AssignedUsers!=0)
                GetStockSheet = GetStockSheet.Where(a => a.User_Assigned_ID == ddl_AssignedUsers).ToList();
            if (GetStockSheet != null && txtSheetName != "" && txtSheetName != null)
                GetStockSheet = GetStockSheet.Where(a => a.Stock_Name.ToLower().Contains(txtSheetName.ToLower())).ToList();

            foreach (var item in GetStockSheet)
            {
                View_Stock_Count_Details count_sheet = new View_Stock_Count_Details();
                count_sheet.ID = item.ID;
                count_sheet.Stock_Name = item.Stock_Name;
                
                count_sheet.Date_of_Creation = item.Date_of_Creation.ToString("dd MMM yyy");
                if (item.User_Assigned_ID != 0)
                {
                    string nameid = Convert.ToString(item.User_Assigned_ID);
                    var details = m_db.Users.Where(m => m.Id == nameid).FirstOrDefault();
                    if (details != null)
                    {
                        if (details.Name == null)
                        {
                            count_sheet.User_Assigned = " ";
                        }
                        else
                        {
                            count_sheet.User_Assigned = details.Name;
                        }
                    }

                }
                else
                {
                    count_sheet.User_Assigned = " ";
                }
                lst_count_sheet.Add(count_sheet);
            }
            return View(lst_count_sheet);
        }
        public PartialViewResult PartialViewStockSheet(int StockSheetID)
        {
            List<stock_details> lst_stock_details = new List<stock_details>();
            var GetPurchaseOrder = (from ob_stock_item in m_db.tbl_Stock_Count_Item_Details.Where(a => a.tbl_Stock_Count_Details_ID == StockSheetID)
                                    join ob_stock in m_db.stock_details on ob_stock_item.Stock_Item_ID equals ob_stock.ID

                                    select new
                                    {
                                        ob_stock = ob_stock,
                                        ob_stock_item = ob_stock_item
                                    }).ToList();
            foreach (var item in GetPurchaseOrder)
            {
                stock_details StockItem = new stock_details();
                StockItem.ID = item.ob_stock.ID;
                StockItem.Item_Name = item.ob_stock.Item_Name;
                StockItem.Item_No = item.ob_stock.Item_No;
                lst_stock_details.Add(StockItem);
            }
            return PartialView(lst_stock_details);
        }
        public JsonResult GetStockSheetAssignedUser(int StockSheetID)
        {
            int AssigneUserID = 0;
            try
            {
                var details = m_db.tbl_Stock_Count_Details.Where(a => a.ID == StockSheetID).FirstOrDefault();
                if (details != null)
                {
                    if (details.User_Assigned_ID != null)
                        AssigneUserID = Convert.ToInt32(details.User_Assigned_ID);
                }
            }
            catch (Exception ex)
            {
                writelog = new Writelog();
                writelog.write_exception_log(0, "StockCountController", "GetStockSheetAssignedUser", DateTime.Now, ex);

            }
            return Json(AssigneUserID, JsonRequestBehavior.AllowGet);
        }
        public JsonResult SaveEmployeeAssignedStockSheet(int StockSheetID, string EmployeeID)
        {
            string Message = "";
            int Status = 0;
            try
            {
                if (StockSheetID != 0)
                {

                    var details = m_db.tbl_Stock_Count_Details.Where(a => a.ID == StockSheetID).FirstOrDefault();
                    //var details1 = m_db.PurchaseOrder_Details.Where(m => m.Id == EmployeeID).FirstOrDefault();
                    if (details != null)
                    {

                        details.User_Assigned_ID = Convert.ToInt16(EmployeeID);

                        m_db.Entry(details).State = EntityState.Modified;
                        m_db.SaveChanges();
                        Status = 1;
                        Message = "Saved";
                    }
                }
                else
                    Message = "Select at least one User!";
            }
            catch (Exception ex)
            {
                writelog = new Writelog();
                writelog.write_exception_log(0, "StockCountController", "SaveEmployeeAssignedStockSheet", DateTime.Now, ex);
                Message = "Error";
            }
            return Json(new { Status = Status, Message = Message }, JsonRequestBehavior.AllowGet);
        }
        #endregion
    }
}