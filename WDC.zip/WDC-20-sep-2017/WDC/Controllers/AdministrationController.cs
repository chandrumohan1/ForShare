﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WDC.Models;
using Microsoft.AspNet.Identity;
using System.Data;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin.Security;
using System.Globalization;
using System.Data.Entity.Infrastructure;

namespace WDC.Controllers
{
    [Authorize]
    public class AdministrationController : Controller
    {
        ApplicationDbContext m_db = new ApplicationDbContext();

        comman_function cf = null;
        Writelog writelog = null;
        public static List<View_SalesOrder_Item> Lst_SalesItems = new List<View_SalesOrder_Item>();
        public static List<View_PurchaseOrder_Item> Lst_purchaseItems = new List<View_PurchaseOrder_Item>();
        // GET: Administration
        #region Email Setting
        public ActionResult EmailSetting()
        {
            var query = m_db.m_Email_Setting.Where(a => a.ID == 1).FirstOrDefault();
            if (query != null)
            {
                return View(query);
            }
            return View();
        }
        [HttpPost]
        public ActionResult EmailSetting(m_Email_Setting model)
        {
            //var transaction = m_db.Database.BeginTransaction();

            if (ModelState.IsValid)
            {
                if (model.ID == 0)
                {
                    model.Date_of_Creation = DateTime.Now;
                    model.m_Status_ID = 1;
                    m_db.m_Email_Setting.Add(model);
                    m_db.SaveChanges();
                }
                else
                {
                    var query = m_db.m_Email_Setting.Where(a => a.ID == 1).FirstOrDefault();
                    if (query != null)
                    {
                        query.SMPTServer = model.SMPTServer;
                        query.SMPTPort = model.SMPTPort;
                        query.SSL = model.SSL;
                        query.UserName = model.UserName;
                        query.Password = model.Password;
                        query.ConfirmPassword = model.ConfirmPassword;
                        m_db.Entry(query).State = EntityState.Modified;
                        m_db.SaveChanges();
                    }
                }
                ViewData["Message"] = DisplayMessage.DataSave;
                //return RedirectToAction("EmailSetting","Administration");
            }
            return View(model);
        }
        #endregion
        #region Barcode Setting
        public ActionResult BarcodeSetting()
        {
            cf = new comman_function();
            Dictionary<string, string> dict = cf.GetField();
            List<SelectListItem> lst = new List<SelectListItem>();
            lst.Add(new SelectListItem { Text = "--Select--", Value = "" });
            foreach (KeyValuePair<string, string> dictionry in dict)
            {
                lst.Add(new SelectListItem { Text = dictionry.Value, Value = dictionry.Key });
            }
            ViewData["ListItem"] = lst;
            return View();
        }
        public PartialViewResult BarCodePartialView()
        {
            
            cf = new comman_function();
            List<m_barcode_setting> lst_barcode = new List<m_barcode_setting>();
            try
            {
                Dictionary<string, string> dict = cf.GetField();

                m_barcode_setting barcode = null;
                var get = m_db.m_barcode_setting.OrderByDescending(a=>a.ID).ToList();
                foreach (var filed in get)
                {
                    barcode = new m_barcode_setting();
                    barcode.Prefix = filed.Prefix;
                    barcode.Firest_Field = "Item Code";
                    barcode.Second_Field = dict[filed.Second_Field];
                    barcode.Third_Field = dict[filed.Third_Field];
                    barcode.m_Status_ID = filed.m_Status_ID;
                    barcode.Date_of_Creation = filed.Date_of_Creation;
                    lst_barcode.Add(barcode);
                }
            }
            catch (Exception ex)
            {
                int UserID = Convert.ToInt32(User.Identity.GetUserId());
                writelog = new Writelog();
                writelog.write_exception_log(UserID, "AdministrationController", "BarCodePartialView", DateTime.Now, ex);
            }
            return PartialView(lst_barcode);
        }
        [HttpPost]
        public JsonResult UpdateBarcodeSetting(string prfx, string first, string second, string third)
        {
            string message = "Not Update.";
            try
            {
                cf = new comman_function();
               // Dictionary<string, string> dict = cf.GetField();
               // Master_Modification_History m_history = new Master_Modification_History();
                using (var transaction = cf.CreateTransactionScope())
                {
                    var get = m_db.m_barcode_setting.Where(a => a.m_Status_ID == 1).ToList();
                    if (get != null)
                    {
                        get.ForEach(a => a.m_Status_ID = 0);
                        m_db.SaveChanges();
                       // m_history.Current_Value = get[0].Prefix + "/" + dict[get[0].Firest_Field] + "/" + dict[get[0].Second_Field] + "/" + dict[get[0].Third_Field];
                    }
                    m_barcode_setting addbarcode = new m_barcode_setting();
                    addbarcode.Prefix = prfx;
                    addbarcode.Firest_Field = first;
                    addbarcode.Second_Field = second;
                    addbarcode.Third_Field = third;
                    addbarcode.m_Status_ID = 1;
                    addbarcode.Date_of_Creation = DateTime.Now;
                    m_db.m_barcode_setting.Add(addbarcode);
                    m_db.SaveChanges();

                    //m_history.DB_ID = addbarcode.ID;
                    //m_history.Change_Date = DateTime.Now;

                    //m_history.New_Value = prfx + "/" + dict[first] + "/" + dict[second] + "/" + dict[third];
                    //m_history.Master_Type = "Barcode Settings";
                    //m_history.m_Master_Action_Type = 1;
                    //m_db.Master_Modification_History.Add(m_history);
                    //m_db.SaveChanges();
                    transaction.Complete();
                }
                message = DisplayMessage.DataSave;


            }
            catch (Exception ex)
            {
                int UserID = Convert.ToInt32(User.Identity.GetUserId());
                message = DisplayMessage.ErrorMessage;
                writelog = new Writelog();
                writelog.write_exception_log(UserID, "AdministrationController", "UpdateBarcodeSetting", DateTime.Now, ex);
            }
            return Json(message, JsonRequestBehavior.AllowGet);
        }
        public PartialViewResult ViewBarcodePartial()
        {
            return PartialView();
        }
        #endregion
        #region Report Color Setting
        public ActionResult ReportColorSetting()
        {
            var get = m_db.m_Report_Color.Where(a => a.m_Status_ID == 1).FirstOrDefault();
            if (get != null)
                return View(get);
            else
                return View();
        }
        [HttpPost]
        public ActionResult ReportColorSetting(m_Report_Color color)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    cf = new comman_function();
                    //Master_Modification_History m_history = new Master_Modification_History();
                    using (var transaction = cf.CreateTransactionScope())
                    {
                        var get = m_db.m_Report_Color.Where(a => a.m_Status_ID == 1).ToList();
                        if (get != null)
                        {
                            get.ForEach(a => a.m_Status_ID = 0);
                            m_db.SaveChanges();
                            //m_history.Current_Value = get[0].HeaderRow_BackColor + "/" + get[0].HeaderRow_ForColor + "/" + get[0].RowStyle_BackColor;
                        }

                        m_Report_Color dcolor = new m_Report_Color();
                        dcolor.HeaderRow_BackColor = color.HeaderRow_BackColor;
                        dcolor.HeaderRow_ForColor = color.HeaderRow_ForColor;
                        dcolor.RowStyle_BackColor = color.RowStyle_BackColor;
                        dcolor.Date_of_Creation = DateTime.Now;
                        dcolor.m_Status_ID = 1;
                        m_db.m_Report_Color.Add(dcolor);
                        m_db.SaveChanges();
                        //m_history.DB_ID = dcolor.ID;
                        //m_history.Change_Date = DateTime.Now;
                        //m_history.New_Value = color.HeaderRow_BackColor + "/" + color.HeaderRow_ForColor + "/" + color.RowStyle_BackColor;
                        //m_history.Master_Type = "ReportColorSettings";
                        //m_history.m_Master_Action_Type = 3;
                        //m_db.Master_Modification_History.Add(m_history);
                        //m_db.SaveChanges();
                        transaction.Complete();
                        ViewData["Message"] =  DisplayMessage.DataSave;
                    }
                }
                catch (Exception ex)
                {
                    ViewData["Message"] = DisplayMessage.ErrorMessage;
                    writelog = new Writelog();
                    writelog.write_exception_log(0, "AdministrationController", "ReportColorSetting", DateTime.Now, ex);
                }

            }
            return View(color);
        }
        #endregion
        #region Create Vender
        [HttpGet]
        public ActionResult CreateVendor(int? ID)
        {
            cf = new comman_function();
            ViewData["CountryList"] = cf.GetCountry(0);
            if (ID != null && ID != 0)
            {
                var model = m_db.Vendor_Details.Where(v => v.ID == ID).FirstOrDefault();
                return View(model);
            }
            return View();
        }
        [HttpPost]
        public ActionResult CreateVendor(Vendor_Details vendor)
        {
            int UserID = 0;
            //RetMessage message = new RetMessage();
            try
            {

                UserID = Convert.ToInt32(User.Identity.GetUserId());
                cf = new comman_function();
                if (ModelState.IsValid)
                {
                    var GetVender = m_db.Vendor_Details.Where(v => v.ID == vendor.ID).FirstOrDefault();
                    if (GetVender == null)
                    {
                        vendor.Created_By = UserID;
                        vendor.Date_of_Creation = DateTime.Now;
                        m_db.Vendor_Details.Add(vendor);
                        m_db.SaveChanges();
                        ViewData["ID"] = 1;
                        ViewData["Message"] = DisplayMessage.VendorCreated;
                    }
                    else
                    {
                        GetVender.Vendor_Name = vendor.Vendor_Name;
                        GetVender.Website_link = vendor.Website_link;
                        GetVender.Contact_Person_Name = vendor.Contact_Person_Name;
                        GetVender.Email_ID = vendor.Email_ID;
                        GetVender.Mobile = vendor.Mobile;
                        GetVender.Fax = vendor.Fax;
                        GetVender.Address = vendor.Address;
                        GetVender.m_Country_ID = vendor.m_Country_ID;
                        GetVender.State = vendor.State;
                        GetVender.City = vendor.City;
                        GetVender.ZIP = vendor.ZIP;
                        m_db.Entry(GetVender).State = EntityState.Modified;
                        m_db.SaveChanges();
                        ViewData["ID"] = 2;
                        ViewData["Message"] = DisplayMessage.VendorUpdated;
                    }
                }
                ViewData["CountryList"] = cf.GetCountry(0);
            }
            catch (Exception ex)
            {

                writelog = new Writelog();
                writelog.write_exception_log(UserID, "AdministrationController", "CreateVender", DateTime.Now, ex);
            }
            return View(vendor);
        }
        #endregion
        #region View Vender
        public ActionResult ViewVendor()
        {
            List<ViewVendor_Details> lst_vendor = new List<ViewVendor_Details>();
            var model = (from obj_vendor in m_db.Vendor_Details
                         join obj_country in m_db.tbl_Country on obj_vendor.m_Country_ID equals obj_country.id
                         select new
                         {
                             obj_vendor = obj_vendor,
                             obj_country = obj_country
                         }).ToList();
            if (model != null)
            {
                foreach (var item in model)
                {
                    ViewVendor_Details GetVendor = new ViewVendor_Details();
                    GetVendor.ID = item.obj_vendor.ID;
                    GetVendor.Vendor_Name = item.obj_vendor.Vendor_Name;
                    GetVendor.Contact_Person_Name = item.obj_vendor.Contact_Person_Name;
                    GetVendor.Email_ID = item.obj_vendor.Email_ID;
                    GetVendor.Mobile = item.obj_vendor.Mobile;
                    GetVendor.Fax = item.obj_vendor.Fax;
                    GetVendor.Address = item.obj_vendor.Address;
                    GetVendor.Country = item.obj_country.countryname;
                    GetVendor.State = item.obj_vendor.State;
                    GetVendor.City = item.obj_vendor.City;
                    GetVendor.ZIP = item.obj_vendor.ZIP;
                    lst_vendor.Add(GetVendor);
                }
            }
            return View(lst_vendor);
        }
        public JsonResult DeleteVendor(int id)
        {
            RetMessage message = new RetMessage();
            try
            {
                var GetVendor = m_db.Vendor_Details.Where(v => v.ID == id).FirstOrDefault();
                if (GetVendor != null)
                {
                    m_db.Vendor_Details.Remove(GetVendor);
                    m_db.SaveChanges();
                    message.ID = 1;
                    message.Message = DisplayMessage.VendorDeleted;
                }

            }
            catch (Exception ex)
            {
                message.ID = 0;
                message.Message = DisplayMessage.ErrorMessage;
            }
            return Json(message, JsonRequestBehavior.AllowGet);
        }
        #endregion
        #region Vendor Product
        public ActionResult VendorProduct(int ID)
        {
            cf = new comman_function();
            ViewData["StockItemList"] = cf.GetStockItemList();

            return View();
        }
        public JsonResult GetStockUnit(int ID)
        {
            string Unit = "";
            var GetStock = m_db.stock_details.Where(a => a.ID == ID).FirstOrDefault();
            if (GetStock != null)
            {
                var get = m_db.m_Stock_Unit.Where(a => a.ID == GetStock.m_Stock_Unit_ID).FirstOrDefault();
                if (get != null)
                {
                    Unit = get.Unit;
                }
            }
            return Json(Unit, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public JsonResult VendorProduct(Vendor_Products addproduct)
        {
            RetMessage message = new RetMessage();
            if (ModelState.IsValid)
            {
                if (addproduct.ID == 0 || addproduct.ID == null)
                {
                    addproduct.Date_of_Creation = DateTime.Now;
                    m_db.Vendor_Products.Add(addproduct);
                    m_db.SaveChanges();
                    message.ID = 1;
                    message.Message = DisplayMessage.VendorProductCreated;
                }
                else
                {
                    var get = m_db.Vendor_Products.Where(a => a.ID == addproduct.ID).FirstOrDefault();
                    if (get != null)
                    {
                        get.Product_ID = addproduct.Product_ID;
                        get.Item_No = addproduct.Item_No;
                        get.Cost = addproduct.Cost;
                        get.Lead_Time = addproduct.Lead_Time;
                        get.Description = addproduct.Description;
                        m_db.SaveChanges();
                        message.ID = 1;
                        message.Message = DisplayMessage.VendorProductUpdated;
                    }

                }

            }
            return Json(message, JsonRequestBehavior.AllowGet);
        }
        public PartialViewResult ViewPartialVendorProduct(int? VendorID)
        {
            cf = new comman_function();
            List<ViewVendor_Products> lst_barcode = new List<ViewVendor_Products>();
            try
            {
                if (VendorID != null)
                {
                    var get = (from obj_product in m_db.Vendor_Products.Where(a => a.Vendor_ID == VendorID)
                               join obj_stock in m_db.stock_details.Where(a => a.m_stock_status_id != 4) on obj_product.Product_ID equals obj_stock.ID
                               select new
                               {
                                   obj_stock = obj_stock,
                                   obj_product = obj_product
                               }).ToList();


                    foreach (var item in get)
                    {
                        ViewVendor_Products product = new ViewVendor_Products();
                        product.ID = item.obj_product.ID;
                        product.Product_Name = item.obj_stock.Item_Name;
                        product.Item_No = item.obj_product.Item_No;
                        product.Cost = item.obj_product.Cost;
                        product.Lead_Time = item.obj_product.Lead_Time;
                        product.Description = item.obj_product.Description;
                        product.Date_of_Creation = item.obj_product.Date_of_Creation;
                        lst_barcode.Add(product);
                    }
                }

            }
            catch (Exception ex)
            {
                writelog = new Writelog();
                writelog.write_exception_log(0, "AdministrationController", "ViewPartialVendorProduct", DateTime.Now, ex);
            }
            return PartialView(lst_barcode);
        }
        public JsonResult DeleteVendorProduct(int ProductID)
        {
            RetMessage message = new RetMessage();
            var get = m_db.Vendor_Products.Where(a => a.ID == ProductID).FirstOrDefault();
            if (get != null)
            {
                m_db.Vendor_Products.Remove(get);
                m_db.SaveChanges();
                message.ID = 1;
                message.Message = DisplayMessage.VendorProductDeleted;
            }

            return Json(message, JsonRequestBehavior.AllowGet);
        }
        public JsonResult EditVendorProduct(int ProductID)
        {
            Vendor_Products product = new Vendor_Products();
            var get = m_db.Vendor_Products.Where(a => a.ID == ProductID).FirstOrDefault();
            if (get != null)
            {
                product.ID = get.ID;
                product.Product_ID = get.Product_ID;
                product.Description = get.Description;
                product.Cost = get.Cost;
                product.Lead_Time = get.Lead_Time;
                product.Item_No = get.Item_No;
            }
            return Json(product, JsonRequestBehavior.AllowGet);
        }
        #endregion
        #region Location
        public ActionResult LocationDetails(int? ID)
        {
            if (ID != null)
            {
                var getLocation = m_db.Location_Details.Where(a => a.ID == ID).FirstOrDefault();
                if (getLocation != null)
                {
                    ViewBag.Title = "Edit Location";
                    return View(getLocation);
                }
                else
                {
                    ViewBag.Title = "Add New Location";
                    return View();
                }
            }
            else
            {
                ViewBag.Title = "Add New Location";
                return View();
            }
        }
        [HttpPost]
        public ActionResult LocationDetails(Location_Details location)
        {
            location.Parent_ID = 0;
            if (ModelState.IsValid)
            {
                var getLocation = m_db.Location_Details.Where(a => a.ID == location.ID).FirstOrDefault();
                if (getLocation == null)
                {
                    Location_Details loc = new Location_Details();
                    loc.Area = location.Area;
                    loc.Parent_ID = location.Parent_ID;
                    loc.Date_of_Creation = DateTime.Now;
                    m_db.Location_Details.Add(loc);
                    m_db.SaveChanges();

                }
                else
                {
                    getLocation.Area = location.Area;
                    m_db.Entry(getLocation).State = EntityState.Modified;
                    m_db.SaveChanges();
                    ViewData["Message"] = "Location Has been updated successfully.";
                }

                location.Area = "";
                return View();

            }
            else
                return View(location);
        }
        public PartialViewResult ViewPartialLocation()
        {
            //cf = new comman_function();
            List<Location_Details> lst_barcode = new List<Location_Details>();
            try
            {
                var get = m_db.Location_Details.Where(a => a.Parent_ID == 0).ToList();
                foreach (var item in get)
                {
                    Location_Details loc = new Location_Details();
                    loc.ID = item.ID;
                    loc.Area = item.Area;
                    loc.Parent_ID = item.Parent_ID;
                    loc.Date_of_Creation = DateTime.Now;
                    lst_barcode.Add(loc);
                }
            }
            catch (Exception ex)
            {
                writelog = new Writelog();
                writelog.write_exception_log(0, "AdministrationController", "ViewPartialVendorProduct", DateTime.Now, ex);
            }
            return PartialView(lst_barcode);
        }
        public JsonResult DeleteLocation(int ID)
        {
            RetMessage message = new RetMessage();
            var get = m_db.Location_Details.Where(a => a.ID == ID).FirstOrDefault();
            if (get != null)
            {
                m_db.Location_Details.Remove(get);
                m_db.SaveChanges();
                message.ID = 1;
                message.Message = "Location has been deleted successfully.";
            }
            return Json(message, JsonRequestBehavior.AllowGet);
        }
        #endregion
        #region Sub Location
        public ActionResult SubLocation(int ID)
        {

            var getLocation = m_db.Location_Details.Where(a => a.ID == ID).FirstOrDefault();
            if (getLocation != null)
            {
                cf = new comman_function();
                ViewData["LocationList"] = cf.GetLocationList();
                return View(getLocation);
            }
            else
            {

                return View();
            }
        }
        [HttpPost]
        public JsonResult AddSubLocation(Location_Details location)
        {
            RetMessage message = new RetMessage();
            try
            {
                if (location.ID == 0 || location.ID == null)
                {
                    location.Date_of_Creation = DateTime.Now;
                    m_db.Location_Details.Add(location);
                    m_db.SaveChanges();
                    message.ID = 1;
                    message.Message = DisplayMessage.LocationCreated;
                }
                else
                {
                    var getLocation = m_db.Location_Details.Where(a => a.ID == location.ID).FirstOrDefault();
                    if (getLocation != null)
                    {
                        getLocation.Area = location.Area;
                        m_db.SaveChanges();
                        message.ID = 1;
                        message.Message = DisplayMessage.LocationUpdated;

                    }
                }
            }
            catch (Exception ex)
            {
                message.ID = 0;
                message.Message = "Error";
                writelog = new Writelog();
                writelog.write_exception_log(0, "AdministrationController", "AddSubLocation", DateTime.Now, ex);
            }
            return Json(message, JsonRequestBehavior.AllowGet);
        }
        public JsonResult EditSubLocation(int ID)
        {
            var get = m_db.Location_Details.Where(a => a.ID == ID).FirstOrDefault();
            return Json(get, JsonRequestBehavior.AllowGet);
        }
        public JsonResult DeleteSubLocation(int ID)
        {
            RetMessage message = new RetMessage();
            var getLocation = m_db.Location_Details.Where(a => a.ID == ID).FirstOrDefault();
            if (getLocation != null)
            {
                m_db.Location_Details.Remove(getLocation);
                m_db.SaveChanges();
                message.ID = 1;
                message.Message = DisplayMessage.LocationDeleted;
            }
            return Json(message, JsonRequestBehavior.AllowGet);
        }
        public PartialViewResult ViewPartialSubLocation(int LocID)
        {
            List<Location_Details> lst_loc = new List<Location_Details>();
            try
            {
                var get = m_db.Location_Details.Where(a => a.Parent_ID == LocID).ToList();
                foreach (var item in get)
                {
                    Location_Details loc = new Location_Details();
                    loc.ID = item.ID;
                    loc.Area = item.Area;
                    loc.Parent_ID = item.Parent_ID;
                    loc.Date_of_Creation = DateTime.Now;
                    lst_loc.Add(loc);
                }
            }
            catch (Exception ex)
            {
                writelog = new Writelog();
                writelog.write_exception_log(0, "AdministrationController", "ViewPartialSubLocation", DateTime.Now, ex);
            }
            return PartialView(lst_loc);
        }
        #endregion
        #region Unit
        public ActionResult ManageUnit()
        {
            return View();
        }
        [HttpPost]
        public JsonResult ManageUnit(m_Stock_Unit stock)
        {
            RetMessage message = new RetMessage();
            if (ModelState.IsValid)
            {
                if (stock.ID == 0 || stock.ID == null)
                {
                    m_db.m_Stock_Unit.Add(stock);
                    m_db.SaveChanges();
                    message.ID = 1;
                    message.Message = DisplayMessage.UnitCreated;
                }
                else
                {
                    var get = m_db.m_Stock_Unit.Where(a => a.ID == stock.ID).FirstOrDefault();
                    if (get != null)
                    {

                        get.Unit = stock.Unit;
                        get.m_Status_ID = stock.m_Status_ID;
                        m_db.SaveChanges();
                        message.ID = 1;
                        message.Message = DisplayMessage.UnitUpdated;
                    }

                }

            }
            return Json(message, JsonRequestBehavior.AllowGet);
        }
        public PartialViewResult ViewPartialUnit(int? VendorID)
        {
            List<m_Stock_Unit> lst_barcode = new List<m_Stock_Unit>();
            try
            {
                if (VendorID != null)
                {
                    var get = m_db.m_Stock_Unit.ToList();


                    foreach (var item in get)
                    {
                        m_Stock_Unit Unit = new m_Stock_Unit();
                        Unit.ID = item.ID;
                        Unit.Unit = item.Unit;
                        Unit.m_Status_ID = item.m_Status_ID;
                        lst_barcode.Add(Unit);
                    }
                }

            }
            catch (Exception ex)
            {
                writelog = new Writelog();
                writelog.write_exception_log(0, "AdministrationController", "ViewPartialUnit", DateTime.Now, ex);
            }
            return PartialView(lst_barcode);
        }
        public JsonResult DeleteUnit(int UnitID)
        {
            RetMessage message = new RetMessage();
            var get = m_db.m_Stock_Unit.Where(a => a.ID == UnitID).FirstOrDefault();
            if (get != null)
            {
                m_db.m_Stock_Unit.Remove(get);
                m_db.SaveChanges();
                message.ID = 1;
                message.Message = DisplayMessage.UnitDeleted;
            }

            return Json(message, JsonRequestBehavior.AllowGet);
        }
        public JsonResult EditUnit(int ID)
        {

            var get = m_db.m_Stock_Unit.Where(a => a.ID == ID).FirstOrDefault();

            return Json(get, JsonRequestBehavior.AllowGet);
        }
        #endregion
        #region Customer
        public ActionResult CreateCustomer()
        {

            return View();
        }
        [HttpPost]
        public ActionResult CreateCustomer(Customer_Details customer)
        {
            int UserID = 0;
            try
            {
                UserID = Convert.ToInt32(User.Identity.GetUserId());
                //customer.ID = 0;
                if (ModelState.IsValid)
                {
                    var Getcustomer = m_db.Customer_Details.Where(v => v.ID == customer.ID).FirstOrDefault();
                    if (Getcustomer == null)
                    {
                        customer.Created_On = DateTime.Now;
                        m_db.Customer_Details.Add(customer);
                        m_db.SaveChanges();
                        ViewData["Message"] = DisplayMessage.CustomerCreated;
                        return View();
                    }
                    else
                        return View(customer);
                }
                else return View(customer);
            }
            catch (Exception ex)
            {
                writelog = new Writelog();
                writelog.write_exception_log(UserID, "AdministrationController", "CreateCustomer", DateTime.Now, ex);
                return View(customer);
            }
        }
        public ActionResult ViewCustomer()
        {
            var GetCustomer = m_db.Customer_Details.ToList();
            return View(GetCustomer);
        }
        public JsonResult DeleteCustomer(int ID)
        {
            RetMessage message = new RetMessage();
            var get = m_db.Customer_Details.Where(a => a.ID == ID).FirstOrDefault();
            if (get != null)
            {
                m_db.Customer_Details.Remove(get);
                m_db.SaveChanges();
                message.ID = 1;
                message.Message = "Customer information has been deleted successfully.";
            }
            return Json(message, JsonRequestBehavior.AllowGet);
        }
        public ActionResult EditCustomer(int ID)
        {
            var query = m_db.Customer_Details.Where(a => a.ID == ID).FirstOrDefault();
            if (query != null)
            {
                Customer_Details profile = new Customer_Details();
                profile.name = query.name;
                profile.ContactPerson = query.ContactPerson;
                profile.Phone_No = query.Phone_No;
                profile.Email_ID = query.Email_ID;
                profile.Address = query.Address;
                profile.Is_Active = query.Is_Active;
                return View(profile);
            }
            return View();
        }
        [HttpPost]
        public ActionResult EditCustomer(Customer_Details model)
        {
            if (ModelState.IsValid)
            {
                //ApplicationDbContext m_db = new ApplicationDbContext();
                var query = m_db.Customer_Details.Where(a => a.ID == model.ID).FirstOrDefault();
                if (query != null)
                {
                    query.name = model.name;
                    query.ContactPerson = model.ContactPerson;
                    query.Phone_No = model.Phone_No;
                    query.Email_ID = model.Email_ID;
                    query.Address = model.Address;
                    query.Is_Active = model.Is_Active;

                    m_db.Entry(query).State = EntityState.Modified;
                    m_db.SaveChanges();
                    ViewData["Message"] = DisplayMessage.DataSave;
                }
                return View(model);
            }
            else
                return View();
        }
        #endregion
        #region Sales Order

        public ActionResult CreateSalesOrder()
        {
            cf = new comman_function();
            List<SelectListItem> lst_Sales = cf.GetClientList();

            ViewData["SalesListItems"] = lst_Sales;
            return View();
        }
        public PartialViewResult SalesOrderPartial(int ID)
        {
            cf = new comman_function();
            ViewData["SalesListItem"] = cf.GetSalesItemList(ID);
            try
            {
                if (ID == 0)
                    Lst_SalesItems.Clear();

            }
            catch (Exception ex)
            {
                writelog = new Writelog();
                writelog.write_exception_log(0, "AdministrationController", "SalesOrderPartial", DateTime.Now, ex);
            }
            return PartialView(Lst_SalesItems);
        }

        //Delete Sales Item
        public JsonResult DeleteSalesItem(int id)
        {
            RetMessage message = new RetMessage();
            var getStock = m_db.stock_details.Where(a => a.ID == id).FirstOrDefault();
            if (getStock != null)
            {
                m_db.stock_details.Remove(getStock);
                m_db.SaveChanges();
                message.ID = 1;
                message.Message = DisplayMessage.StockDeleted;
            }
            return Json(message, JsonRequestBehavior.AllowGet);

        }
        public JsonResult GetClientItemCost(int ItemID)
        {
            float ItemCost = 0;

            var itemList = m_db.stock_details.Where(a => a.ID == ItemID).FirstOrDefault();
            if (itemList != null)
            {
                ItemCost = itemList.Cost_per_Item;
            }
            return Json(ItemCost, JsonRequestBehavior.AllowGet);
        }

        public static int itemlistcount = 0;
        public JsonResult PostSalesOrderItem(int ItemID, string ItemName, float Quantity, float Item_Cost)
        {
            itemlistcount++;
            float Status = 0;
            View_SalesOrder_Item item = new View_SalesOrder_Item();
            item.ID = itemlistcount;
            item.Item_ID = ItemID;
            item.Item_Name = ItemName;
            item.Quantity = Quantity;
            item.Cost_Per_Item = Item_Cost;
            Lst_SalesItems.Add(item);
            Status = 1;
            return Json(Status, JsonRequestBehavior.AllowGet);
        }
        public JsonResult SaveSalesOrder(int customerID, DateTime DateOfOrder, DateTime ExpectedDateOfDelivery, string Sales_Order_Number)
        {
            try
            {
                if (Lst_SalesItems.Count > 0)
                {
                    Sales_Order_Details order = new Sales_Order_Details();
                    order.Customer_ID = customerID;
                    order.DateOfOrder = DateOfOrder;
                    order.ExpectedDateOfDelivery = ExpectedDateOfDelivery;
                    order.tbl_Sales_Order_Status_ID = 1;
                    order.SalesOrderNo = Sales_Order_Number;
                    order.Remarks = "";
                    m_db.Sales_Order_Details.Add(order);
                    m_db.SaveChanges();

                    foreach (var item in Lst_SalesItems)
                    {
                        Sales_Order_Item_Details order_items = new Sales_Order_Item_Details();
                        order_items.sales_Order_Detail_ID = order.ID;
                        order_items.Item_ID = item.Item_ID;
                        order_items.Quantity = item.Quantity;
                        order_items.Batch_No = "";
                        order_items.Serial_No = "";
                        order_items.Scan_Value = "";
                        order_items.Delivered_Quntity = 0;
                        order_items.Cost_Per_Item = item.Cost_Per_Item;
                        m_db.Sales_Order_Item_Details.Add(order_items);
                        m_db.SaveChanges();
                    }

                    return Json(new { Status = 1, Message = "Saved" }, JsonRequestBehavior.AllowGet);
                }
                else
                    return Json(new { Status = 0, Message = "Please select atleast one item!" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                writelog = new Writelog();
                writelog.write_exception_log(0, "AdministrationController", "SavPurchaseOrder", DateTime.Now, ex);

            }
            return Json(new { Status = 0, Message = "Error" }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult DeletePostSalesItem(int RowID)
        {
            float Status = 0;
            try
            {
                Lst_SalesItems.RemoveAt(RowID - 1);
                Status = 1;
            }
            catch { }
            return Json(Status, JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetSOAssignedUser(int SO_ID)
        {
            int AssigneUserID = 0;
            try
            {
                var details = m_db.Sales_Order_Details.Where(a => a.ID == SO_ID).FirstOrDefault();
                if (details != null)
                {
                    if (details.Assigned_User_ID != null)
                        AssigneUserID = Convert.ToInt32(details.Assigned_User_ID);
                }
            }
            catch (Exception ex)
            {
                writelog = new Writelog();
                writelog.write_exception_log(0, "AdministrationController", "GetSOAssignedUser", DateTime.Now, ex);

            }
            return Json(AssigneUserID, JsonRequestBehavior.AllowGet);
        }
        public ActionResult ViewSalesOrder(int? ddl_Client, string txtSalesOrderNo, int? ddl_AssignedUsers, int? ddl_status)
        {
            cf = new comman_function();
            List<SelectListItem> lst_Client = cf.GetAllClientList();
            List<SelectListItem> lst_Employee = cf.GetHHTEmployeeList();
            List<SelectListItem> lst_AllEmployee = cf.GetAllHHTEmployeeList();
            List<SelectListItem> lst_SOStatus = cf.GetAllSalesOrderStatus();
            ViewData["AllEmployeeList"] = lst_AllEmployee;
            ViewData["EmployeeList"] = lst_Employee;
            ViewData["ClientList"] = lst_Client;
            ViewData["SOStatusList"] = lst_SOStatus;
            {

                List<ViewSales_Order_Detail> lst_Sales = new List<ViewSales_Order_Detail>();
                var GetSalesOrder = (from ob_sales in m_db.Sales_Order_Details
                                     join ob_status in m_db.tbl_Sales_Order_Status on ob_sales.tbl_Sales_Order_Status_ID equals ob_status.ID
                                     join ob_Customer in m_db.Customer_Details on ob_sales.Customer_ID equals ob_Customer.ID
                                    
                                     select new
                                     {
                                         ob_Customer = ob_Customer,
                                         ob_sales = ob_sales,
                                         ob_status = ob_status

                                     }).ToList();
                if (GetSalesOrder != null)
                {
                    if (ddl_Client != null && ddl_Client != 0)
                    {
                        GetSalesOrder = GetSalesOrder.Where(a => a.ob_sales.Customer_ID == ddl_Client).ToList();
                    }
                }
                if (GetSalesOrder != null)
                {
                    if (txtSalesOrderNo != null && txtSalesOrderNo != "")
                    {
                        GetSalesOrder = GetSalesOrder.Where(a => a.ob_sales.SalesOrderNo.Contains(txtSalesOrderNo)).ToList();
                    }
                }
                if (GetSalesOrder != null && ddl_AssignedUsers != null && ddl_AssignedUsers!=0)
                {  
                    GetSalesOrder = GetSalesOrder.Where(a => a.ob_sales.Assigned_User_ID==ddl_AssignedUsers).ToList();
                }
                if (GetSalesOrder != null && ddl_status != null && ddl_status != 0)
                {
                    GetSalesOrder = GetSalesOrder.Where(a => a.ob_sales.tbl_Sales_Order_Status_ID == ddl_status).ToList();
                }


                foreach (var item in GetSalesOrder)
                {
                    ViewSales_Order_Detail order = new ViewSales_Order_Detail();
                    order.ID = item.ob_sales.ID;
                    order.name = item.ob_Customer.name;
                    order.DateOfOrder = item.ob_sales.DateOfOrder.ToString("dd MMM yyyy");
                    order.ExpectedDateOfDelivery = item.ob_sales.ExpectedDateOfDelivery.ToString("dd MMM yyyy");
                    order.SalesOrderNo = item.ob_sales.SalesOrderNo;
                    order.Status = item.ob_status.Status;
                    order.Remarks = item.ob_sales.Remarks;
                    if (item.ob_sales.Actual_Delivery_Date.ToString() != "1/1/0001 12:00:00 AM" && item.ob_sales.Actual_Delivery_Date!=null)
                        order.Actual_Delivery_Date = Convert.ToDateTime(item.ob_sales.Actual_Delivery_Date).ToString("dd MMM yyyy"); ;
                    if (item.ob_sales.Assigned_User_ID != 0)
                    {
                        string nameid = Convert.ToString(item.ob_sales.Assigned_User_ID);
                        var details1 = m_db.Users.Where(m => m.Id == nameid).FirstOrDefault();
                        if (details1 != null)
                        {
                            if (details1.Name == null)
                            {
                                order.Assigned_User = " ";
                            }
                            else
                            {
                                order.Assigned_User = details1.Name;
                            }
                        }

                    }
                    else
                    {
                        order.Assigned_User = " ";
                    }

                    lst_Sales.Add(order);
                }
                return View(lst_Sales);
            }
        }
        public JsonResult SaveEmployeeAssignedSO(int SO_ID, int EmployeeID)
        {
            string Message = "";
            int Status = 0;
            try
            {
                if (SO_ID != 0)
                {

                    var details = m_db.Sales_Order_Details.Where(a => a.ID == SO_ID).FirstOrDefault();
                    if (details != null)
                    {
                        details.Assigned_User_ID = Convert.ToInt16(EmployeeID);
                        m_db.Entry(details).State = EntityState.Modified;
                        m_db.SaveChanges();
                        Status = 1;
                        Message = "Saved";
                    }
                }
                else
                    Message = "Select at least one User!";
            }
            catch (Exception ex)
            {
                writelog = new Writelog();
                writelog.write_exception_log(0, "AdministrationController", "Save User", DateTime.Now, ex);
                Message = "Error";
            }
            return Json(new { Status = Status, Message = Message }, JsonRequestBehavior.AllowGet);
        }
        public JsonResult UpdateSOStatus(int? SO_ID, int? StatusID)
        {
            string Message = "";
            int Status = 0;
            try
            {
                if (SO_ID != 0)
                {

                    var details = m_db.Sales_Order_Details.Where(a => a.ID == SO_ID).FirstOrDefault();
                    if (details != null)
                    {
                        details.tbl_Sales_Order_Status_ID = Convert.ToInt32(StatusID);
                        m_db.Entry(details).State = EntityState.Modified;
                        m_db.SaveChanges();
                        Status = 1;
                        Message = "Status updated successfully.";
                    }
                }
                else
                    Message = "Select Sales Order Status!";
            }
            catch (Exception ex)
            {
                writelog = new Writelog();
                writelog.write_exception_log(0, "AdministrationController", "Save User", DateTime.Now, ex);
                Message = "Error";
            }
            return Json(new { Status = Status, Message = Message }, JsonRequestBehavior.AllowGet);
        }
        public PartialViewResult ViewsalesOrderDetailsPopupPartial(int ID)
        {
            List<View_SalesOrder_Item> lst_sales = new List<View_SalesOrder_Item>();
            var GetsalesOrder = (from ob_sales in m_db.Sales_Order_Item_Details.Where(a => a.sales_Order_Detail_ID == ID)
                                 join ob_Stock in m_db.stock_details on ob_sales.Item_ID equals ob_Stock.ID
                                 select new
                                 {
                                     ob_Stock = ob_Stock,
                                     ob_sales = ob_sales
                                 }).ToList();
            foreach (var item in GetsalesOrder)
            {
                View_SalesOrder_Item order = new View_SalesOrder_Item();
                order.Item_ID = item.ob_sales.Item_ID;
                order.Item_Name = item.ob_Stock.Item_Name;
                order.Quantity = item.ob_sales.Quantity;
                order.Cost_Per_Item = item.ob_sales.Cost_Per_Item;
                order.Delivered_Quntity = item.ob_sales.Delivered_Quntity.ToString();
                order.Batch_No = item.ob_sales.Batch_No;
                order.Serial_No = item.ob_sales.Serial_No;
                order.Scan_Value = item.ob_sales.Scan_Value;
                lst_sales.Add(order);
            }
            return PartialView(lst_sales);
        }
        #endregion

        #region  Purchase Order
        public ActionResult CreatePurchaseOrder()
        {
            cf = new comman_function();
            List<SelectListItem> lst_vender = cf.GetVenderList();

            ViewData["VenderList"] = lst_vender;
            return View();
        }
        public JsonResult GetVenderItemCost(int VenderID, int ItemID)
        {
            float ItemCost = 0;

            var itemList = m_db.Vendor_Products.Where(a => a.ID == ItemID && a.Vendor_ID == VenderID).FirstOrDefault();
            if (itemList != null)
            {
                ItemCost = itemList.Cost;
            }

            return Json(ItemCost, JsonRequestBehavior.AllowGet);
        }
        public PartialViewResult PurchaseOrderPartial(int VenderID)
        {
            cf = new comman_function();
            ViewData["VendorListItem"] = cf.GetVenderItemList(VenderID);
            try
            {
                if (VenderID == 0)
                    Lst_purchaseItems.Clear();

            }
            catch (Exception ex)
            {
                writelog = new Writelog();
                writelog.write_exception_log(0, "AdministrationController", "PurchaseOrderPartial", DateTime.Now, ex);
            }
            return PartialView(Lst_purchaseItems);
        }
        public static int itemcount = 0;
        public JsonResult PostPurchaseItem(int VenderID, int ItemID, string ItemName, float Quantity, float Item_Cost)
        {
            itemcount++;
            float Status = 0;
            View_PurchaseOrder_Item item = new View_PurchaseOrder_Item();
            item.ID = itemcount;
            item.Item_ID = ItemID;
            item.Item_Name = ItemName;
            item.Vender_ID = VenderID;
            item.Quantity = Quantity;
            item.Cost_Per_Item = Item_Cost;
            Lst_purchaseItems.Add(item);
            Status = 1;
            return Json(Status, JsonRequestBehavior.AllowGet);
        }
        public JsonResult DeletePostPurchaseItem(int RowID)
        {
            float Status = 0;
            try
            {
                Lst_purchaseItems.RemoveAt(RowID - 1);
                Status = 1;
            }
            catch { }
            return Json(Status, JsonRequestBehavior.AllowGet);
        }
        public JsonResult SavePurchaseOrder(int VenderID, DateTime DateOfPurchase, DateTime Expected_Received_Date, string Purchase_Order_Number)
        {
            int UserID = 0;
            try
            {
                UserID = Convert.ToInt32(User.Identity.GetUserId());
                if (Lst_purchaseItems.Count > 0)
                {
                    PurchaseOrder_Details order = new PurchaseOrder_Details();
                    order.Vender_ID = VenderID;
                    order.Expected_Received_Date = Expected_Received_Date;
                    order.DateOfPurchase = DateOfPurchase;
                    order.Purchase_Order_Number = Purchase_Order_Number;
                    order.tbl_Purchase_Order_Status_ID = 1;
                    order.CreatedBy = UserID;
                    order.CreatedOn = DateTime.Now;
                    m_db.PurchaseOrder_Details.Add(order);
                    m_db.SaveChanges();

                    foreach (var item in Lst_purchaseItems)
                    {
                        purchase_order_item_details order_items = new purchase_order_item_details();
                        order_items.Created_By = UserID;
                        order_items.Created_On = DateTime.Now;
                        order_items.Purchase_Order_Details_ID = order.ID;
                        order_items.Item_ID = item.Item_ID;
                        order_items.Quantity = item.Quantity;
                        order_items.Cost_Per_Item = item.Cost_Per_Item;
                        m_db.purchase_order_item_details.Add(order_items);
                        m_db.SaveChanges();
                    }
                    return Json(new { Status = 1, Message = "Saved" }, JsonRequestBehavior.AllowGet);
                }
                else
                    return Json(new { Status = 0, Message = "Please select atleast one item!" }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                writelog = new Writelog();
                writelog.write_exception_log(0, "AdministrationController", "SavPurchaseOrder", DateTime.Now, ex);

            }
            return Json(new { Status = 0, Message = "Error" }, JsonRequestBehavior.AllowGet);
        }

        //View purchase Order Assign User Id
        public JsonResult SaveEmployeeAssignedPO(int PO_ID, string EmployeeID)
        {
            string Message = "";
            int Status = 0;
            try
            {
                if (PO_ID != 0)
                {

                    var details = m_db.PurchaseOrder_Details.Where(a => a.ID == PO_ID).FirstOrDefault();
                    //var details1 = m_db.PurchaseOrder_Details.Where(m => m.Id == EmployeeID).FirstOrDefault();
                    if (details != null)
                    {

                        details.Assigned_User_ID = Convert.ToInt16(EmployeeID);

                        m_db.Entry(details).State = EntityState.Modified;
                        m_db.SaveChanges();
                        Status = 1;
                        Message = "Saved";
                    }
                }
                else
                    Message = "Select at least one User!";
            }
            catch (Exception ex)
            {
                writelog = new Writelog();
                writelog.write_exception_log(0, "AdministrationController", "Save User", DateTime.Now, ex);
                Message = "Error";
            }
            return Json(new { Status = Status, Message = Message }, JsonRequestBehavior.AllowGet);
        }
        
        public JsonResult GetPOAssignedUser(int PO_ID)
        {
            int AssigneUserID = 0;
            try
            {
                var details = m_db.PurchaseOrder_Details.Where(a => a.ID == PO_ID).FirstOrDefault();
                if (details != null)
                {
                    if (details.Assigned_User_ID != null)
                        AssigneUserID = Convert.ToInt32(details.Assigned_User_ID);
                }
            }
            catch (Exception ex)
            {
                writelog = new Writelog();
                writelog.write_exception_log(0, "AdministrationController", "GetSOAssignedUser", DateTime.Now, ex);

            }
            return Json(AssigneUserID, JsonRequestBehavior.AllowGet);
        }
        public ActionResult ViewPurchaseOrder(int? ddl_Vender, string txtPurchaseOrderNo, int? ddl_AssignedUsers, int? ddl_status)
        {
            cf = new comman_function();
            List<SelectListItem> lst_AllVender = cf.GetAllVenderList();
            List<SelectListItem> lst_Employee = cf.GetHHTEmployeeList();
            List<SelectListItem> lst_AllEmployee = cf.GetAllHHTEmployeeList();
            List<SelectListItem> lst_POStatus = cf.GetAllPurchaseOrderStatus();
            ViewData["AllEmployeeList"] = lst_AllEmployee;
            ViewData["EmployeeList"] = lst_Employee;
            ViewData["VenderList"] = lst_AllVender;
            ViewData["POStatusList"] = lst_POStatus;
            {
                List<View_PurchaseOrder_Details> lst_purchase = new List<View_PurchaseOrder_Details>();
                var GetPurchaseOrder = (from ob_purchase in m_db.PurchaseOrder_Details
                                        join ob_vender in m_db.Vendor_Details on ob_purchase.Vender_ID equals ob_vender.ID
                                        join ob_status in m_db.tbl_Purchase_Order_Status on ob_purchase.tbl_Purchase_Order_Status_ID equals ob_status.ID
                                       
                                        select new
                                        {
                                            ob_vender = ob_vender,
                                            ob_purchase = ob_purchase,
                                            ob_status=ob_status

                                        }).ToList();
                if (GetPurchaseOrder != null)
                {
                    if (ddl_Vender != null && ddl_Vender != 0)
                    {
                        GetPurchaseOrder = GetPurchaseOrder.Where(a => a.ob_purchase.Vender_ID == ddl_Vender).ToList();
                    }
                }
                if (GetPurchaseOrder != null)
                {
                    if (txtPurchaseOrderNo != null && txtPurchaseOrderNo != "")
                    {
                        GetPurchaseOrder = GetPurchaseOrder.Where(a => a.ob_purchase.Purchase_Order_Number.Contains(txtPurchaseOrderNo)).ToList();
                    }
                }
                if (GetPurchaseOrder != null && ddl_AssignedUsers!= null && ddl_AssignedUsers != 0)
                {
                    GetPurchaseOrder = GetPurchaseOrder.Where(a => a.ob_purchase.Assigned_User_ID == ddl_AssignedUsers).ToList();
                }
                if (GetPurchaseOrder != null && ddl_status != null && ddl_status != 0)
                {
                    GetPurchaseOrder = GetPurchaseOrder.Where(a => a.ob_purchase.tbl_Purchase_Order_Status_ID == ddl_status).ToList();
                }
                foreach (var item in GetPurchaseOrder)
                {
                    View_PurchaseOrder_Details order = new View_PurchaseOrder_Details();
                    order.ID = item.ob_purchase.ID;
                    order.Status = item.ob_status.Status;
                    order.Vendor_Name = item.ob_vender.Vendor_Name;
                    order.DateOfPurchase = item.ob_purchase.DateOfPurchase.ToString("dd MMM yyyy");
                    order.Expected_Received_Date = item.ob_purchase.Expected_Received_Date.ToString("dd MMM yyyy");
                    order.Purchase_Order_Number = item.ob_purchase.Purchase_Order_Number;
                    if (item.ob_purchase.Actual_Received_Date.ToString() != "1/1/0001 12:00:00 AM" && item.ob_purchase.Actual_Received_Date!=null)
                    order.Actual_Received_Date = Convert.ToDateTime(item.ob_purchase.Actual_Received_Date).ToString("dd MMM yyyy");
                    order.Remarks = item.ob_purchase.Remarks;
                    
                    if (item.ob_purchase.Assigned_User_ID != 0)
                    {
                        string nameid = Convert.ToString(item.ob_purchase.Assigned_User_ID);
                        var details1 = m_db.Users.Where(m => m.Id == nameid).FirstOrDefault();
                        if (details1 != null)
                        {
                            if (details1.Name == null)
                            {
                                order.Assigned_User = " ";
                            }
                            else
                            {
                                order.Assigned_User = details1.Name;
                            }
                        }
                        
                    }
                    else
                    {
                        order.Assigned_User = " ";
                    }
                    lst_purchase.Add(order);
                }
                return View(lst_purchase);
            }
        }
        public PartialViewResult ViewPurchaseOrderDetailsPopupPartial(int ID)
        {
            List<View_PurchaseOrder_Item> lst_purchase = new List<View_PurchaseOrder_Item>();
            var GetPurchaseOrder = (from ob_purchase in m_db.purchase_order_item_details.Where(a => a.Purchase_Order_Details_ID == ID)
                                    join ob_Items in m_db.stock_details on ob_purchase.Item_ID equals ob_Items.ID
                                
                                    select new
                                    {
                                        ob_Items = ob_Items,
                                        ob_purchase = ob_purchase
                                    }).ToList();
            foreach (var item in GetPurchaseOrder)
            {
                View_PurchaseOrder_Item order = new View_PurchaseOrder_Item();
                order.Item_ID = item.ob_purchase.Item_ID;
                order.Item_Name = item.ob_Items.Item_Name;
                order.Quantity = item.ob_purchase.Quantity;
                order.Cost_Per_Item = item.ob_purchase.Cost_Per_Item;
                order.Batch_No = item.ob_purchase.Batch_No;
                order.Serial_No = item.ob_purchase.Serial_No;
                order.Scan_Value = item.ob_purchase.Scan_Value;
                order.Rcd_Quntity = item.ob_purchase.Rcd_Quntity.ToString();
                lst_purchase.Add(order);
            }
            return PartialView(lst_purchase);
        }
        public JsonResult UpdatePOStatus(int? PO_ID, int? StatusID)
        {
            string Message = "";
            int Status = 0;
            try
            {
                if (PO_ID != 0)
                {

                    var details = m_db.PurchaseOrder_Details.Where(a => a.ID == PO_ID).FirstOrDefault();
                    if (details != null)
                    {
                        details.tbl_Purchase_Order_Status_ID = Convert.ToInt32(StatusID);
                        m_db.Entry(details).State = EntityState.Modified;
                        m_db.SaveChanges();
                        Status = 1;
                        Message = "Status updated successfully.";
                    }
                }
                else
                    Message = "Select Purchase Order Status!";
            }
            catch (Exception ex)
            {
                writelog = new Writelog();
                writelog.write_exception_log(0, "AdministrationController", "UpdatePOStatus", DateTime.Now, ex);
                Message = "Error";
            }
            return Json(new { Status = Status, Message = Message }, JsonRequestBehavior.AllowGet);
        }
        #endregion

        public ActionResult AssignedtoUserPurchaseOrder()
        {
            cf = new comman_function();
            List<SelectListItem> lst_Employee = cf.GetHHTEmployeeList();

            ViewData["EmployeeList"] = lst_Employee;

            return View();
        }




    }
}

