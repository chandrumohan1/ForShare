﻿using System;               
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Threading.Tasks;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin.Security;
using WDC.Models;
using System.Transactions;
using System.Data.Common;
namespace WDC.Controllers
{
    public class TestController : Controller
    {
        // GET: Test//flxeemp88/aug
        ApplicationDbContext m_db = null;
        comman_function cf = null;
        public ActionResult CreateTest()
        {
            return View();
        }
        public JsonResult PostTest()
        {
           
            
            m_db = new ApplicationDbContext();
            m_db.Database.Connection.Open();
            using (DbTransaction trans = m_db.Database.Connection.BeginTransaction())
            {
                try
                {
                    m_barcode_setting addbarcode = new m_barcode_setting();
                    addbarcode.Prefix = "WDC";
                    addbarcode.Firest_Field = "Item_No";
                    addbarcode.Second_Field = "dc";
                    addbarcode.Third_Field = "dcd";
                    addbarcode.m_Status_ID = Convert.ToInt32("1");
                    addbarcode.Date_of_Creation = DateTime.Now;
                    m_db.m_barcode_setting.Add(addbarcode);
                    m_db.SaveChanges();

                    long id = addbarcode.ID;

                    m_barcode_setting barcode = new m_barcode_setting();
                    barcode.Prefix = "WDC";
                    barcode.Firest_Field = "Item_No";
                    barcode.Second_Field = "dc";
                    barcode.Third_Field = "dcd";
                    barcode.m_Status_ID = Convert.ToInt32("1d");
                    barcode.Date_of_Creation = DateTime.Now;
                    m_db.m_barcode_setting.Add(barcode);
                    m_db.SaveChanges();
                    trans.Commit();
                }
                catch (Exception)
                {
                    trans.Rollback();
                }
                finally
                {
                    if (m_db != null && m_db.Database.Connection.State != System.Data.ConnectionState.Closed
        && m_db.Database.Connection.State != System.Data.ConnectionState.Broken)
                        m_db.Database.Connection.Close();
                }
            }
            
            return Json("success");
        }
       
    }
}