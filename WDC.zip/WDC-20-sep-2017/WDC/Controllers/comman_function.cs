﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using System.Web;
using System.Web.Mvc;
using System.Data.OleDb;
using System.Data;
using System.IO;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.Net.Http;
//using iTextSharp.text.pdf;
//using iTextSharp.text;
//using iTextSharp.text.html.simpleparser;
using System.Web.Helpers;
using WDC.Models;
using iTextSharp.text.pdf;
using iTextSharp.text;

namespace WDC.Controllers
{
   
    public class comman_function : Controller
    {
        ApplicationDbContext db = new ApplicationDbContext();
        SelectListItem SelectItems = null;
        SelectListItem SelectAllItems = null;
        public comman_function()
        {
            SelectItems = new SelectListItem();
            SelectItems.Text = "--Select--";
            SelectItems.Value = "";
            SelectAllItems = new SelectListItem();
            SelectAllItems.Text = "  All  ";
            SelectAllItems.Value = "0";
        }
        public TransactionScope CreateTransactionScope()
        {
            var transactionOptions = new TransactionOptions
            {
                IsolationLevel = System.Transactions.IsolationLevel.ReadCommitted,
                Timeout = TimeSpan.FromMinutes(10) //assume 10 min is the timeout time
            };
            return new TransactionScope(TransactionScopeOption.Required, transactionOptions);
        }
        public List<SelectListItem> GetYesNoList()
        {
            List<SelectListItem> lst = new List<SelectListItem>();
            lst.Add(SelectItems);
            lst.Add(new SelectListItem { Text = "Yes", Value = "1" });
            lst.Add(new SelectListItem { Text = "No", Value = "0" });
            return lst;
        }
        public List<SelectListItem> GetStockStatus()
        {
            List<SelectListItem> lst = new List<SelectListItem>();
            lst.Add(SelectItems);
            var get = db.m_stock_status.Where(a => a.m_status_id == 1).ToList();
            foreach (var item in get)
            {
                lst.Add(new SelectListItem { Value = item.ID.ToString(), Text = item.Status });
            }
            return lst;
        }
        public List<SelectListItem> GetStockAllStatus()
        {
            List<SelectListItem> lst = new List<SelectListItem>();
            lst.Add(SelectAllItems);
            var get = db.m_stock_status.Where(a => a.m_status_id == 1).ToList();
            foreach (var item in get)
            {
                lst.Add(new SelectListItem { Value = item.ID.ToString(), Text = item.Status });
            }
            return lst;
        }
        public List<SelectListItem> GetExportList()
        {
            List<SelectListItem> lst_export = new List<SelectListItem>();
            lst_export.Add(new SelectListItem { Text = "-Select-", Value = "" });
            lst_export.Add(new SelectListItem { Text = "Excel", Value = "1" });
            lst_export.Add(new SelectListItem { Text = "PDF", Value = "2" });
            return lst_export;
        }
        public List<SelectListItem> GetCountry(int ParentID)
        {
            List<SelectListItem> lst = new List<SelectListItem>();
            lst.Add(SelectItems);
            var get = db.tbl_Country.Where(a => a.parentid == ParentID).ToList();
            foreach(var item in get)
            {
                lst.Add(new SelectListItem { Value = item.id.ToString(), Text = item.countryname });
            }
            return lst;
        }
        public List<SelectListItem> GetStockUnit()
        {
            List<SelectListItem> lst_unit = new List<SelectListItem>();
            lst_unit.Add(SelectItems);
            var getUnit = db.m_Stock_Unit.Where(a => a.m_Status_ID == 1).ToList();
            foreach (var items in getUnit)
            {
                lst_unit.Add(new SelectListItem { Value = items.ID.ToString(), Text = items.Unit });
            }
            return lst_unit;
        }
        public List<SelectListItem> GetStockType()
        {
            List<SelectListItem> lst_type = new List<SelectListItem>();
            lst_type.Add(SelectItems);
            var getStockType = db.m_Stock_Type.Where(a => a.m_Status_ID == 1).ToList();
            foreach (var items in getStockType)
            {
                lst_type.Add(new SelectListItem { Value = items.ID.ToString(), Text = items.Stock_Type });
            }
            return lst_type;
        }
        public List<SelectListItem> GetStockItemList()
        {
            List<SelectListItem> lst_item = new List<SelectListItem>();
            lst_item.Add(SelectItems);

            var getItem = db.stock_details.Where(a => a.m_stock_status_id!= 4).ToList();
            foreach (var items in getItem)
            {
                lst_item.Add(new SelectListItem { Value = items.ID.ToString(), Text = items.Item_Name});
            }
           
            return lst_item;
        }
        public List<SelectListItem> GetLocationList()
        {
            List<SelectListItem> lst = new List<SelectListItem>();
            lst.Add(SelectItems);

            var getItem = db.Location_Details.Where(a => a.Parent_ID == 0).ToList();
            foreach (var items in getItem)
            {
                lst.Add(new SelectListItem { Value = items.ID.ToString(), Text = items.Area });
            }
            return lst;
        }
        public List<SelectListItem> GetAllLocationList()
        {
            List<SelectListItem> lst = new List<SelectListItem>();
            lst.Add(SelectAllItems);

            var getItem = db.Location_Details.Where(a => a.Parent_ID == 0).ToList();
            foreach (var items in getItem)
            {
                lst.Add(new SelectListItem { Value = items.ID.ToString(), Text = items.Area });
            }
            return lst;
        }
        public List<SelectListItem> GetSubLocationList(int ParentID)
        {
            List<SelectListItem> lst = new List<SelectListItem>();
            lst.Add(SelectItems);
            if (ParentID != 0)
            {
                var getItem = db.Location_Details.Where(a => a.Parent_ID == ParentID).ToList();
                foreach (var items in getItem)
                {
                    lst.Add(new SelectListItem { Value = items.ID.ToString(), Text = items.Area });
                }
            }
            return lst;
        }
        public List<SelectListItem> GetSubLocationAllList(int ParentID)
        {
            List<SelectListItem> lst = new List<SelectListItem>();
            lst.Add(SelectAllItems);
            if (ParentID != 0)
            {
                var getItem = db.Location_Details.Where(a => a.Parent_ID == ParentID).ToList();
                foreach (var items in getItem)
                {
                    lst.Add(new SelectListItem { Value = items.ID.ToString(), Text = items.Area });
                }
            }
            return lst;
        }
        public List<SelectListItem> GetVenderList()
        {
            List<SelectListItem> lst = new List<SelectListItem>();
            lst.Add(SelectItems);
            
            var getItem = db.Vendor_Details.ToList();
            foreach (var items in getItem)
            {
                lst.Add(new SelectListItem { Value = items.ID.ToString(), Text = items.Vendor_Name });
            }
            return lst;
        }

        public List<SelectListItem> GetAllVenderList()
        {
            List<SelectListItem> lst = new List<SelectListItem>();
            lst.Add(SelectAllItems);
            var getItem = db.Vendor_Details.ToList();
            foreach (var items in getItem)
            {
                lst.Add(new SelectListItem { Value = items.ID.ToString(), Text = items.Vendor_Name });
            }
            return lst;
        }
        public List<SelectListItem> GetVenderItemList(int venderID)
        {
            List<SelectListItem> lst = new List<SelectListItem>();
            lst.Add(SelectItems);

            var getItem =(from ob_venderProduct in db.Vendor_Products.Where(a=>a.Vendor_ID== venderID)
                          join ob_stock in db.stock_details.Where(a=>a.m_stock_status_id!=4) on ob_venderProduct.Product_ID equals ob_stock.ID
                          select new {
                              ob_venderProduct= ob_venderProduct,
                              ob_stock= ob_stock
                          }).ToList();
            foreach (var items in getItem)
            {
                lst.Add(new SelectListItem { Value = items.ob_venderProduct.ID.ToString(), Text =items.ob_stock.Item_Name });
            }
            return lst;
        }
        public List<SelectListItem> GetClientList()
        {
            List<SelectListItem> lst = new List<SelectListItem>();
            lst.Add(SelectItems);

            var getItem = db.Customer_Details.ToList();
            foreach (var items in getItem)
            {
                lst.Add(new SelectListItem { Value = items.ID.ToString(), Text = items.name });
            }
            return lst;
        }
        public List<SelectListItem> GetAllClientList()
        {
            List<SelectListItem> lst = new List<SelectListItem>();
            lst.Add(SelectAllItems);

            var getItem = db.Customer_Details.ToList();
            foreach (var items in getItem)
            {
                lst.Add(new SelectListItem { Value = items.ID.ToString(), Text = items.name });
            }
            return lst;
        }
        public List<SelectListItem> GetSalesItemList(int ID) 
        {
            List<SelectListItem> lst = new List<SelectListItem>();
            lst.Add(SelectItems);

            var getItem =  db.stock_details.Where(a=>a.m_stock_status_id!=4).ToList();
            foreach (var items in getItem)
            {
                lst.Add(new SelectListItem { Value = items.ID.ToString(), Text = items.Item_Name });
            }
            return lst;
        }
        public List<SelectListItem> GetHHTEmployeeList()
        {
            List<SelectListItem> lst = new List<SelectListItem>();
            lst.Add(SelectItems);

            var getlist = db.Users.Where(a=>a.Is_Active==1 && a.Is_for_Mobile_Device==1).ToList();
            foreach (var items in getlist)
            {
                lst.Add(new SelectListItem { Value = items.Id.ToString(), Text = items.Name });
            }
            return lst;
        }
        public List<SelectListItem> GetAllHHTEmployeeList()
        {
            List<SelectListItem> lst = new List<SelectListItem>();
            lst.Add(SelectAllItems);

            var getlist = db.Users.Where(a => a.Is_Active == 1 && a.Is_for_Mobile_Device == 1).ToList();
            foreach (var items in getlist)
            {
                lst.Add(new SelectListItem { Value = items.Id.ToString(), Text = items.Name });
            }
            return lst;
        }
        public List<SelectListItem> GetAllPurchaseOrderStatus()
        {
             List<SelectListItem> lst = new List<SelectListItem>();
             lst.Add(SelectAllItems);
            var getlist = db.tbl_Purchase_Order_Status.ToList();
            foreach (var items in getlist)
            {
                lst.Add(new SelectListItem { Value = items.ID.ToString(), Text = items.Status });
            }
            return lst;
        }
        public List<SelectListItem> GetPOList()
        {
             List<SelectListItem> lst = new List<SelectListItem>();
             lst.Add(SelectItems);
            var getlist = db.PurchaseOrder_Details.OrderByDescending(a=>a.ID).ToList();
            foreach (var items in getlist)
            {
                lst.Add(new SelectListItem { Value = items.ID.ToString(), Text = items.Purchase_Order_Number });
            }
            return lst;
        }
        public List<SelectListItem> GetSOList()
        {
            List<SelectListItem> lst = new List<SelectListItem>();
            lst.Add(SelectItems);
            var getlist = db.Sales_Order_Details.OrderByDescending(a=>a.ID).ToList();
            foreach (var items in getlist)
            {
                lst.Add(new SelectListItem { Value = items.ID.ToString(), Text = items.SalesOrderNo });
            }
            return lst;
        }
        public List<SelectListItem> StockSheetList()
        {
            List<SelectListItem> lst = new List<SelectListItem>();
            lst.Add(SelectItems);
            var getlist = db.tbl_Stock_Count_Details.OrderByDescending(a => a.ID).ToList();
            foreach (var items in getlist)
            {
                lst.Add(new SelectListItem { Value = items.ID.ToString(), Text = items.Stock_Name });
            }
            return lst;
        }
        public List<SelectListItem> GetAllSalesOrderStatus()
        {
            List<SelectListItem> lst = new List<SelectListItem>();
            lst.Add(SelectAllItems);
            var getlist = db.tbl_Sales_Order_Status.ToList();
            foreach (var items in getlist)
            {
                lst.Add(new SelectListItem { Value = items.ID.ToString(), Text = items.Status });
            }
            return lst;
        }
        public Dictionary<string, string> GetField()
        {
            Dictionary<string, string> myDict = new Dictionary<string, string>()
            {
                { "m_Stock_type_ID", "Stock type" },
                { "Location_ID", "Location" },
                { "Sub_Location_ID", "Sub Location" },
                
            };
            return myDict;
        }
       
        public static DataTable ConvertCSVtoDataTable(string strFilePath)
        {
            DataTable dt = new DataTable();
            using (StreamReader sr = new StreamReader(strFilePath))
            {
                string[] headers = sr.ReadLine().Split(',');
                foreach (string header in headers)
                {
                    dt.Columns.Add(header);
                }

                while (!sr.EndOfStream)
                {
                    string[] rows = sr.ReadLine().Split(',');
                    if(rows.Length > 1)
                    {
                        DataRow dr = dt.NewRow();
                        for (int i = 0; i < headers.Length; i++)
                        {
                            dr[i] = rows[i].Trim();
                        }
                        dt.Rows.Add(dr);
                    }
                }

            }


            return dt;
        }
        public static FillDataTable ConvertXSLXtoDataTable(string strFilePath, string connString)
        {
            ApplicationDbContext db1 = new ApplicationDbContext();

            OleDbConnection oledbConn = new OleDbConnection(connString);
            // DataTable dt = new DataTable();
            FillDataTable FillDatatbl = new FillDataTable();
            Exception_History exep_ = new Exception_History();
            exep_.exception = "first call";
            exep_.page = "dump";
            exep_.exception_date = DateTime.Now;
            db1.Exception_History.Add(exep_);
            db1.SaveChanges();

            try
            {

                try
                {
                    Exception_History exe = new Exception_History();
                    exe.exception = "first before open call";
                    exe.page = "dump";
                    exe.exception_date = DateTime.Now;
                    db1.Exception_History.Add(exe);
                    db1.SaveChanges();
                  
                    oledbConn.Open();
                }
                catch (Exception e)
                {
                   
                    throw;
                }
                using (DataTable Sheets = oledbConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null))
                {

                    Exception_History exeep1 = new Exception_History();
                    exeep1.exception = "before for each";
                    exeep1.page = "exception block in at line no. 352";
                    exeep1.exception_date = DateTime.Now;
                    db1.Exception_History.Add(exeep1);
                    db1.SaveChanges();


                    for (int i = 0; i < Sheets.Rows.Count; i++)
                    {


                        DataSet ds = new DataSet();
                        string worksheets = Sheets.Rows[i]["TABLE_NAME"].ToString();
                        Exception_History exep1 = new Exception_History();
                        exep1.exception = worksheets;
                        exep1.page = "insert name in at line no. 300";
                        exep1.exception_date = DateTime.Now;
                        db1.Exception_History.Add(exep1);
                        db1.SaveChanges();

                        worksheets = worksheets.Replace("'", "");
                        if (worksheets == "_xlnm#_FilterDatabase")
                            continue;

                        if (worksheets == "Asset$_")
                            continue;

                        OleDbCommand cmd = new OleDbCommand(String.Format("SELECT * FROM [{0}]", worksheets), oledbConn);
                        OleDbDataAdapter oleda = new OleDbDataAdapter();
                        oleda.SelectCommand = cmd;
                        oleda.Fill(ds);
                        Exception_History exep2 = new Exception_History();
                        exep2.exception ="call fill" ;
                        exep2.page = "insert name in at line no.281";
                        exep2.exception_date = DateTime.Now;
                        db1.Exception_History.Add(exep2);
                        db1.SaveChanges();

                        switch (worksheets)
                        {
                            case "Asset$":
                                FillDatatbl.asset_tbl = ds.Tables[0];
                                break;
                            case "Custodian$":
                                FillDatatbl.cust_tbl = ds.Tables[0];
                                break;
                            case "Department$":
                                FillDatatbl.department_tbl = ds.Tables[0];
                                break;
                            case "L1 Category$":
                                FillDatatbl.l1_category_tbl = ds.Tables[0];
                                break;
                            case "L2 Category$":
                                FillDatatbl.l2_category_tbl = ds.Tables[0];
                                break;
                            case "L3 Category$":
                                FillDatatbl.l3_category_tbl = ds.Tables[0];
                                break;
                            case "Loc1$":
                                FillDatatbl.loc1_tbl = ds.Tables[0];
                                break;
                            case "Loc2$":
                                FillDatatbl.loc2_tbl = ds.Tables[0];
                                break;
                            case "Loc3$":
                                FillDatatbl.loc3_tbl = ds.Tables[0];
                                break;
                            case "Model$":
                                FillDatatbl.model_tbl = ds.Tables[0];
                                break;
                            default:
                                break;
                        }


                    }


                    Exception_History exeep = new Exception_History();
                    exeep.exception = "after for each";
                    exeep.page = "exception block in at line no. 352";
                    exeep.exception_date = DateTime.Now;
                    db1.Exception_History.Add(exeep);
                    db1.SaveChanges();




                }

            }
            catch (Exception ex)
            {
                
                Exception_History exep = new Exception_History();
                exep.exception = ex.ToString();
                exep.page = "exception block in at line no. 322";
                exep.exception_date = DateTime.Now;
                db1.Exception_History.Add(exep);
                db1.SaveChanges();
                
            }
            finally
            {
                if(FillDatatbl.asset_tbl==null)
                {
                    Exception_History exep3 = new Exception_History();
                    exep3.exception = "call finally @ Null";
                    exep3.page = "insert name in at line no.281";
                    exep3.exception_date = DateTime.Now;
                    db1.Exception_History.Add(exep3);
                    db1.SaveChanges();
                }
                else
                {
                    Exception_History exep3 = new Exception_History();
                    exep3.exception = "call finally @ Not null Count @" + FillDatatbl.l1_category_tbl.Rows.Count;
                    exep3.page = "insert name in at line no.281";
                    exep3.exception_date = DateTime.Now;
                    db1.Exception_History.Add(exep3);
                    db1.SaveChanges();
                }
               

                oledbConn.Close();
            }



            return FillDatatbl;

        }
        public class FillDataTable
        {
            public DataTable asset_tbl { get; set; }
            public DataTable l1_category_tbl { get; set; }
            public DataTable l2_category_tbl { get; set; }
            public DataTable l3_category_tbl { get; set; }
            public DataTable loc1_tbl { get; set; }
            public DataTable loc2_tbl { get; set; }
            public DataTable loc3_tbl { get; set; }
            public DataTable department_tbl { get; set; }
            public DataTable cust_tbl { get; set; }
            public DataTable model_tbl { get; set; }
        }
        public DataTable CreateTableMasterStock(List<Viewstock_details> lst_purchase)
        {
            DataTable export_dt = new DataTable();
            export_dt.Columns.Add("Sr. No.", typeof(string));
            export_dt.Columns.Add("Item No", typeof(string));
            export_dt.Columns.Add("Item Name", typeof(string));
            export_dt.Columns.Add("Item Description", typeof(string));
            export_dt.Columns.Add("Item Type", typeof(string));
            export_dt.Columns.Add("Location", typeof(string));
            export_dt.Columns.Add("Unit", typeof(string));
            export_dt.Columns.Add("Reorder Level", typeof(string));
            export_dt.Columns.Add("Current Level", typeof(string));
            export_dt.Columns.Add("Status", typeof(string));
            int s = 1;
            foreach (var Data in lst_purchase)
            {
                DataRow row = export_dt.NewRow();
                if (Data == null)
                    continue;
                row[0] = s + ".";
                row[1] = Data.Item_No;
                row[2] = Data.Item_Name;
                row[3] = Data.Description;
                row[4] = Data.Stock_type;
                row[5] = Data.Location;
                row[6] = Data.Stock_Unit;
                row[7] = Data.Reorder_Level;
                row[8] = Data.Current_Stock;
                row[9] = Data.Status;
                export_dt.Rows.Add(row);
                s++;
            }

            return export_dt;
        }
        public DataTable CreateTablePO(List<View_PurchaseOrder_Details> lst_purchase)
        {
            DataTable export_dt = new DataTable();
                export_dt.Columns.Add("Sr. No.", typeof(string));
                export_dt.Columns.Add("Vendor Name", typeof(string));
                export_dt.Columns.Add("Purchase Order No.", typeof(string));
                export_dt.Columns.Add("Purchase Order Date", typeof(string));
                export_dt.Columns.Add("Expected Received Date", typeof(string));
                export_dt.Columns.Add("Actual Received Date", typeof(string));
                export_dt.Columns.Add("Total Item", typeof(string));
                export_dt.Columns.Add("Assigned User", typeof(string));
                export_dt.Columns.Add("Remarks", typeof(string));
                export_dt.Columns.Add("PO Status", typeof(string));
                int s = 1;
                foreach (var Data in lst_purchase)
                {
                    DataRow row = export_dt.NewRow();
                    if (Data == null)
                        continue;
                    row[0] = s + ".";
                    row[1] = Data.Vendor_Name;
                    row[2] = Data.Purchase_Order_Number;
                    row[3] = Data.DateOfPurchase;
                    row[4] = Data.Expected_Received_Date;
                    row[5] = Data.Actual_Received_Date;
                    row[6] = Data.Total_Items;
                    row[7] = Data.Assigned_User;
                    row[8] = Data.Remarks;
                    row[9] = Data.Status;
                    export_dt.Rows.Add(row);
                    s++;
                }
           
            return export_dt;
        }
        public DataTable CreateTableSO(List<ViewSales_Order_Detail> lst)
        {
            DataTable export_dt = new DataTable();
            export_dt.Columns.Add("Sr. No.", typeof(string));
            export_dt.Columns.Add("Client Name", typeof(string));
            export_dt.Columns.Add("Sales Order No.", typeof(string));
            export_dt.Columns.Add("Date Of Order", typeof(string));
            export_dt.Columns.Add("Expected Date Of Delivery", typeof(string));
            export_dt.Columns.Add("Actual Date of Delivery", typeof(string));
            export_dt.Columns.Add("Total Item", typeof(string));
            export_dt.Columns.Add("Assigned User", typeof(string));
            export_dt.Columns.Add("Remarks", typeof(string));
            export_dt.Columns.Add("SO Status", typeof(string));
            int s = 1;
            foreach (var Data in lst)
            {
                DataRow row = export_dt.NewRow();
                if (Data == null)
                    continue;
                row[0] = s + ".";
                row[1] = Data.name;
                row[2] = Data.SalesOrderNo;
                row[3] = Data.DateOfOrder;
                row[4] = Data.ExpectedDateOfDelivery;
                row[5] = Data.Actual_Delivery_Date;
                row[6] = Data.Total_Items;
                row[7] = Data.Assigned_User;
                row[8] = Data.Remarks;
                row[9] = Data.Status;
                export_dt.Rows.Add(row);
                s++;
            }

            return export_dt;
        }
        public DataTable CreateTableStockSheet(List<View_Stock_Count_Details> lst)
        {
            DataTable export_dt = new DataTable();
            export_dt.Columns.Add("Sr. No.", typeof(string));
            export_dt.Columns.Add("Sheet Name", typeof(string));
            export_dt.Columns.Add("Assigned User", typeof(string));
            export_dt.Columns.Add("Created On", typeof(string));
            export_dt.Columns.Add("Total Item", typeof(string));
            int s = 1;
            foreach (var Data in lst)
            {
                DataRow row = export_dt.NewRow();
                if (Data == null)
                    continue;
                row[0] = s + ".";
                row[1] = Data.Stock_Name;
                row[2] = Data.User_Assigned;
                row[3] = Data.Date_of_Creation;
                row[4] = Data.Total_Item;
                export_dt.Rows.Add(row);
                s++;
            }

            return export_dt;
        }
        public DataTable CreateTableStockMismatch(List<view_missing_inventory> lst)
        {
            DataTable export_dt = new DataTable();
            export_dt.Columns.Add("Sr. No.", typeof(string));
            export_dt.Columns.Add("Sheet Name", typeof(string));
            export_dt.Columns.Add("Assigned User", typeof(string));
            export_dt.Columns.Add("Item Name", typeof(string));
            export_dt.Columns.Add("System Quantity", typeof(string));
            export_dt.Columns.Add("Reported Quantity", typeof(string));
            export_dt.Columns.Add("Remarks", typeof(string));
            export_dt.Columns.Add("Action Taken", typeof(string));
            export_dt.Columns.Add("Reported On", typeof(string));
            int s = 1;
            foreach (var Data in lst)
            {
                DataRow row = export_dt.NewRow();
                if (Data == null)
                    continue;
                row[0] = s + ".";
                row[1] = Data.Stock_Name;
                row[2] = Data.User_Assigned;
                row[3] = Data.Item_Name;
                row[4] = Data.System_Quantity;
                row[5] = Data.Reported_Quantity;
                row[6] = Data.Remarks;
                row[7] = Data.Action_Taken;
                row[8] = Data.Reported_on;

                export_dt.Rows.Add(row);
                s++;
            }

            return export_dt;
        }
        public DataTable CreateTableDiscrepency(List<view_missing_inventory> lst)
        {
            DataTable export_dt = new DataTable();
            export_dt.Columns.Add("Sr. No.", typeof(string));
            export_dt.Columns.Add("Customer Name", typeof(string));
            export_dt.Columns.Add("PO No.", typeof(string));
            export_dt.Columns.Add("Assigned User", typeof(string));
            export_dt.Columns.Add("Item Name", typeof(string));
            //export_dt.Columns.Add("System Quantity", typeof(string));
            //export_dt.Columns.Add("Reported Quantity", typeof(string));
            export_dt.Columns.Add("Remarks", typeof(string));
            export_dt.Columns.Add("Action Taken", typeof(string));
            export_dt.Columns.Add("Reported On", typeof(string));
            int s = 1;
            foreach (var Data in lst)
            {
                DataRow row = export_dt.NewRow();
                if (Data == null)
                    continue;
                row[0] = s + ".";
                row[1] = Data.Customer_Name;
                row[2] = Data.Stock_Name;
                row[3] = Data.User_Assigned;
                row[4] = Data.Item_Name;
                //row[4] = Data.System_Quantity;
                //row[5] = Data.Reported_Quantity;
                row[5] = Data.Remarks;
                row[6] = Data.Action_Taken;
                row[7] = Data.Reported_on;

                export_dt.Rows.Add(row);
                s++;
            }

            return export_dt;
        }
        public DataTable CreateTablePurchaseItems(List<View_PurchaseOrder_Item> lst)
        {
            DataTable export_dt = new DataTable();
            export_dt.Columns.Add("Sr. No.", typeof(string));
            export_dt.Columns.Add("Item Name", typeof(string));
            export_dt.Columns.Add("Ordered Quantity", typeof(string));
            export_dt.Columns.Add("Received Quntity", typeof(string));
            export_dt.Columns.Add("Batch No", typeof(string));
            export_dt.Columns.Add("Serial No", typeof(string));
            export_dt.Columns.Add("Barcode", typeof(string));
            int s = 1;
            foreach (var Data in lst)
            {
                DataRow row = export_dt.NewRow();
                if (Data == null)
                    continue;
                row[0] = s + ".";
                row[1] = Data.Item_Name;
                row[2] = Data.Quantity;
                row[3] = Data.Rcd_Quntity;
                row[4] = Data.Batch_No;
                row[5] = Data.Serial_No;
                row[6] = Data.Scan_Value;	
                export_dt.Rows.Add(row);
                s++;
            }

            return export_dt;
        }
        public DataTable CreateTableSalesItems(List<View_SalesOrder_Item> lst)
        {
            DataTable export_dt = new DataTable();
            export_dt.Columns.Add("Sr. No.", typeof(string));
            export_dt.Columns.Add("Item Name", typeof(string));
            export_dt.Columns.Add("Ordered Quantity", typeof(string));
            export_dt.Columns.Add("Delivered Quntity", typeof(string));
            export_dt.Columns.Add("Batch No", typeof(string));
            export_dt.Columns.Add("Serial No", typeof(string));
            export_dt.Columns.Add("Barcode", typeof(string));
            int s = 1;
            foreach (var Data in lst)
            {
                DataRow row = export_dt.NewRow();
                if (Data == null)
                    continue;
                row[0] = s + ".";
                row[1] = Data.Item_Name;
                row[2] = Data.Quantity;
                row[3] = Data.Delivered_Quntity;
                row[4] = Data.Batch_No;
                row[5] = Data.Serial_No;
                row[6] = Data.Scan_Value;
                export_dt.Rows.Add(row);
                s++;
            }

            return export_dt;
        }
        public DataTable CreateTableStockSheetItems(List<Stock_Sheet_Items> lst)
        {
            DataTable export_dt = new DataTable();
            export_dt.Columns.Add("Sr. No.", typeof(string));
            export_dt.Columns.Add("Item Name", typeof(string));
            export_dt.Columns.Add("Batch No", typeof(string));
            export_dt.Columns.Add("Serial No", typeof(string));
            export_dt.Columns.Add("Barcode", typeof(string));
            int s = 1;
            foreach (var Data in lst)
            {
                DataRow row = export_dt.NewRow();
                if (Data == null)
                    continue;
                row[0] = s + ".";
                row[1] = Data.Item_Name;
                row[2] = Data.Batch_No != null ? Data.Batch_No : "";
                row[3] = Data.Serial_No != null ? Data.Serial_No : "";
                row[4] = Data.Scan_Value != null ? Data.Scan_Value : "";
                export_dt.Rows.Add(row);
                s++;
            }

            return export_dt;
        }
        public int Export(string header, DataTable dt_header, DataTable dt, HttpResponseBase Response,int type,bool SendMail,string EmailID)
        {
            int message = 0;
            string HeaderRow_ForColor = "Black";
            string HeaderRow_BackColor = "White";
            string RowStyle_BackColor = "White";
            string BorderColor = "Black";
            var get = db.m_Report_Color.Where(m => m.m_Status_ID == 1).FirstOrDefault();
            if (get != null)
            {
                if (get.HeaderRow_ForColor != "#ffffff")
                    HeaderRow_ForColor = get.HeaderRow_ForColor;
                if (get.HeaderRow_BackColor != "#ffffff")
                {
                    HeaderRow_BackColor = get.HeaderRow_BackColor;
                    BorderColor = get.HeaderRow_BackColor;
                }
                if (get.RowStyle_BackColor != "#ffffff")
                    RowStyle_BackColor = get.RowStyle_BackColor;
            }

            int head_col = dt.Columns.Count;
            var grid = new GridView();
            grid.DataSource = dt;
            grid.DataBind();
            grid.ShowHeader = false;
            grid.CssClass = "textmode";
            grid.HeaderRow.CssClass = "HeaderRow_ForColor";
            //grid.HeaderRow.BackColor = Color.DarkCyan;
            grid.AlternatingRowStyle.CssClass = "AlternatingRowStyle";

            var grid2 = new GridView();
            grid2.DataSource = dt_header;
            grid2.DataBind();
            grid2.CssClass = "filtermode";

            if (type == 1)
            {
                #region Excel
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                
                string style = @"<style> .textmode{border : 1px Solid " + BorderColor + ";  } .textmode td,th {height:25px;}.filtermode{border : 1px Solid #fff;} .filtermode td,th{border:0px;font-weight: bold;} .logo{Color:" + HeaderRow_ForColor + ";text-align:center;background:" + HeaderRow_BackColor + ";font-size:16pt;font-weight: bold;} .HeaderRow_ForColor{color:" + HeaderRow_ForColor + ";background:" + HeaderRow_BackColor + "} .AlternatingRowStyle{background:" + RowStyle_BackColor + "}</style>";

                sw.Write(style);
                sw.Write("<table><tr><td></td><td  class='logo'>" + header + "</td></tr><tr><td></td><td style='border : 1px Solid " + BorderColor + ";'>");
                grid2.RenderControl(htw);
                sw.Write("</td></tr><tr><td></td><td style='border : 1px Solid " + BorderColor + ";'>");
                grid.RenderControl(htw);
                sw.Write("</td></tr></table>");
                if (SendMail)
                {
                    System.IO.MemoryStream s = new MemoryStream();
                    System.Text.Encoding Enc = System.Text.Encoding.Default;
                    byte[] mBArray = Enc.GetBytes(sw.ToString());
                    string[] send_to = new string[] { EmailID };
                    string[] bcc_to = new string[] { "" };
                    string subject = "WDC - " + header;
                    SendMail maill = new SendMail();
                    bool i= maill.send_mail("Hello, <br/>Please find the report attached.<br/><br/>Thanks", send_to, bcc_to, subject, mBArray, header + ".xls");
                    if(i)message=3;
                }
                else
                {
                    Response.Clear();
                    Response.Buffer = true;
                    Response.AddHeader("content-disposition", "attachment;filename=" + header + ".xls");
                    Response.Charset = "";
                    Response.ContentType = "application/vnd.ms-excel";
                    Response.Write(sw.ToString());
                    Response.End();
                    message = 1;
                }
                #endregion
            }
            else if (type == 2)
            {
                #region PDF
                Response.Clear();
                var doc = new Document();
                if (!SendMail)
                    PdfWriter.GetInstance(doc, Response.OutputStream);

                System.IO.MemoryStream s = new MemoryStream();
                PdfWriter writer = PdfWriter.GetInstance(doc, s);
                doc.SetPageSize(PageSize.A4.Rotate());
                doc.Open();

                var BHeaderRow_ForColor = System.Drawing.ColorTranslator.FromHtml(HeaderRow_ForColor);
                var BHeaderRow_BackColor = System.Drawing.ColorTranslator.FromHtml(HeaderRow_BackColor);
                var BRowStyle_BackColor = System.Drawing.ColorTranslator.FromHtml(RowStyle_BackColor);
                var BBorderColor = System.Drawing.ColorTranslator.FromHtml(BorderColor);

                var arial = FontFactory.GetFont("Arial", 8, BaseColor.BLACK);
                var arialBold = FontFactory.GetFont("Arial", 9, iTextSharp.text.Font.BOLD, new BaseColor(BHeaderRow_ForColor));
                var FilterBold = FontFactory.GetFont("Arial", 10, iTextSharp.text.Font.BOLD, BaseColor.BLACK);
                BaseFont bfTimes = BaseFont.CreateFont(BaseFont.TIMES_ROMAN, BaseFont.CP1252, false);
                Font times = new Font(bfTimes, 15, Font.ITALIC, new BaseColor(BHeaderRow_ForColor));
                PdfPTable tbl_header = new PdfPTable(2);
                tbl_header.SetWidths(new int[] { 0, 50 });
                tbl_header.TotalWidth = 700f;
                tbl_header.LockedWidth = true;
                PdfPCell cell = new PdfPCell(new Paragraph(header, times));
                cell.Colspan = 4;
                cell.PaddingTop = 10;
                cell.PaddingBottom = 10;
                cell.BorderColor = new BaseColor(BBorderColor);
                cell.BackgroundColor = new BaseColor(BHeaderRow_BackColor);
                cell.HorizontalAlignment = Element.ALIGN_CENTER;
                tbl_header.AddCell(cell);
                doc.Add(tbl_header);
                int headerColumn = dt_header.Columns.Count;
                if (headerColumn > 6) headerColumn = 6;
                var tblheader = new PdfPTable(headerColumn)
                {
                    TotalWidth = 700f,
                    LockedWidth = true,
                };

                for (int k = 0; k < dt_header.Rows.Count; k++)
                {
                    for (int j = 0; j < headerColumn; j++)
                    {
                        PdfPCell NoBoaderCell = new PdfPCell(new Phrase(dt_header.Rows[k][j].ToString(), FilterBold));

                        NoBoaderCell.BorderColor = new BaseColor(BBorderColor);
                        if (j == 0)
                        {
                            NoBoaderCell.BorderWidthLeft = 1;
                            NoBoaderCell.BorderWidthTop = 0;
                            NoBoaderCell.BorderWidthBottom = 0;
                            NoBoaderCell.BorderWidthRight = 0;
                        }
                        else if (j == headerColumn - 1)
                        {
                            NoBoaderCell.BorderWidthLeft = 0;
                            NoBoaderCell.BorderWidthTop = 0;
                            NoBoaderCell.BorderWidthBottom = 0;
                            NoBoaderCell.BorderWidthRight = 1;
                        }
                        else
                            NoBoaderCell.BorderWidth = 0;
                        tblheader.AddCell(NoBoaderCell);
                    }
                }
                doc.Add(tblheader);
                var table = new PdfPTable(dt.Columns.Count)
                {
                    TotalWidth = 700f,
                    LockedWidth = true,
                };

                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    PdfPCell hcell = new PdfPCell(new Paragraph(dt.Columns[i].ColumnName, arialBold));
                    hcell.BackgroundColor = new BaseColor(BHeaderRow_BackColor);
                    hcell.HorizontalAlignment = Element.ALIGN_CENTER;
                    hcell.BorderColor = new BaseColor(BBorderColor);
                    table.AddCell(hcell);
                }
                for (int k = 0; k < dt.Rows.Count; k++)
                {
                    for (int j = 0; j < dt.Columns.Count; j++)
                    {
                        PdfPCell dcell = new PdfPCell(new Phrase(dt.Rows[k][j].ToString(), arial));
                        dcell.HorizontalAlignment = Element.ALIGN_CENTER;
                        dcell.BorderColor = new BaseColor(BBorderColor);
                        table.AddCell(dcell);
                    }
                }
                doc.Add(table);
                if (SendMail)
                {
                    doc.Close();
                    byte[] mBArray = s.ToArray();
                    s.Close();
                    string[] send_to = new string[] { EmailID };
                    string[] bcc_to = new string[] { "" };
                    string subject = "WDC - " + header;
                    SendMail maill = new SendMail();
                    bool i = maill.send_mail("Hello, <br/>Please find the report attached.<br/><br/>Thanks", send_to, bcc_to, subject, mBArray, header + ".pdf");
                    if (i) message = 3;
                }
                else
                {
                    doc.Close();
                    Response.Buffer = true;
                    Response.AddHeader("Content-disposition", "attachment; filename=" + header + ".pdf");
                    Response.ContentType = "application/octet-stream";
                    Response.Write(doc);
                    Response.End();
                    message = 1;
                }
                
               
                #endregion
            }

            return message;
        }


        public FillDataTableIN ConvertXSLXtoDataTableIN(string connString)
        {
           

            OleDbConnection oledbConn = new OleDbConnection(connString);
            FillDataTableIN FillDatatbl = new FillDataTableIN();

            try
            {

                oledbConn.Open();
                using (DataTable Sheets = oledbConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null))
                {

                    for (int i = 0; i < Sheets.Rows.Count; i++)
                    {
                        DataSet ds = new DataSet();
                        string worksheets = Sheets.Rows[i]["TABLE_NAME"].ToString();
                        worksheets = worksheets.Replace("'", "");
                        if (worksheets == "_xlnm#_FilterDatabase")
                            continue;

                        if (worksheets == "Asset$_")
                            continue;

                        OleDbCommand cmd = new OleDbCommand(String.Format("SELECT * FROM [{0}]", worksheets), oledbConn);
                        OleDbDataAdapter oleda = new OleDbDataAdapter();
                        oleda.SelectCommand = cmd;
                        oleda.Fill(ds);

                        switch (worksheets)
                        {
                            case "Inventory - Stock Control$":
                                FillDatatbl.inventry_tbl = ds.Tables[0];
                                break;
                            case "Inventory - Stock Vendor List$":
                                FillDatatbl.vendor_tbl = ds.Tables[0];
                                break;
                            default:
                                break;
                        }


                    }

                }

            }
            catch (Exception ex)
            {



            }
            finally
            {
                if (FillDatatbl.inventry_tbl == null)
                {

                }
                else
                {

                }


                oledbConn.Close();
            }

            return FillDatatbl;
        }
    }
    public class FillDataTableIN
    {
        public DataTable inventry_tbl { get; set; }
        public DataTable vendor_tbl { get; set; }
    }
}