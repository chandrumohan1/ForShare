﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using AttributeRouting.Web.Http;
using AttributeRouting;
using WDC.Models;
using System.Data.Entity;  

namespace WDC.Controllers
{
    [RoutePrefix("WDCAPI")] 
    public class WDCAPIController : ApiController
    {
        ApplicationDbContext db = new ApplicationDbContext();
        comman_function cf = null;
        Writelog writelog = null;

        [HttpGet]
        [HttpRoute("GetUsers")]  
        public HttpResponseMessage GetUsers()
        {
            HttpResponseMessage response = new HttpResponseMessage();
            try
            {
                var GetUser = db.Users.Where(a => a.Is_Active == 1 && a.Is_for_Mobile_Device == 1).ToList();
                response = Request.CreateResponse(HttpStatusCode.OK, GetUser);
            }
            catch (Exception ex)
            {
                writelog = new Writelog();
                writelog.write_exception_log(0, "WDCAPIController", "GetUsers", DateTime.Now, ex);
                response = Request.CreateResponse(HttpStatusCode.ServiceUnavailable, "Error");  
            }
            return response;
        }
        [HttpPost]
        [HttpRoute("PostChangeUsersPassword")]
        public HttpResponseMessage PostChangeUsersPassword(UserProfile user)
        {
            HttpResponseMessage response = new HttpResponseMessage();
            response = Request.CreateResponse(HttpStatusCode.ServiceUnavailable, "Error");
            try
            {
                string UserID=user.Id.ToString();
                var GetUser = db.Users.Where(a => a.Id == UserID).FirstOrDefault();
                if (GetUser != null)
                {
                    //var ctrl = new AccountController();
                    //ctrl.ControllerContext = ControllerContext;
                    //ctrl.LoginByCookies();
                    GetUser.Password = user.Password;
                    db.Entry(GetUser).State = EntityState.Modified;
                    db.SaveChanges();
                    
                    
                    //var Sresult = UserManager.RemovePasswordAsync(UserID);
                    //if (Sresult.Result.Succeeded)
                    //{
                    //    Sresult = UserManager.AddPasswordAsync(UserID, user.Password);
                    //}
                   
                    response = Request.CreateResponse(HttpStatusCode.OK, GetUser);
                }
                
            }
            catch (Exception ex)
            {
                writelog = new Writelog();
                writelog.write_exception_log(0, "WDCAPIController", "GetUsers", DateTime.Now, ex);
                
            }
            return response;
        }
        [HttpGet]
        [HttpRoute("GetPurchaseOrder/{AssignedEmployeeID}")]
        public HttpResponseMessage GetPurchaseOrder(int AssignedEmployeeID)
        {
            HttpResponseMessage response = new HttpResponseMessage();
            try
            {
               List<View_PurchaseOrder_Details> lst_purchase_order=new List<View_PurchaseOrder_Details>();
               if (AssignedEmployeeID != 0)
               {
                  
                   var PurchaseOrders = (from ob_purchase in db.PurchaseOrder_Details.Where(a => a.Assigned_User_ID == AssignedEmployeeID)
                                           join ob_vender in db.Vendor_Details on ob_purchase.Vender_ID equals ob_vender.ID
                                           //join ob_status in db.tbl_Purchase_Order_Status on ob_purchase.tbl_Purchase_Order_Status_ID equals ob_status.ID

                                           select new
                                           {
                                               ob_vender = ob_vender,
                                               ob_purchase = ob_purchase,
                                               //ob_status = ob_status

                                           }).ToList();
                   foreach (var item in PurchaseOrders)
                   {
                       View_PurchaseOrder_Details obPurchase_order = new View_PurchaseOrder_Details();
                       obPurchase_order.ID = item.ob_purchase.ID;
                       obPurchase_order.Status = item.ob_purchase.tbl_Purchase_Order_Status_ID.ToString();
                       obPurchase_order.Purchase_Order_Number = item.ob_purchase.Purchase_Order_Number;
                       obPurchase_order.Vendor_ID = item.ob_purchase.Vender_ID;
                       obPurchase_order.Vendor_Name = item.ob_vender.Vendor_Name;
                       obPurchase_order.Assigned_User = item.ob_purchase.Assigned_User_ID.ToString();
                       obPurchase_order.DateOfPurchase = null;//1/1/0001 12:00:00 AM
                       if (item.ob_purchase.DateOfPurchase.ToString() != "1/1/0001 12:00:00 AM")
                           obPurchase_order.DateOfPurchase = item.ob_purchase.DateOfPurchase.ToString("MM/dd/yyy");

                       obPurchase_order.Expected_Received_Date = null;
                       if (item.ob_purchase.Expected_Received_Date.ToString() != "1/1/0001 12:00:00 AM")
                           obPurchase_order.Expected_Received_Date = item.ob_purchase.Expected_Received_Date.ToString("MM/dd/yyy");
                       obPurchase_order.Actual_Received_Date = null;
                       if (item.ob_purchase.Actual_Received_Date.ToString() != null && item.ob_purchase.Actual_Received_Date.ToString() != "1/1/0001 12:00:00 AM")
                           obPurchase_order.Actual_Received_Date = Convert.ToDateTime(item.ob_purchase.Actual_Received_Date).ToString("MM/dd/yyy");

                       obPurchase_order.View_PurchaseOrder_Item = new List<View_PurchaseOrder_Item>();
                      // var GetPurchaseItems = db.purchase_order_item_details.Where(a => a.Purchase_Order_Details_ID == item.ID).ToList();

                       var GetPurchaseItems = (from ob_purchase in db.purchase_order_item_details.Where(a => a.Purchase_Order_Details_ID == obPurchase_order.ID)
                                               join ob_Items in db.stock_details on ob_purchase.Item_ID equals ob_Items.ID

                                               select new
                                               {
                                                   ob_Items = ob_Items,
                                                   ob_purchase_items = ob_purchase
                                               }).ToList();
                       foreach (var itms in GetPurchaseItems)
                       {
                           View_PurchaseOrder_Item obOrder_items = new View_PurchaseOrder_Item();
                           obOrder_items.ID = itms.ob_purchase_items.ID;
                           obOrder_items.PO_ID = obPurchase_order.ID;
                           obOrder_items.Cost_Per_Item = itms.ob_purchase_items.Cost_Per_Item;
                           obOrder_items.Item_ID = itms.ob_purchase_items.Item_ID;
                           obOrder_items.Quantity = itms.ob_purchase_items.Quantity;
                           obOrder_items.Cost_Per_Item = itms.ob_purchase_items.Cost_Per_Item;
                           obOrder_items.Item_Name = itms.ob_Items.Item_Name;
                           obPurchase_order.View_PurchaseOrder_Item.Add(obOrder_items);
                       }
                       lst_purchase_order.Add(obPurchase_order);
                   }

               }
                response = Request.CreateResponse(HttpStatusCode.OK, lst_purchase_order);
            }
            catch (Exception ex)
            {
                writelog = new Writelog();
                writelog.write_exception_log(0, "WDCAPIController", "GetUsers", DateTime.Now, ex);
                response = Request.CreateResponse(HttpStatusCode.ServiceUnavailable, "Error");
            }
            return response;
        }
        [HttpPost]
        [HttpRoute("PostPurchaseOrder")]
        public HttpResponseMessage PostPurchaseOrder(List<View_PurchaseOrder_Details> lstPostPurchaseOrder)
        {
            List<RetPOMessage> lstPOMessage = new List<RetPOMessage>();
            HttpResponseMessage response = new HttpResponseMessage();
            try
            {
                if (lstPostPurchaseOrder != null)
                {
                    foreach (var OrderList in lstPostPurchaseOrder)
                    {
                        RetPOMessage message = new RetPOMessage();
                        message.PO_ID = OrderList.ID;
                        message.Status = false;
                        
                        var ObPurchaseOrder = db.PurchaseOrder_Details.Where(a => a.ID == OrderList.ID).FirstOrDefault();
                        if (ObPurchaseOrder != null)
                        {
                            message.PO_Number = ObPurchaseOrder.Purchase_Order_Number;
                            message.Status = true;
                            if (OrderList.View_PurchaseOrder_Item != null)
                            {
                                foreach (var OrderItemList in OrderList.View_PurchaseOrder_Item)
                                {
                                    var ObPurchaseOrderItem = db.purchase_order_item_details.Where(a => a.ID == OrderItemList.ID).FirstOrDefault();
                                    if (ObPurchaseOrderItem != null)
                                    {
                                        var StockItem = db.stock_details.Where(a => a.ID == ObPurchaseOrderItem.Item_ID).FirstOrDefault();
                                        if (StockItem != null)
                                        {
                                            int Stockadded = 0;
                                            switch (StockItem.m_Stock_type_ID)
                                            {
                                                case 1://with quantity
                                                    {
                                                        var GetInventry = db.tbl_inventory.Where(a => a.Item_ID == ObPurchaseOrderItem.Item_ID && a.tbl_Purchase_Order_ID == OrderList.ID).ToList();
                                                        int inventoryQuantity = 0;
                                                        if (GetInventry != null)
                                                          inventoryQuantity=GetInventry.Sum(d => d.Quantity);
                                                        if (ObPurchaseOrderItem.Quantity != inventoryQuantity)
                                                        {

                                                            tbl_inventory inventry = new tbl_inventory();
                                                            inventry.Item_ID = ObPurchaseOrderItem.Item_ID;
                                                            inventry.Quantity = Convert.ToInt32(OrderItemList.Rcd_Quntity);
                                                            inventry.Batch_No = "";
                                                            inventry.Serial_No = "";
                                                            inventry.tbl_Purchase_Order_ID = OrderList.ID;
                                                            inventry.Last_Update = DateTime.Now;
                                                            db.tbl_inventory.Add(inventry);
                                                            db.SaveChanges();
                                                            Stockadded = inventry.Quantity;
                                                        }
                                                        else
                                                        {
                                                            message.Status = false;
                                                            message.Message = message.Message + "Item '" + StockItem.Item_Name+ "' quantity  '" + OrderItemList.Rcd_Quntity + "' is already added by this PO.";

                                                        }
                                                        break;
                                                    }
                                                case 2: //with batch No.
                                                    {
                                                        var Batch = OrderItemList.Batch_No.Split('#');
                                                        var Rcd_Quntity = OrderItemList.Rcd_Quntity.Split('#');
                                                        for (int i = 0; i < Rcd_Quntity.Length; i++)
                                                        {
                                                            tbl_inventory inventry = new tbl_inventory();
                                                            inventry.Item_ID = ObPurchaseOrderItem.Item_ID;
                                                            inventry.tbl_Purchase_Order_ID = OrderList.ID;
                                                            inventry.Quantity = 1;
                                                            inventry.Batch_No = "";
                                                            if (Batch.Length >= (i + 1))
                                                                inventry.Batch_No = Batch[i];
                                                            if (Rcd_Quntity.Length >= (i + 1))
                                                                inventry.Quantity = Convert.ToInt32(Rcd_Quntity[i]);

                                                            inventry.Serial_No = "";
                                                            inventry.Last_Update = DateTime.Now;
                                                            var GetInventry = db.tbl_inventory.Where(a => a.Item_ID == ObPurchaseOrderItem.Item_ID && a.tbl_Purchase_Order_ID == OrderList.ID).ToList();
                                                            int inventoryQuantity = 0;
                                                            if (GetInventry != null)
                                                               inventoryQuantity=GetInventry.Sum(d => d.Quantity);
                                                            if (ObPurchaseOrderItem.Quantity != inventoryQuantity)
                                                            {
                                                                var checkInventryBatch = db.tbl_inventory.Where(a => a.Item_ID == ObPurchaseOrderItem.Item_ID && a.tbl_Purchase_Order_ID == OrderList.ID && a.Batch_No == inventry.Batch_No).FirstOrDefault();
                                                                if (checkInventryBatch == null)
                                                                    db.tbl_inventory.Add(inventry);
                                                                else
                                                                {
                                                                    checkInventryBatch.Quantity = checkInventryBatch.Quantity + inventry.Quantity;
                                                                    checkInventryBatch.Last_Update = DateTime.Now;
                                                                }
                                                                db.SaveChanges();
                                                                Stockadded++;
                                                            }
                                                            else
                                                            {
                                                                message.Status = false;
                                                                message.Message = message.Message + "Item quantity  1 with batch no. '" + inventry.Batch_No + "' is already exist.";
                                                            }
                                                        }
                                                        break;
                                                    }
                                                case 3://with batch no. and serial no.
                                                    {
                                                        var Batch = OrderItemList.Batch_No.Split('#');
                                                        var Serial = OrderItemList.Serial_No.Split('#');
                                                        var Rcd_Quntity = OrderItemList.Rcd_Quntity.Split('#');
                                                        for (int i = 0; i < Serial.Length; i++)
                                                        {
                                                            tbl_inventory inventry = new tbl_inventory();
                                                            inventry.Item_ID = ObPurchaseOrderItem.Item_ID;
                                                            inventry.tbl_Purchase_Order_ID = OrderList.ID;
                                                            inventry.Quantity = 1;
                                                            inventry.Batch_No = "";
                                                            if (Batch.Length >= (i + 1))
                                                                inventry.Batch_No = Batch[i];

                                                            inventry.Serial_No = "";
                                                            if (Serial.Length >= (i + 1))
                                                                inventry.Serial_No = Serial[i];

                                                            inventry.Last_Update = DateTime.Now;
                                                            var GetInventry = db.tbl_inventory.Where(a => a.Item_ID == ObPurchaseOrderItem.Item_ID && a.tbl_Purchase_Order_ID == OrderList.ID && a.Serial_No == inventry.Serial_No && a.Batch_No == inventry.Batch_No).FirstOrDefault();
                                                            if (GetInventry == null)
                                                            {
                                                                db.tbl_inventory.Add(inventry);
                                                                db.SaveChanges();
                                                                Stockadded++;
                                                            }
                                                            else
                                                            {
                                                                message.Status = false;
                                                                message.Message = message.Message + "Item with serial no '" + inventry.Serial_No + "' and and batch no. '" + inventry.Batch_No + "' is already exist.";
                                                            }
                                                        }
                                                        break;
                                                    }
                                                case 4://only serial no.
                                                    {
                                                        var Serial = OrderItemList.Serial_No.Split('#');
                                                        var Rcd_Quntity = OrderItemList.Rcd_Quntity.Split('#');
                                                        for (int i = 0; i < Serial.Length; i++)
                                                        {

                                                            tbl_inventory inventry = new tbl_inventory();
                                                            inventry.Item_ID = ObPurchaseOrderItem.Item_ID;
                                                            inventry.tbl_Purchase_Order_ID = OrderList.ID;
                                                            inventry.Quantity = 1;
                                                            inventry.Batch_No = "";
                                                            inventry.Serial_No = "";
                                                            if (Serial.Length >= (i + 1))
                                                                inventry.Serial_No = Serial[i];

                                                            inventry.Last_Update = DateTime.Now;
                                                            var GetInventry = db.tbl_inventory.Where(a => a.Item_ID == ObPurchaseOrderItem.Item_ID && a.tbl_Purchase_Order_ID == OrderList.ID && a.Serial_No == inventry.Serial_No).FirstOrDefault();
                                                            if (GetInventry == null)
                                                            {
                                                                db.tbl_inventory.Add(inventry);
                                                                db.SaveChanges();
                                                                Stockadded++;
                                                            }
                                                            else
                                                            {
                                                                message.Status = false;
                                                                message.Message = message.Message + "Item with serial no '" + inventry.Serial_No + "' is already exist.";
                                                            }
                                                        }
                                                        break;
                                                    }
                                            }
                                            StockItem.Current_Stock = StockItem.Current_Stock + Stockadded;
                                            //ObPurchaseOrderItem.Batch_No = OrderItemList.Batch_No;
                                            // ObPurchaseOrderItem.Serial_No = OrderItemList.Serial_No;
                                            // ObPurchaseOrderItem.Scan_Value = OrderItemList.Scan_Value;
                                            ObPurchaseOrderItem.Rcd_Quntity = ObPurchaseOrderItem.Rcd_Quntity+Stockadded;
                                            db.SaveChanges();

                                        }

                                    }
                                }//end foreach
                                if (OrderList.Actual_Received_Date != "" && OrderList.Actual_Received_Date != null)
                                    ObPurchaseOrder.Actual_Received_Date = Convert.ToDateTime(OrderList.Actual_Received_Date);
                                ObPurchaseOrder.Remarks = OrderList.Remarks;
                                ObPurchaseOrder.tbl_Purchase_Order_Status_ID = OrderList.Phone_Status;
                                db.SaveChanges();
                            }
                        }
                        else
                            message.Message = "PO is not exist.";
                        lstPOMessage.Add(message);
                    }
                }
                response = Request.CreateResponse(HttpStatusCode.OK, lstPOMessage);
            }
            catch (Exception ex)
            {
                writelog = new Writelog();
                writelog.write_exception_log(0, "WDCAPIController", "PostPurchaseOrder", DateTime.Now, ex);
                response = Request.CreateResponse(HttpStatusCode.ServiceUnavailable, "Error");
            }
            return response;
        }
        [HttpGet]
        [HttpRoute("GetSalesOrder/{AssignedEmployeeID}")]
        public HttpResponseMessage GetSalesOrder(int AssignedEmployeeID)
        {
            HttpResponseMessage response = new HttpResponseMessage();
            try
            {
                List<ViewSales_Order_Detail> lst_sales_order = new List<ViewSales_Order_Detail>();
                if (AssignedEmployeeID != 0)
                {
                    //var PurchaseOrders = .ToList();
                    var GetSalesOrder = (from ob_sales in db.Sales_Order_Details.Where(a => a.Assigned_User_ID == AssignedEmployeeID)
                                        // join ob_status in db.tbl_Sales_Order_Status on ob_sales.tbl_Sales_Order_Status_ID equals ob_status.ID
                                         join ob_Customer in db.Customer_Details on ob_sales.Customer_ID equals ob_Customer.ID

                                         select new
                                         {
                                             ob_Customer = ob_Customer,
                                             ob_sales = ob_sales,
                                             //ob_status = ob_status

                                         }).ToList();
                    foreach (var item in GetSalesOrder)
                    {
                        ViewSales_Order_Detail obSales_order = new ViewSales_Order_Detail();
                        obSales_order.ID = item.ob_sales.ID;
                        obSales_order.Status = item.ob_sales.tbl_Sales_Order_Status_ID.ToString();
                        obSales_order.SalesOrderNo = item.ob_sales.SalesOrderNo;
                        obSales_order.name = item.ob_Customer.name;
                        obSales_order.Customer_ID = item.ob_sales.Customer_ID;
                        obSales_order.Assigned_User = item.ob_sales.Assigned_User_ID.ToString();

                       obSales_order.DateOfOrder = null;//1/1/0001 12:00:00 AM
                       if (item.ob_sales.DateOfOrder.ToString() != "1/1/0001 12:00:00 AM")
                           obSales_order.DateOfOrder = item.ob_sales.DateOfOrder.ToString("MM/dd/yyy");

                       obSales_order.ExpectedDateOfDelivery = null;
                       if (item.ob_sales.ExpectedDateOfDelivery.ToString() != "1/1/0001 12:00:00 AM")
                           obSales_order.ExpectedDateOfDelivery = item.ob_sales.ExpectedDateOfDelivery.ToString("MM/dd/yyy");
                       obSales_order.Actual_Delivery_Date = null;
                       if (item.ob_sales.Actual_Delivery_Date.ToString() != null && item.ob_sales.Actual_Delivery_Date.ToString() != "1/1/0001 12:00:00 AM")
                           obSales_order.Actual_Delivery_Date = Convert.ToDateTime(item.ob_sales.Actual_Delivery_Date).ToString("/MM/ddyyy");




                        obSales_order.View_SalesOrder_Item = new List<View_SalesOrder_Item>();
                       

                        var GetSalesItems = (from ob_sales_items in db.Sales_Order_Item_Details.Where(a => a.sales_Order_Detail_ID == obSales_order.ID)
                                             join ob_Items in db.stock_details on ob_sales_items.Item_ID equals ob_Items.ID
                                             select new
                                                {
                                                    ob_Items = ob_Items,
                                                    ob_sales_items = ob_sales_items
                                                }).ToList();

                        foreach (var itms in GetSalesItems)
                        {
                            View_SalesOrder_Item obOrder_items = new View_SalesOrder_Item();
                            obOrder_items.ID = itms.ob_sales_items.ID;
                            obOrder_items.Cost_Per_Item = itms.ob_sales_items.Cost_Per_Item;
                            obOrder_items.Item_ID = itms.ob_sales_items.Item_ID;
                            obOrder_items.Quantity = itms.ob_sales_items.Quantity;
                            obOrder_items.Cost_Per_Item = itms.ob_sales_items.Cost_Per_Item;
                            obOrder_items.Item_Name = itms.ob_Items.Item_Name;
                            obOrder_items.SO_ID = obSales_order.ID;
                            obSales_order.View_SalesOrder_Item.Add(obOrder_items);
                        }
                        lst_sales_order.Add(obSales_order);
                    }

                }
                response = Request.CreateResponse(HttpStatusCode.OK, lst_sales_order);
            }
            catch (Exception ex)
            {
                writelog = new Writelog();
                writelog.write_exception_log(0, "WDCAPIController", "GetSalesOrder", DateTime.Now, ex);
                response = Request.CreateResponse(HttpStatusCode.ServiceUnavailable, "Error");
            }
            return response;
        }
        [HttpPost]
        [HttpRoute("PostSalesOrder")]
        public HttpResponseMessage PostSalesOrder(List<ViewSales_Order_Detail> lstPostSalesOrder)
        {
            List<RetSOMessage> lstSOMessage = new List<RetSOMessage>();
            HttpResponseMessage response = new HttpResponseMessage();
            try
            {
                if (lstPostSalesOrder != null)
                {
                    foreach (var OrderList in lstPostSalesOrder)
                    {
                        RetSOMessage message = new RetSOMessage();
                        message.SO_ID = OrderList.ID;
                        message.Status = false;
                        var ObSalesOrder = db.Sales_Order_Details.Where(a => a.ID == OrderList.ID).FirstOrDefault();
                        if (ObSalesOrder != null)
                        {
                            message.SO_Number = ObSalesOrder.SalesOrderNo;
                            message.Status = true;

                            if (OrderList.View_SalesOrder_Item != null)
                            {
                                foreach (var OrderItemList in OrderList.View_SalesOrder_Item)
                                {
                                    var ObSalesOrderItem = db.Sales_Order_Item_Details.Where(a => a.ID == OrderItemList.ID).FirstOrDefault();
                                    if (ObSalesOrderItem != null)
                                    {
                                        var StockItem = db.stock_details.Where(a => a.ID == ObSalesOrderItem.Item_ID).FirstOrDefault();
                                        var Delivered_Quntity = OrderItemList.Delivered_Quntity.Split('#');

                                        if (StockItem != null && StockItem.Current_Stock >= Delivered_Quntity.Length)
                                        {
                                            int StockDeduction = 0;
                                            switch (StockItem.m_Stock_type_ID)
                                            {
                                                case 1://with quantity
                                                    {
                                                        #region Case 1
                                                        var GetInventry = db.tbl_inventory.Where(a => a.Item_ID == ObSalesOrderItem.Item_ID && a.Quantity != 0).ToList();
                                                        float inventoryQuantity = 0;
                                                        if (GetInventry != null)
                                                            inventoryQuantity = GetInventry.Sum(d => d.Quantity);
                                                        if (inventoryQuantity > Convert.ToInt32(Delivered_Quntity))
                                                        {
                                                            int TotalRemainingQuanttity = Convert.ToInt32(Delivered_Quntity);
                                                            foreach (var InventryItem in GetInventry)
                                                            {
                                                                if (TotalRemainingQuanttity == 0)
                                                                    break;
                                                                else
                                                                {
                                                                    if (InventryItem.Quantity >= TotalRemainingQuanttity)
                                                                    {
                                                                        StockDeduction = StockDeduction - TotalRemainingQuanttity;
                                                                        InventryItem.Quantity = InventryItem.Quantity - TotalRemainingQuanttity;
                                                                        TotalRemainingQuanttity = 0;
                                                                        InventryItem.Last_Update = DateTime.Now;
                                                                        db.SaveChanges();
                                                                    }
                                                                    else
                                                                    {
                                                                        TotalRemainingQuanttity = TotalRemainingQuanttity - InventryItem.Quantity;
                                                                        StockDeduction = StockDeduction + InventryItem.Quantity;
                                                                        InventryItem.Quantity = 0;
                                                                        InventryItem.Last_Update = DateTime.Now;
                                                                        db.SaveChanges();
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        else
                                                        {
                                                            message.Message =message.Message+" Item '"+ StockItem.Item_Name+"' quantity more then system stock quantity.";
                                                            message.Status = false;
                                                        }
                                                        #endregion
                                                        break;
                                                    }
                                                case 2: //with batch No.
                                                    {
                                                        #region Case2
                                                        var Batch = OrderItemList.Batch_No.Split('#');
                                                        var Quntity = OrderItemList.Delivered_Quntity.Split('#');
                                                        for (int i = 0; i < Batch.Length; i++)
                                                        {
                                                            string Batch_No = "";
                                                            if (Batch.Length >= (i + 1))
                                                                Batch_No = Batch[i];
                                                            int ItemQuntity = 1;
                                                            if (Quntity.Length >= (i + 1))
                                                                ItemQuntity = Convert.ToInt32(Quntity[i]);

                                                            var GetInventry = db.tbl_inventory.Where(a => a.Item_ID == OrderItemList.Item_ID && a.Batch_No == Batch_No && a.Quantity != 0).ToList();
                                                            int inventoryQuantity = 0;
                                                            if (GetInventry != null)
                                                                inventoryQuantity = GetInventry.Sum(d => d.Quantity);
                                                            if (inventoryQuantity > ItemQuntity)
                                                            {
                                                                int TotalRemainingQuanttity = ItemQuntity;
                                                                foreach (var InventryItem in GetInventry)
                                                                {
                                                                    if (TotalRemainingQuanttity == 0)
                                                                        break;
                                                                    else
                                                                    {
                                                                        if (InventryItem.Quantity >= TotalRemainingQuanttity)
                                                                        {
                                                                            StockDeduction = StockDeduction - TotalRemainingQuanttity;
                                                                            InventryItem.Quantity = InventryItem.Quantity - TotalRemainingQuanttity;
                                                                            TotalRemainingQuanttity = 0;
                                                                            InventryItem.Last_Update = DateTime.Now;
                                                                            db.SaveChanges();
                                                                        }
                                                                        else
                                                                        {
                                                                            TotalRemainingQuanttity = TotalRemainingQuanttity - InventryItem.Quantity;
                                                                            StockDeduction = StockDeduction - InventryItem.Quantity;
                                                                            InventryItem.Quantity = 0;
                                                                            InventryItem.Last_Update = DateTime.Now;
                                                                            db.SaveChanges();
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                            else
                                                            {
                                                                message.Message = message.Message + " Item '" + StockItem.Item_Name + "' with batch no. '" + Batch_No + "' quantity more then system stock quantity.";
                                                                message.Status = false;
                                                            }
                                                        }
                                                        #endregion
                                                        break;
                                                    }
                                                case 3://with batch no. and serial no.
                                                    {
                                                        var Batch = OrderItemList.Batch_No.Split('#');
                                                        var Serial = OrderItemList.Serial_No.Split('#');
                                                        for (int i = 0; i < Serial.Length; i++)
                                                        {
                                                            string Batch_No = "";
                                                            if (Batch.Length >= (i + 1))
                                                                Batch_No = Batch[i];

                                                            string Serial_No = "";
                                                            if (Serial.Length >= (i + 1))
                                                                Serial_No = Serial[i];

                                                            var GetInventry = db.tbl_inventory.Where(a => a.Item_ID == OrderItemList.Item_ID && a.Serial_No == Serial_No && a.Batch_No == Batch_No && a.Quantity != 0).FirstOrDefault();
                                                            if (GetInventry != null)
                                                            {
                                                                GetInventry.Quantity = 0;
                                                                GetInventry.Last_Update = DateTime.Now;
                                                                db.SaveChanges();
                                                                StockDeduction++;
                                                            }
                                                            else
                                                            {
                                                                message.Message = message.Message + " Item '" + StockItem.Item_Name + "' with batch no. '" + Batch_No + "' and serial no. '" + Serial_No + "' is not exist in system stock quantity.";
                                                                message.Status = false;
                                                            }
                                                        }
                                                        break;
                                                    }
                                                case 4://only serial no.
                                                    {
                                                        var Serial = OrderItemList.Serial_No.Split('#');
                                                        for (int i = 0; i < Serial.Length; i++)
                                                        {
                                                            string Serial_No = "";
                                                            if (Serial.Length >= (i + 1))
                                                                Serial_No = Serial[i];

                                                            var GetInventry = db.tbl_inventory.Where(a => a.Item_ID == OrderItemList.Item_ID && a.Serial_No == Serial_No && a.Quantity != 0).FirstOrDefault();
                                                            if (GetInventry != null)
                                                            {
                                                                GetInventry.Quantity = 0;
                                                                db.SaveChanges();
                                                                StockDeduction++;
                                                            }
                                                            else
                                                            {
                                                                message.Message = message.Message + " Item '" + StockItem.Item_Name + "' with serial no. '" + Serial_No + "' is not exist in system stock quantity.";
                                                                message.Status = false;
                                                            }
                                                        }
                                                        break;
                                                    }
                                            }
                                            StockItem.Current_Stock = StockItem.Current_Stock - StockDeduction;
                                            //ObSalesOrderItem.Batch_No = OrderItemList.Batch_No;
                                            //ObSalesOrderItem.Serial_No = OrderItemList.Serial_No;
                                            //ObSalesOrderItem.Scan_Value = OrderItemList.Scan_Value;
                                            ObSalesOrderItem.Delivered_Quntity = StockDeduction;
                                            db.SaveChanges();


                                        }
                                    }

                                }
                            }
                            if (OrderList.Actual_Delivery_Date != "" && OrderList.Actual_Delivery_Date != null)
                                ObSalesOrder.Actual_Delivery_Date = Convert.ToDateTime(OrderList.Actual_Delivery_Date);
                            ObSalesOrder.Remarks = OrderList.Remarks;
                            ObSalesOrder.tbl_Sales_Order_Status_ID = OrderList.Phone_Status;
                            db.SaveChanges();
                        }
                        else
                            message.Message = "Sales order is not exist.";
                        lstSOMessage.Add(message);
                    }
                }
                response = Request.CreateResponse(HttpStatusCode.OK, lstSOMessage);
            }
            catch (Exception ex)
            {
                writelog = new Writelog();
                writelog.write_exception_log(0, "WDCAPIController", "PostSalesOrder", DateTime.Now, ex);
                response = Request.CreateResponse(HttpStatusCode.ServiceUnavailable, "Error");
            }
            return response;
        }
        [HttpGet]
        [HttpRoute("GetStockDetails")]
        public HttpResponseMessage GetStockDetails()
        {
            HttpResponseMessage response = new HttpResponseMessage();
            try
            {
                GetStockWithLocation lst = new GetStockWithLocation();
                lst.stock = db.stock_details.Where(a => a.m_stock_status_id != 4).ToList();//4=>Discontinued 	
                lst.location = db.Location_Details.ToList();
                response = Request.CreateResponse(HttpStatusCode.OK, lst);
            }
            catch (Exception ex)
            {
                writelog = new Writelog();
                writelog.write_exception_log(0, "WDCAPIController", "GetStockDetails", DateTime.Now, ex);
                response = Request.CreateResponse(HttpStatusCode.ServiceUnavailable, "Error");
            }
            return response;
        }
        [HttpGet]
        [HttpRoute("GetStockCountSheet/{AssignedEmployeeID}")]
        public HttpResponseMessage GetStockCountSheet(int AssignedEmployeeID)
        {
            HttpResponseMessage response = new HttpResponseMessage();
            try
            {
                List<StockCountDetails> lst_stock_count = new List<StockCountDetails>();
                if (AssignedEmployeeID != 0)
                {
                    //var PurchaseOrders = .ToList();
                    var StockCountSheet = db.tbl_Stock_Count_Details.Where(a => a.User_Assigned_ID == AssignedEmployeeID).ToList();
                    foreach (var item in StockCountSheet)
                    {
                        StockCountDetails obStockCcount = new StockCountDetails();
                        obStockCcount.ID = item.ID;
                        obStockCcount.Name = item.Stock_Name;
                        obStockCcount.Status = item.m_Status_ID;

                        obStockCcount.Items = new List<Items>();

                        var GetItems = db.tbl_Stock_Count_Item_Details.Where(a => a.tbl_Stock_Count_Details_ID == obStockCcount.ID).ToList();

                        foreach (var itms in GetItems)
                        {
                            Items obSheet_items = new Items();
                            //obSheet_items.ID = itms.ob_sales_items.ID;
                            obSheet_items.Item_ID = itms.ID;
                            obSheet_items.Stock_ID = itms.Stock_Item_ID;
                            obStockCcount.Items.Add(obSheet_items);
                        }
                        lst_stock_count.Add(obStockCcount);
                    }

                }
                response = Request.CreateResponse(HttpStatusCode.OK, lst_stock_count);
            }
            catch (Exception ex)
            {
                writelog = new Writelog();
                writelog.write_exception_log(0, "WDCAPIController", "GetStockCountSheet", DateTime.Now, ex);
                response = Request.CreateResponse(HttpStatusCode.ServiceUnavailable, "Error");
            }
            return response;
        }
        [HttpPost]
        [HttpRoute("PostStockCountSheet")]
        public HttpResponseMessage PostStockCountSheet( List<StockCountDetails> lst_stock_count)
        {
            List<RetStokCountMessage> lstStokCountMessage = new List<RetStokCountMessage>();
            HttpResponseMessage response = new HttpResponseMessage();
            try
            {
                if (lst_stock_count != null)
                {
                    foreach (var StockList in lst_stock_count)
                    {
                        RetStokCountMessage message = new RetStokCountMessage();
                        message.Stok_Count_ID = StockList.ID;
                        message.Status = false;
                        var obStockCountSheet = db.tbl_Stock_Count_Details.Where(a => a.ID == StockList.ID).FirstOrDefault();
                        if (obStockCountSheet != null)
                        {
                            message.Sheet_Name = obStockCountSheet.Stock_Name;
                            if (StockList.Items != null)
                            {
                                foreach (var PostListItms in StockList.Items)
                                {
                                    var obListItems = db.tbl_Stock_Count_Item_Details.Where(a => a.ID == PostListItms.ID).FirstOrDefault();
                                    if (obListItems != null)
                                    {
                                        message.Status = true;
                                        var StockItem = db.stock_details.Where(a => a.ID == obListItems.Stock_Item_ID).FirstOrDefault();
                                        if (StockItem != null)
                                        {
                                            switch (StockItem.m_Stock_type_ID)
                                            {
                                                case 1://with quantity
                                                    {
                                                        #region Case 1
                                                        var GetInventry = db.tbl_inventory.Where(a => a.Item_ID == obListItems.Stock_Item_ID && a.Quantity > 0).ToList();
                                                        int inventoryQuantity = 0;
                                                        if (GetInventry != null)
                                                            inventoryQuantity = GetInventry.Sum(d => d.Quantity);
                                                        int PostItemQuntity = 0;
                                                        if (PostListItms.Quntity!=null)
                                                            PostItemQuntity=Convert.ToInt32(PostListItms.Quntity);
                                                        if (PostItemQuntity == inventoryQuantity)
                                                        {
                                                            GetInventry.ForEach(a => a.Verified = 1);
                                                            GetInventry.ForEach(a => a.Last_Update = DateTime.Now);
                                                            db.SaveChanges();
                                                        }
                                                        else if (PostItemQuntity > inventoryQuantity)//stock sheet quantity greater then inventry quantity
                                                        {

                                                            int TotalAddingQuanttity = PostItemQuntity - inventoryQuantity;
                                                            //Add these items in inventory table
                                                            tbl_inventory tblInventry = new tbl_inventory();
                                                            tblInventry.Item_ID = obListItems.Stock_Item_ID;
                                                            tblInventry.SO_StockCount_ID = obStockCountSheet.ID;
                                                            tblInventry.Case_Status_ID = 2;
                                                            tblInventry.tbl_Purchase_Order_ID = 0;
                                                            tblInventry.Quantity = TotalAddingQuanttity;
                                                            tblInventry.Last_Update = DateTime.Now;
                                                            tblInventry.Verified = 1;
                                                            tblInventry.Batch_No = "";
                                                            tblInventry.Serial_No = "";
                                                            tblInventry.Case_Status_ID = 2;
                                                            db.tbl_inventory.Add(tblInventry);
                                                            db.SaveChanges();
                                                            //Add these items in missing inventory table
                                                            tbl_missing_inventory missing = new tbl_missing_inventory();
                                                            missing.tbl_inventory_ID = tblInventry.ID;
                                                            missing.Actual_Quantity = inventoryQuantity;
                                                            missing.Reported_Quantity = Convert.ToInt32(PostListItms.Quntity);
                                                            missing.Reported_on = DateTime.Now;
                                                            missing.Remarks = TotalAddingQuanttity + " item more then system inventory";
                                                            missing.Action_Taken = TotalAddingQuanttity + " item is added in system inventory";
                                                            missing.SO_StockCount_Item_DetailsID = obListItems.ID;
                                                            missing.Case_Status_ID = 2;
                                                            missing.SO_StockCount_ID = obStockCountSheet.ID;
                                                            db.tbl_missing_inventory.Add(missing);
                                                            GetInventry.ForEach(a => a.Verified = 1);
                                                            GetInventry.ForEach(a => a.Last_Update = DateTime.Now);
                                                            StockItem.Current_Stock = StockItem.Current_Stock + TotalAddingQuanttity;
                                                            db.SaveChanges();
                                                        }
                                                        else if (PostItemQuntity < inventoryQuantity)//stock sheet quantity less then inventry quantity
                                                        {
                                                            tbl_missing_inventory missing = new tbl_missing_inventory();
                                                            missing.Actual_Quantity = inventoryQuantity;
                                                            missing.Reported_Quantity = Convert.ToInt32(PostListItms.Quntity);
                                                            missing.Reported_on = DateTime.Now;
                                                            missing.SO_StockCount_Item_DetailsID = obListItems.ID;
                                                            missing.Case_Status_ID = 2;
                                                            missing.SO_StockCount_ID = obStockCountSheet.ID;


                                                            int TotalDeductQuanttity = inventoryQuantity - PostItemQuntity;
                                                            int DeductQuantity = TotalDeductQuanttity;
                                                            foreach (var InventryItem in GetInventry)
                                                            {
                                                                if (TotalDeductQuanttity == 0)
                                                                    break;
                                                                else
                                                                {
                                                                    if (InventryItem.Quantity >= TotalDeductQuanttity)
                                                                    {
                                                                        InventryItem.Quantity = InventryItem.Quantity - TotalDeductQuanttity;
                                                                        TotalDeductQuanttity = 0;

                                                                        db.SaveChanges();
                                                                    }
                                                                    else
                                                                    {
                                                                        TotalDeductQuanttity = TotalDeductQuanttity - InventryItem.Quantity;
                                                                        InventryItem.Quantity = 0;
                                                                        db.SaveChanges();
                                                                    }
                                                                    missing.tbl_inventory_ID = InventryItem.ID;
                                                                }
                                                            }
                                                            missing.Remarks = DeductQuantity + " item is less then system inventory";
                                                            missing.Action_Taken = DeductQuantity + " item is Deducted from system inventory";
                                                            db.tbl_missing_inventory.Add(missing);
                                                            GetInventry.ForEach(a => a.Verified = 1);
                                                            GetInventry.ForEach(a => a.Last_Update = DateTime.Now);
                                                            StockItem.Current_Stock = StockItem.Current_Stock - DeductQuantity;
                                                            db.SaveChanges();
                                                        }
                                                        #endregion
                                                        break;
                                                    }
                                                case 2: //with batch No.
                                                    {
                                                        #region Case 2
                                                        var Batch = PostListItms.Batch_No.Split('#');
                                                        var Quntity = PostListItms.Quntity.Split('#');
                                                        for (int i = 0; i < Batch.Length; i++)
                                                        {
                                                            string Batch_No = "";
                                                            if (Batch.Length >= (i + 1))
                                                                Batch_No = Batch[i];
                                                            int BatchQuntity = 1;
                                                            if (Quntity.Length >= (i + 1))
                                                                BatchQuntity = Convert.ToInt32(Quntity[i]);

                                                            var GetInventry = db.tbl_inventory.Where(a => a.Item_ID == obListItems.Stock_Item_ID && a.Batch_No == Batch_No && a.Quantity > 0).ToList();
                                                            if (GetInventry != null)
                                                            {
                                                                int inventoryQuantity = 0;
                                                                if (GetInventry != null)
                                                                    inventoryQuantity = GetInventry.Sum(d => d.Quantity);
                                                                if (BatchQuntity == inventoryQuantity)
                                                                {
                                                                    GetInventry.ForEach(a => a.Verified = 1);
                                                                    GetInventry.ForEach(a => a.Last_Update = DateTime.Now);
                                                                    db.SaveChanges();
                                                                }
                                                                else if (inventoryQuantity == 0)// item not exist Adding item in inventory table and stock table
                                                                {
                                                                    tbl_inventory inventry = new tbl_inventory();
                                                                    inventry.tbl_Purchase_Order_ID = 0;//adding by inventory count
                                                                    inventry.Quantity = BatchQuntity;
                                                                    inventry.Batch_No = Batch_No;
                                                                    inventry.Serial_No = "";
                                                                    inventry.Last_Update = DateTime.Now;
                                                                    inventry.Verified = 1;
                                                                    inventry.Item_ID = obListItems.Stock_Item_ID;
                                                                    inventry.SO_StockCount_ID = obStockCountSheet.ID;
                                                                    inventry.Case_Status_ID = 2;
                                                                    db.tbl_inventory.Add(inventry);
                                                                    db.SaveChanges();
                                                                    //Add on missing inventry
                                                                    tbl_missing_inventory missing = new tbl_missing_inventory();
                                                                    missing.Actual_Quantity = 0;
                                                                    missing.Reported_Quantity = BatchQuntity;
                                                                    missing.Reported_on = DateTime.Now;
                                                                    missing.SO_StockCount_Item_DetailsID = obListItems.ID;
                                                                    missing.Case_Status_ID = 2;
                                                                    missing.SO_StockCount_ID = obStockCountSheet.ID;
                                                                    missing.tbl_inventory_ID = inventry.ID;
                                                                    missing.Remarks = "'" + Batch_No + "' is not found in system inventory.";
                                                                    missing.Action_Taken = "'" + Batch_No + " is added in system inventory.";
                                                                    db.tbl_missing_inventory.Add(missing);
                                                                    StockItem.Current_Stock = StockItem.Current_Stock + BatchQuntity;

                                                                }
                                                                else if (BatchQuntity > inventoryQuantity)//stock sheet quantity greater then inventry quantity
                                                                {
                                                                    int TotalAddingQuanttity = BatchQuntity - inventoryQuantity;
                                                                    //Add these items in inventory table
                                                                    tbl_inventory tblInventry = new tbl_inventory();
                                                                    tblInventry.tbl_Purchase_Order_ID = 0;
                                                                    tblInventry.Quantity = TotalAddingQuanttity;
                                                                    tblInventry.Last_Update = DateTime.Now;
                                                                    tblInventry.Batch_No = Batch_No;
                                                                    tblInventry.Serial_No = "";
                                                                    tblInventry.Verified = 1;
                                                                    tblInventry.Item_ID = obListItems.Stock_Item_ID;
                                                                    tblInventry.SO_StockCount_ID = obStockCountSheet.ID;
                                                                    tblInventry.Case_Status_ID = 2;
                                                                    db.tbl_inventory.Add(tblInventry);
                                                                    db.SaveChanges();

                                                                    tbl_missing_inventory missing = new tbl_missing_inventory();
                                                                    missing.Actual_Quantity = inventoryQuantity;
                                                                    missing.Reported_Quantity = BatchQuntity;
                                                                    missing.Reported_on = DateTime.Now;
                                                                    missing.SO_StockCount_ID = obStockCountSheet.ID;
                                                                    missing.SO_StockCount_Item_DetailsID = obListItems.ID;
                                                                    missing.Case_Status_ID = 2;
                                                                    missing.tbl_inventory_ID = tblInventry.ID;
                                                                    missing.Remarks = TotalAddingQuanttity + " quantity for '" + Batch_No + "' is greater then system inventory.";
                                                                    missing.Action_Taken = TotalAddingQuanttity + " quantity for '" + Batch_No + " is added in system inventory.";
                                                                    db.tbl_missing_inventory.Add(missing);

                                                                    GetInventry.ForEach(a => a.Verified = 1);
                                                                    GetInventry.ForEach(a => a.Last_Update = DateTime.Now);
                                                                    StockItem.Current_Stock = StockItem.Current_Stock + TotalAddingQuanttity;
                                                                }
                                                                else if (BatchQuntity < inventoryQuantity)//stock sheet quantity less then inventry quantity
                                                                {//Deduction of inventry
                                                                    tbl_missing_inventory missing = new tbl_missing_inventory();
                                                                    missing.Actual_Quantity = inventoryQuantity;
                                                                    missing.Reported_Quantity = BatchQuntity;
                                                                    missing.Reported_on = DateTime.Now;
                                                                    missing.SO_StockCount_Item_DetailsID = obListItems.ID;
                                                                    missing.Case_Status_ID = 2;
                                                                    missing.SO_StockCount_ID = obStockCountSheet.ID;

                                                                    int TotalDeductQuantity = inventoryQuantity - BatchQuntity;
                                                                    int DeductQuantity = TotalDeductQuantity;
                                                                    foreach (var InventryItem in GetInventry)
                                                                    {
                                                                        if (TotalDeductQuantity == 0)
                                                                            break;
                                                                        else
                                                                        {
                                                                            if (InventryItem.Quantity >= TotalDeductQuantity)
                                                                            {
                                                                                InventryItem.Quantity = InventryItem.Quantity - TotalDeductQuantity;
                                                                                TotalDeductQuantity = 0;
                                                                                db.SaveChanges();
                                                                            }
                                                                            else
                                                                            {
                                                                                TotalDeductQuantity = TotalDeductQuantity - InventryItem.Quantity;
                                                                                InventryItem.Quantity = 0;
                                                                                db.SaveChanges();
                                                                            }
                                                                            missing.tbl_inventory_ID = InventryItem.ID;
                                                                        }
                                                                    }
                                                                    GetInventry.ForEach(a => a.Verified = 1);
                                                                    GetInventry.ForEach(a => a.Last_Update = DateTime.Now);
                                                                    StockItem.Current_Stock = StockItem.Current_Stock - DeductQuantity;
                                                                    //Add on missing inventry
                                                                    missing.Remarks = DeductQuantity + " quantity for '" + Batch_No + "' is less then system inventory.";
                                                                    missing.Action_Taken = DeductQuantity + " quantity for '" + Batch_No + " is deducted from system inventory.";
                                                                    db.tbl_missing_inventory.Add(missing);
                                                                }
                                                            }
                                                            db.SaveChanges();
                                                        }
                                                        #endregion
                                                        break;
                                                    }
                                                case 3://with batch no. and serial no.
                                                    {
                                                        #region Case 3
                                                        var Batch = PostListItms.Batch_No.Split('#');
                                                        var Serial = PostListItms.Serial_No.Split('#');
                                                        //var Rcd_Quntity = PostListItms.Quntity.Split('#');
                                                        for (int i = 0; i < Serial.Length; i++)
                                                        {
                                                            string Batch_No = "";
                                                            if (Batch.Length >= (i + 1))
                                                                Batch_No = Batch[i];

                                                            string Serial_No = "";
                                                            if (Serial.Length >= (i + 1))
                                                                Serial_No = Serial[i];


                                                            var GetInventory = db.tbl_inventory.Where(a => a.Item_ID == obListItems.Stock_Item_ID && a.Serial_No == Serial_No && a.Batch_No == Batch_No && a.Quantity > 0).FirstOrDefault();
                                                            if (GetInventory != null)
                                                            {
                                                                GetInventory.Verified = 1;
                                                                GetInventory.Last_Update = DateTime.Now;
                                                                db.SaveChanges();
                                                            }
                                                            else// item not exist Adding item in inventory table and stock table
                                                            {
                                                                tbl_inventory inventry = new tbl_inventory();
                                                                inventry.tbl_Purchase_Order_ID = 0;//adding by inventory count
                                                                inventry.Quantity = 1;
                                                                inventry.Batch_No = Batch_No;
                                                                inventry.Serial_No = Serial_No;
                                                                inventry.Last_Update = DateTime.Now;
                                                                inventry.Verified = 1;
                                                                inventry.Item_ID = obListItems.Stock_Item_ID;
                                                                inventry.SO_StockCount_ID = obStockCountSheet.ID;
                                                                inventry.Case_Status_ID = 2;
                                                                db.tbl_inventory.Add(inventry);
                                                                db.SaveChanges();
                                                                StockItem.Current_Stock = StockItem.Current_Stock + 1;

                                                                tbl_missing_inventory missing = new tbl_missing_inventory();
                                                                missing.Actual_Quantity = 0;
                                                                missing.Reported_Quantity = 1;
                                                                missing.Reported_on = DateTime.Now;
                                                                missing.SO_StockCount_ID = obStockCountSheet.ID;
                                                                missing.SO_StockCount_Item_DetailsID = obListItems.ID;
                                                                missing.Case_Status_ID = 2;
                                                                missing.tbl_inventory_ID = inventry.ID;
                                                                missing.Remarks = "Batch no. '" + Batch_No + "' and ' serial no. " + Serial_No + "' is not found system inventory.";
                                                                missing.Action_Taken = "Batch no. '" + Batch_No + "' and serial no. '" + Serial_No + "' is added in system inventory.";
                                                                db.tbl_missing_inventory.Add(missing);
                                                                db.SaveChanges();
                                                            }

                                                        }
                                                        #endregion
                                                        break;
                                                    }
                                                case 4://only serial no.
                                                    {
                                                        #region Case 3
                                                        var Serial = PostListItms.Serial_No.Split('#');
                                                        //var Rcd_Quntity = PostListItms.Quntity.Split('#');
                                                        for (int i = 0; i < Serial.Length; i++)
                                                        {
                                                            string Serial_No = "";
                                                            if (Serial.Length >= (i + 1))
                                                                Serial_No = Serial[i];


                                                            var GetInventory = db.tbl_inventory.Where(a => a.Item_ID == obListItems.Stock_Item_ID && a.Serial_No == Serial_No && a.Quantity > 0).FirstOrDefault();
                                                            if (GetInventory != null)
                                                            {
                                                                GetInventory.Verified = 1;
                                                                db.SaveChanges();
                                                            }
                                                            else// item not exist Adding item in inventory table and stock table
                                                            {
                                                                tbl_inventory inventry = new tbl_inventory();

                                                                inventry.tbl_Purchase_Order_ID = 0;//adding by inventory count
                                                                inventry.Quantity = 1;
                                                                inventry.Batch_No = "";
                                                                inventry.Last_Update = DateTime.Now;
                                                                inventry.Verified = 1;
                                                                inventry.Serial_No = Serial_No;
                                                                inventry.Item_ID = obListItems.Stock_Item_ID;
                                                                inventry.SO_StockCount_ID = obStockCountSheet.ID;
                                                                inventry.Case_Status_ID = 2;
                                                                db.tbl_inventory.Add(inventry);
                                                                db.SaveChanges();
                                                                StockItem.Current_Stock = StockItem.Current_Stock + 1;

                                                                tbl_missing_inventory missing = new tbl_missing_inventory();
                                                                missing.Actual_Quantity = 0;
                                                                missing.Reported_Quantity = 1;
                                                                missing.Reported_on = DateTime.Now;
                                                                missing.SO_StockCount_ID = obStockCountSheet.ID;
                                                                missing.SO_StockCount_Item_DetailsID = obListItems.ID;
                                                                missing.Case_Status_ID = 2;
                                                                missing.Remarks = "Serial no. '" + Serial_No + "' is not found in system inventory.";
                                                                missing.Action_Taken = "Serial no. '" + Serial_No + "' is added in system inventory.";
                                                                missing.tbl_inventory_ID = inventry.ID;
                                                                db.tbl_missing_inventory.Add(missing);
                                                                db.SaveChanges();
                                                            }

                                                        }
                                                        #endregion
                                                        break;
                                                    }
                                            }
                                        }

                                    }//end stock item
                                    else
                                        message.Message = message.Message + " Item '" + PostListItms.ID + "' is not exist in stock item list.";
                                        
                                }
                            }
                            obStockCountSheet.m_Status_ID = StockList.Phone_Status;
                            obStockCountSheet.Remarks = StockList.Remarks;
                            db.SaveChanges();
                            lstStokCountMessage.Add(message);
                        }
                    }
                    response = Request.CreateResponse(HttpStatusCode.OK, lstStokCountMessage);
                }
              
            }
            catch (Exception ex)
            {
                writelog = new Writelog();
                writelog.write_exception_log(0, "WDCAPIController", "PostStockCountSheet", DateTime.Now, ex);
                response = Request.CreateResponse(HttpStatusCode.ServiceUnavailable, "Error");
            }
            return response;
        }

    }
}