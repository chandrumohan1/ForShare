﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WDC.Models;

namespace WDC.Controllers
{
    public class ReportController : Controller
    {
        ApplicationDbContext m_db = new ApplicationDbContext();
        comman_function cf = null;
        Writelog writelog = null;
        #region Stock Report
        public ActionResult MasterStockReport(FormCollection form, int? ddl_export, string txtItemNo, int? ddl_statuslist, int? ddl_locationlist, int? ddl_Sublocationlist)
        {
            List<Viewstock_details> list = new List<Viewstock_details>();
            try
            {
                int LocationID = 0;
                cf = new comman_function();
                List<SelectListItem> ListStockStatus = cf.GetStockAllStatus();
                List<SelectListItem> ListLocationList = cf.GetAllLocationList();
                List<SelectListItem> ListSubLocationList = cf.GetSubLocationAllList(LocationID);
                ViewData["ListStockStatus"] = ListStockStatus;
                ViewData["ListLocationList"] = ListLocationList;
                ViewData["ListSubLocationList"] = ListSubLocationList;
                ViewData["ExportList"] = cf.GetExportList();
                
                var getStock = (from obj_stock in m_db.stock_details
                                join obj_unit in m_db.m_Stock_Unit on obj_stock.m_Stock_Unit_ID equals obj_unit.ID
                                join obj_type in m_db.m_Stock_Type on obj_stock.m_Stock_type_ID equals obj_type.ID
                                join obj_location in m_db.Location_Details on obj_stock.Location_ID equals obj_location.ID
                                into loc
                                from obloc in loc.DefaultIfEmpty()
                                join obj_sublocation in m_db.Location_Details on obj_stock.Sub_Location_ID equals obj_sublocation.ID into sloc
                                from subloc in sloc.DefaultIfEmpty()
                                join obj_status in m_db.m_stock_status on obj_stock.m_stock_status_id equals obj_status.ID
                                select new
                                {
                                    obj_stock = obj_stock,
                                    obj_unit = obj_unit,
                                    obj_type = obj_type,
                                    obj_location = obloc,
                                    obj_sublocation = subloc,
                                    obj_status = obj_status
                                }).ToList();

                if (getStock != null)
                {
                    if (ddl_statuslist != null && ddl_statuslist != 0)
                    {
                        getStock = getStock.Where(a => a.obj_stock.m_stock_status_id == ddl_statuslist).ToList();
                    }
                }
                if (getStock != null)
                {
                    if (ddl_locationlist != null && ddl_locationlist != 0)
                    {
                        getStock = getStock.Where(a => a.obj_stock.Location_ID == ddl_locationlist).ToList();
                    }
                }
                if (getStock != null)
                {
                    if (ddl_Sublocationlist != null && ddl_Sublocationlist != 0)
                    {
                        getStock = getStock.Where(a => a.obj_stock.Sub_Location_ID == ddl_Sublocationlist).ToList();
                    }
                }
                if (getStock != null)
                {
                    if (txtItemNo != null && txtItemNo != "")
                    {
                        getStock = getStock.Where(a => a.obj_stock.Item_No.Contains(txtItemNo)).ToList();
                    }
                }
                var GetBarcode = m_db.m_barcode_setting.Where(a => a.m_Status_ID == 1).FirstOrDefault();



                foreach (var item in getStock)
                {
                    Viewstock_details ViewStock = new Viewstock_details();
                    ViewStock.ID = item.obj_stock.ID;
                    ViewStock.Description = item.obj_stock.Description;
                    ViewStock.Status = item.obj_status.Status;
                    ViewStock.Item_Name = item.obj_stock.Item_Name;
                    ViewStock.Item_No = item.obj_stock.Item_No;
                    ViewStock.Stock_type = item.obj_type.Stock_Type;
                    ViewStock.Reorder_Level = item.obj_stock.Reorder_Level;
                    ViewStock.Current_Stock = item.obj_stock.Current_Stock;
                    ViewStock.Stock_Unit = item.obj_unit.Unit;
                    if (item.obj_location != null)
                    {
                        ViewStock.Location = item.obj_location.Area;
                        if (item.obj_sublocation != null)
                        {
                            ViewStock.Location = item.obj_location.Area + "/" + item.obj_sublocation.Area;
                        }
                    }
                    list.Add(ViewStock);
                }
                string value = form["command"];
                string sendOnMail = form["sendmail"];
                if (value == "Export" || sendOnMail == "Send On Mail")
                {
                    if (ddl_export != null)
                    {
                        bool mail = false;
                        if (sendOnMail != null) mail = true;
                        string EmailID = form["txt_email"];


                        DataTable header = new DataTable();
                        string colum = " ";
                        for (int i = 0; i < 6; i++)
                        {
                            header.Columns.Add(colum);
                            colum = colum + " ";
                        }
                        DataRow erow = header.NewRow();
                        erow[2] = " ";
                        header.Rows.Add(erow);
                        DataRow drow = header.NewRow();
                        drow[1] = "Item No";
                        drow[2] = txtItemNo;
                        drow[4] = "Report Taken On";
                        drow[5] = DateTime.Now.ToString("dd MMM yyyy");
                        header.Rows.Add(drow);
                        DataRow brow = header.NewRow();
                        brow[1] = "Status";
                        brow[2] = ListStockStatus.Find(a => a.Value == ddl_statuslist.ToString()).Text;
                        brow[4] = "Report Taken By";
                        brow[5] = User.Identity.Name;
                        header.Rows.Add(brow);
                        DataRow frow = header.NewRow();
                        frow[1] = "Location";
                        frow[2] = ListLocationList.Find(a => a.Value == ddl_locationlist.ToString()).Text;
                        header.Rows.Add(frow);

                        DataRow lrow = header.NewRow();
                        lrow[1] = "Sub Location";
                        lrow[2] = ListSubLocationList.Find(a => a.Value == ddl_Sublocationlist.ToString()).Text;
                        header.Rows.Add(lrow);
                        DataRow eerow = header.NewRow();
                        eerow[2] = " ";
                        header.Rows.Add(eerow);

                        DataTable export_dt = cf.CreateTableMasterStock(list);

                        int type = Convert.ToInt32(ddl_export);
                        if (export_dt.Rows.Count > 0)
                        {
                            int r = cf.Export("Master Stock Report", header, export_dt, Response, type, mail, EmailID);
                            if (r == 3) ViewData["Message"] = DisplayMessage.ReportSentOnMail;
                        }
                        else ViewData["Message"] = DisplayMessage.NoRecord;

                    }
                    else ViewData["Message"] = DisplayMessage.SelectExport;
                }
            }
            catch (Exception ex)
            {
                ViewData["Message"] = DisplayMessage.ErrorMessage;
                writelog = new Writelog();
                writelog.write_exception_log(0, "ReportController", "MasterStockReport", DateTime.Now, ex);
            }
            return View(list);
        }
        #endregion
        #region PO Report
        public ActionResult POSummary(FormCollection form,int? ddl_export, int? ddl_Vender, string txtPurchaseOrderNo, int? ddl_AssignedUsers, int? ddl_status)
        {
            List<View_PurchaseOrder_Details> lst_purchase = new List<View_PurchaseOrder_Details>();
            try
            {
                cf = new comman_function();
                List<SelectListItem> lst_AllVender = cf.GetAllVenderList();
                List<SelectListItem> lst_AllEmployee = cf.GetAllHHTEmployeeList();
                List<SelectListItem> lst_POStatus = cf.GetAllPurchaseOrderStatus();
                ViewData["AllEmployeeList"] = lst_AllEmployee;
                ViewData["VenderList"] = lst_AllVender;
                ViewData["POStatusList"] = lst_POStatus;
                ViewData["ExportList"] = cf.GetExportList();
                string value = form["command"];
              
                var GetPurchaseOrder = (from ob_purchase in m_db.PurchaseOrder_Details
                                        join ob_vender in m_db.Vendor_Details on ob_purchase.Vender_ID equals ob_vender.ID
                                        join ob_status in m_db.tbl_Purchase_Order_Status on ob_purchase.tbl_Purchase_Order_Status_ID equals ob_status.ID

                                        select new
                                        {
                                            ob_vender = ob_vender,
                                            ob_purchase = ob_purchase,
                                            ob_status = ob_status

                                        }).OrderByDescending(a => a.ob_purchase.ID).ToList();
                if (GetPurchaseOrder != null)
                {
                    if (ddl_Vender != null && ddl_Vender != 0)
                    {
                        GetPurchaseOrder = GetPurchaseOrder.Where(a => a.ob_purchase.Vender_ID == ddl_Vender).ToList();
                    }
                }
                if (GetPurchaseOrder != null)
                {
                    if (txtPurchaseOrderNo != null && txtPurchaseOrderNo != "")
                    {
                        GetPurchaseOrder = GetPurchaseOrder.Where(a => a.ob_purchase.Purchase_Order_Number.Contains(txtPurchaseOrderNo)).ToList();
                    }
                }
                if (GetPurchaseOrder != null && ddl_AssignedUsers != null && ddl_AssignedUsers != 0)
                {
                    GetPurchaseOrder = GetPurchaseOrder.Where(a => a.ob_purchase.Assigned_User_ID == ddl_AssignedUsers).ToList();
                }
                if (GetPurchaseOrder != null && ddl_status != null && ddl_status != 0)
                {
                    GetPurchaseOrder = GetPurchaseOrder.Where(a => a.ob_purchase.tbl_Purchase_Order_Status_ID == ddl_status).ToList();
                }
                foreach (var item in GetPurchaseOrder)
                {
                    View_PurchaseOrder_Details order = new View_PurchaseOrder_Details();
                    order.ID = item.ob_purchase.ID;
                    order.Status = item.ob_status.Status;
                    order.Vendor_Name = item.ob_vender.Vendor_Name;
                    order.DateOfPurchase = item.ob_purchase.DateOfPurchase.ToString("dd MMM yyyy");
                    order.Expected_Received_Date = item.ob_purchase.Expected_Received_Date.ToString("dd MMM yyyy");
                    order.Purchase_Order_Number = item.ob_purchase.Purchase_Order_Number;
                    if (item.ob_purchase.Actual_Received_Date.ToString() != "1/1/0001 12:00:00 AM" && item.ob_purchase.Actual_Received_Date != null)
                        order.Actual_Received_Date = Convert.ToDateTime(item.ob_purchase.Actual_Received_Date).ToString("dd MMM yyyy");
                    order.Remarks = item.ob_purchase.Remarks;
                    order.Total_Items = m_db.purchase_order_item_details.Where(a => a.Purchase_Order_Details_ID == order.ID).ToList().Count();
                    if (item.ob_purchase.Assigned_User_ID != 0)
                    {
                        string nameid = Convert.ToString(item.ob_purchase.Assigned_User_ID);
                        var details1 = m_db.Users.Where(m => m.Id == nameid).FirstOrDefault();
                        if (details1 != null)
                        {
                            if (details1.Name == null)
                            {
                                order.Assigned_User = " ";
                            }
                            else
                            {
                                order.Assigned_User = details1.Name;
                            }
                        }

                    }
                    else
                    {
                        order.Assigned_User = " ";
                    }
                    lst_purchase.Add(order);
                }
                string sendOnMail = form["sendmail"];
                if (value == "Export" || sendOnMail == "Send On Mail")
                {
                    if (ddl_export != null)
                    {
                        bool mail = false;
                        if (sendOnMail != null) mail = true;
                        string EmailID = form["txt_email"];


                        DataTable header = new DataTable();
                        string colum = " ";
                        for (int i = 0; i < 6; i++)
                        {
                            header.Columns.Add(colum);
                            colum = colum + " ";
                        }
                        DataRow erow = header.NewRow();
                        erow[2] = " ";
                        header.Rows.Add(erow);
                        DataRow drow = header.NewRow();
                        drow[1] = "Vender Name";
                        drow[2] = lst_AllVender.Find(a => a.Value == ddl_Vender.ToString()).Text;
                        drow[4] = "Report Taken On";
                        drow[5] = DateTime.Now.ToString("dd MMM yyyy");
                        header.Rows.Add(drow);
                        DataRow brow = header.NewRow();
                        brow[1] = "Purchase Order No.";
                        brow[2] = txtPurchaseOrderNo;
                        brow[4] = "Report Taken By";
                        brow[5] = User.Identity.Name;
                        header.Rows.Add(brow);
                        DataRow frow = header.NewRow();
                        frow[1] = "Assigned User Name";
                        frow[2] = lst_AllEmployee.Find(a => a.Value == ddl_AssignedUsers.ToString()).Text;
                        header.Rows.Add(frow);

                        DataRow lrow = header.NewRow();
                        lrow[1] = "PO Status";
                        lrow[2] = lst_POStatus.Find(a => a.Value == ddl_status.ToString()).Text;
                        header.Rows.Add(lrow);
                        DataRow eerow = header.NewRow();
                        eerow[2] = " ";
                        header.Rows.Add(eerow);

                        DataTable export_dt = cf.CreateTablePO(lst_purchase);

                        int type = Convert.ToInt32(ddl_export);
                        if (export_dt.Rows.Count > 0)
                        {
                            int r = cf.Export("PO Summary Report", header, export_dt, Response, type, mail, EmailID);
                            if (r == 3) ViewData["Message"] = DisplayMessage.ReportSentOnMail;
                        }
                        else ViewData["Message"] = DisplayMessage.NoRecord;

                    }
                    else ViewData["Message"] = DisplayMessage.SelectExport;
                }
            }
            catch (Exception ex)
            {
                ViewData["Message"] = DisplayMessage.ErrorMessage;
                writelog = new Writelog();
                writelog.write_exception_log(0, "ReportController", "POSummary", DateTime.Now, ex);
            }
            return View(lst_purchase);
        }
        public ActionResult PODetailed(FormCollection form, int? ddl_export, int? ddl_PONumber)
        {
            View_PurchaseOrder_Details purchase_order = new View_PurchaseOrder_Details();
            try
            {
                cf = new comman_function();
                ViewData["ExportList"] = cf.GetExportList();
                ViewData["POList"] = cf.GetPOList();
               
                if (ddl_PONumber != null && ddl_PONumber != 0)
                {
                    var GetPurchaseOrder = (from ob_purchase in m_db.PurchaseOrder_Details.Where(a => a.ID == ddl_PONumber)
                                            join ob_vender in m_db.Vendor_Details on ob_purchase.Vender_ID equals ob_vender.ID
                                            join ob_status in m_db.tbl_Purchase_Order_Status on ob_purchase.tbl_Purchase_Order_Status_ID equals ob_status.ID
                                            select new
                                            {
                                                ob_vender = ob_vender,
                                                ob_purchase = ob_purchase,
                                                ob_status = ob_status

                                            }).FirstOrDefault();
                    if (GetPurchaseOrder != null)
                    {
                        purchase_order.ID = GetPurchaseOrder.ob_purchase.ID;
                        purchase_order.Purchase_Order_Number = GetPurchaseOrder.ob_purchase.Purchase_Order_Number;
                        purchase_order.Vendor_Name = GetPurchaseOrder.ob_vender.Vendor_Name;
                        purchase_order.Remarks = GetPurchaseOrder.ob_purchase.Remarks;
                        purchase_order.Status = GetPurchaseOrder.ob_status.Status;
                        purchase_order.DateOfPurchase = GetPurchaseOrder.ob_purchase.DateOfPurchase.ToString("dd MMM yyy");
                        purchase_order.Expected_Received_Date = GetPurchaseOrder.ob_purchase.Expected_Received_Date.ToString("dd MMM yyy");
                        if (GetPurchaseOrder.ob_purchase.Actual_Received_Date != null)
                            purchase_order.Actual_Received_Date = Convert.ToDateTime(GetPurchaseOrder.ob_purchase.Actual_Received_Date).ToString("dd MMM yyy");
                        purchase_order.Assigned_User = m_db.Users.Where(a => a.Id == GetPurchaseOrder.ob_purchase.Assigned_User_ID.ToString()).FirstOrDefault().Name;

                        purchase_order.View_PurchaseOrder_Item = new List<View_PurchaseOrder_Item>();
                        var GetOrderItem = (from ob_order_item in m_db.purchase_order_item_details.Where(a => a.Purchase_Order_Details_ID == purchase_order.ID)
                                            join ob_Items in m_db.stock_details on ob_order_item.Item_ID equals ob_Items.ID

                                            select new
                                            {
                                                ob_Items = ob_Items,
                                                ob_order_item = ob_order_item
                                            }).ToList();
                        foreach (var item in GetOrderItem)
                        {

                            View_PurchaseOrder_Item order_item = new View_PurchaseOrder_Item();
                            order_item.Item_ID = item.ob_order_item.Item_ID;
                            order_item.Item_Name = item.ob_Items.Item_Name;
                            order_item.Quantity = item.ob_order_item.Quantity;
                            order_item.Cost_Per_Item = item.ob_order_item.Cost_Per_Item;
                            order_item.Batch_No = item.ob_order_item.Batch_No;
                            order_item.Serial_No = item.ob_order_item.Serial_No;
                            order_item.Scan_Value = item.ob_order_item.Scan_Value;
                            order_item.Rcd_Quntity = item.ob_order_item.Rcd_Quntity.ToString();
                            purchase_order.View_PurchaseOrder_Item.Add(order_item);
                        }
                        string value = form["command"];
                        string sendOnMail = form["sendmail"];
                        if (value == "Export" || sendOnMail == "Send On Mail")
                        {
                            if (ddl_export != null)
                            {
                                bool mail = false;
                                if (sendOnMail != null) mail = true;
                                string EmailID = form["txt_email"];


                                DataTable header = new DataTable();
                                string colum = " ";
                                for (int i = 0; i < 6; i++)
                                {
                                    header.Columns.Add(colum);
                                    colum = colum + " ";
                                }
                                DataRow erow = header.NewRow();
                                erow[2] = " ";
                                header.Rows.Add(erow);
                                DataRow drow = header.NewRow();
                                drow[1] = "Purchase Order No.";
                                drow[2] = purchase_order.Purchase_Order_Number;
                                drow[4] = "Report Taken On";
                                drow[5] = DateTime.Now.ToString("dd MMM yyyy");
                                header.Rows.Add(drow);
                                DataRow brow = header.NewRow();
                                brow[1] = "Vender Name";
                                brow[2] = purchase_order.Vendor_Name;
                                brow[4] = "Report Taken By";
                                brow[5] = User.Identity.Name;
                                header.Rows.Add(brow);
                                DataRow pbrow = header.NewRow();
                                pbrow[1] = "Date Of Purchase";
                                pbrow[2] = purchase_order.DateOfPurchase;
                                header.Rows.Add(pbrow);
                                DataRow epbrow = header.NewRow();
                                epbrow[1] = "Expected Date Of Received";
                                epbrow[2] = purchase_order.Expected_Received_Date;
                                header.Rows.Add(epbrow);
                                DataRow aepbrow = header.NewRow();
                                aepbrow[1] = "Actual Date Of Received";
                                aepbrow[2] = purchase_order.Actual_Received_Date;
                                header.Rows.Add(aepbrow);
                                DataRow raepbrow = header.NewRow();
                                raepbrow[1] = "Remarks";
                                raepbrow[2] = purchase_order.Remarks;
                                header.Rows.Add(raepbrow);

                                DataRow sraepbrow = header.NewRow();
                                sraepbrow[1] = "Order Status";
                                sraepbrow[2] = purchase_order.Status;
                                header.Rows.Add(sraepbrow);

                                DataRow usraepbrow = header.NewRow();
                                usraepbrow[1] = "User Assigned";
                                usraepbrow[2] = purchase_order.Assigned_User;
                                header.Rows.Add(usraepbrow);


                                DataRow eerow = header.NewRow();
                                eerow[2] = " ";
                                header.Rows.Add(eerow);

                                DataTable export_dt = cf.CreateTablePurchaseItems(purchase_order.View_PurchaseOrder_Item);

                                int type = Convert.ToInt32(ddl_export);
                                if (export_dt.Rows.Count > 0)
                                {
                                    int r = cf.Export("PO Detailed Report", header, export_dt, Response, type, mail, EmailID);
                                    if (r == 3) ViewData["Message"] = DisplayMessage.ReportSentOnMail;
                                }
                                else ViewData["Message"] = DisplayMessage.NoRecord;

                            }
                            else ViewData["Message"] = DisplayMessage.SelectExport;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ViewData["Message"] = DisplayMessage.ErrorMessage;
                writelog = new Writelog();
                writelog.write_exception_log(0, "ReportController", "PODetailed", DateTime.Now, ex);
            }
            return View(purchase_order);
        }
        #endregion
        #region SO Report
        public ActionResult SOSummary(FormCollection form, int? ddl_export, int? ddl_Client, string txtSalesOrderNo, int? ddl_AssignedUsers, int? ddl_status)
        {
            List<ViewSales_Order_Detail> lst_Sales = new List<ViewSales_Order_Detail>();
            try
            {
                cf = new comman_function();
                List<SelectListItem> lst_Client = cf.GetAllClientList();
                List<SelectListItem> lst_AllEmployee = cf.GetAllHHTEmployeeList();
                List<SelectListItem> lst_SOStatus = cf.GetAllSalesOrderStatus();
                ViewData["AllEmployeeList"] = lst_AllEmployee;
                ViewData["ClientList"] = lst_Client;
                ViewData["SOStatusList"] = lst_SOStatus;
                ViewData["ExportList"] = cf.GetExportList();
                string value = form["command"];
                var GetSalesOrder = (from ob_sales in m_db.Sales_Order_Details
                                     join ob_status in m_db.tbl_Sales_Order_Status on ob_sales.tbl_Sales_Order_Status_ID equals ob_status.ID
                                     join ob_Customer in m_db.Customer_Details on ob_sales.Customer_ID equals ob_Customer.ID

                                     select new
                                     {
                                         ob_Customer = ob_Customer,
                                         ob_sales = ob_sales,
                                         ob_status = ob_status

                                     }).ToList();
                if (GetSalesOrder != null)
                {
                    if (ddl_Client != null && ddl_Client != 0)
                    {
                        GetSalesOrder = GetSalesOrder.Where(a => a.ob_sales.Customer_ID == ddl_Client).ToList();
                    }
                }
                if (GetSalesOrder != null)
                {
                    if (txtSalesOrderNo != null && txtSalesOrderNo != "")
                    {
                        GetSalesOrder = GetSalesOrder.Where(a => a.ob_sales.SalesOrderNo.Contains(txtSalesOrderNo)).ToList();
                    }
                }
                if (GetSalesOrder != null && ddl_AssignedUsers != null && ddl_AssignedUsers != 0)
                {
                    GetSalesOrder = GetSalesOrder.Where(a => a.ob_sales.Assigned_User_ID == ddl_AssignedUsers).ToList();
                }
                if (GetSalesOrder != null && ddl_status != null && ddl_status != 0)
                {
                    GetSalesOrder = GetSalesOrder.Where(a => a.ob_sales.tbl_Sales_Order_Status_ID == ddl_status).ToList();
                }


                foreach (var item in GetSalesOrder)
                {
                    ViewSales_Order_Detail order = new ViewSales_Order_Detail();
                    order.ID = item.ob_sales.ID;
                    order.name = item.ob_Customer.name;
                    order.DateOfOrder = item.ob_sales.DateOfOrder.ToString("dd MMM yyyy");
                    order.ExpectedDateOfDelivery = item.ob_sales.ExpectedDateOfDelivery.ToString("dd MMM yyyy");
                    order.SalesOrderNo = item.ob_sales.SalesOrderNo;
                    order.Status = item.ob_status.Status;
                    order.Remarks = item.ob_sales.Remarks;
                    if (item.ob_sales.Actual_Delivery_Date.ToString() != "1/1/0001 12:00:00 AM" && item.ob_sales.Actual_Delivery_Date != null)
                        order.Actual_Delivery_Date = Convert.ToDateTime(item.ob_sales.Actual_Delivery_Date).ToString("dd MMM yyyy"); ;
                    order.Total_Items = m_db.Sales_Order_Item_Details.Where(a => a.sales_Order_Detail_ID == order.ID).ToList().Count;
                    if (item.ob_sales.Assigned_User_ID != 0)
                    {
                        string nameid = Convert.ToString(item.ob_sales.Assigned_User_ID);
                        var details1 = m_db.Users.Where(m => m.Id == nameid).FirstOrDefault();
                        if (details1 != null)
                        {
                            if (details1.Name == null)
                            {
                                order.Assigned_User = " ";
                            }
                            else
                            {
                                order.Assigned_User = details1.Name;
                            }
                        }

                    }
                    else
                    {
                        order.Assigned_User = " ";
                    }

                    lst_Sales.Add(order);
                }
                string sendOnMail = form["sendmail"];
                if (value == "Export" || sendOnMail == "Send On Mail")
                {
                    if (ddl_export != null)
                    {
                        bool mail = false;
                        if (sendOnMail != null) mail = true;
                        string EmailID = form["txt_email"];


                        DataTable header = new DataTable();
                        string colum = " ";
                        for (int i = 0; i < 6; i++)
                        {
                            header.Columns.Add(colum);
                            colum = colum + " ";
                        }
                        DataRow erow = header.NewRow();
                        erow[2] = " ";
                        header.Rows.Add(erow);
                        DataRow drow = header.NewRow();
                        drow[1] = "Client Name";
                        drow[2] = lst_Client.Find(a => a.Value == ddl_Client.ToString()).Text;
                        drow[4] = "Report Taken On";
                        drow[5] = DateTime.Now.ToString("dd MMM yyyy");
                        header.Rows.Add(drow);
                        DataRow brow = header.NewRow();
                        brow[1] = "Sales Order No.";
                        brow[2] = txtSalesOrderNo;
                        brow[4] = "Report Taken By";
                        brow[5] = User.Identity.Name;
                        header.Rows.Add(brow);
                        DataRow frow = header.NewRow();
                        frow[1] = "Assigned User Name";
                        frow[2] = lst_AllEmployee.Find(a => a.Value == ddl_AssignedUsers.ToString()).Text;
                        header.Rows.Add(frow);

                        DataRow lrow = header.NewRow();
                        lrow[1] = "SO Status";
                        lrow[2] = lst_SOStatus.Find(a => a.Value == ddl_status.ToString()).Text;
                        header.Rows.Add(lrow);
                        DataRow eerow = header.NewRow();
                        eerow[2] = " ";
                        header.Rows.Add(eerow);

                        DataTable export_dt = cf.CreateTableSO(lst_Sales);

                        int type = Convert.ToInt32(ddl_export);
                        if (export_dt.Rows.Count > 0)
                        {
                            int r = cf.Export("SO Summary Report", header, export_dt, Response, type, mail, EmailID);
                            if (r == 3) ViewData["Message"] = DisplayMessage.ReportSentOnMail;
                        }
                        else ViewData["Message"] = DisplayMessage.NoRecord;

                    }
                    else ViewData["Message"] = DisplayMessage.SelectExport;


                }
            }
            catch (Exception ex)
            {
                ViewData["Message"] = DisplayMessage.ErrorMessage;
                writelog = new Writelog();
                writelog.write_exception_log(0, "ReportController", "SOSummary", DateTime.Now, ex);
            }
            return View(lst_Sales);
        }
        public ActionResult SODetailed(FormCollection form, int? ddl_export, int? ddl_SONumber)
        {
            ViewSales_Order_Detail sales_order = new ViewSales_Order_Detail();
            try
            {
                cf = new comman_function();
                ViewData["ExportList"] = cf.GetExportList();
                ViewData["SOList"] = cf.GetSOList();
               
                if (ddl_SONumber != null && ddl_SONumber != 0)
                {
                    var GetSalesOrder = (from ob_sales_order in m_db.Sales_Order_Details.Where(a => a.ID == ddl_SONumber)
                                         join ob_client in m_db.Customer_Details on ob_sales_order.Customer_ID equals ob_client.ID
                                         join ob_status in m_db.tbl_Sales_Order_Status on ob_sales_order.tbl_Sales_Order_Status_ID equals ob_status.ID
                                         select new
                                         {
                                             ob_sales = ob_sales_order,
                                             ob_client = ob_client,
                                             ob_status = ob_status

                                         }).FirstOrDefault();
                    if (GetSalesOrder != null)
                    {
                        sales_order.ID = GetSalesOrder.ob_sales.ID;
                        sales_order.SalesOrderNo = GetSalesOrder.ob_sales.SalesOrderNo;
                        sales_order.name = GetSalesOrder.ob_client.name;
                        sales_order.Remarks = GetSalesOrder.ob_sales.Remarks;
                        sales_order.Status = GetSalesOrder.ob_status.Status;
                        sales_order.DateOfOrder = GetSalesOrder.ob_sales.DateOfOrder.ToString("dd MMM yyy");
                        sales_order.ExpectedDateOfDelivery = GetSalesOrder.ob_sales.ExpectedDateOfDelivery.ToString("dd MMM yyy");
                        if (GetSalesOrder.ob_sales.Actual_Delivery_Date != null)
                            sales_order.Actual_Delivery_Date = Convert.ToDateTime(GetSalesOrder.ob_sales.Actual_Delivery_Date).ToString("dd MMM yyy");
                        sales_order.Assigned_User = m_db.Users.Where(a => a.Id == GetSalesOrder.ob_sales.Assigned_User_ID.ToString()).FirstOrDefault().Name;

                        sales_order.View_SalesOrder_Item = new List<View_SalesOrder_Item>();
                        var GetOrderItem = (from ob_order_item in m_db.Sales_Order_Item_Details.Where(a => a.sales_Order_Detail_ID == sales_order.ID)
                                            join ob_Items in m_db.stock_details on ob_order_item.Item_ID equals ob_Items.ID

                                            select new
                                            {
                                                ob_Items = ob_Items,
                                                ob_order_item = ob_order_item
                                            }).ToList();
                        foreach (var item in GetOrderItem)
                        {

                            View_SalesOrder_Item order_item = new View_SalesOrder_Item();
                            order_item.Item_ID = item.ob_order_item.Item_ID;
                            order_item.Item_Name = item.ob_Items.Item_Name;
                            order_item.Quantity = item.ob_order_item.Quantity;
                            order_item.Cost_Per_Item = item.ob_order_item.Cost_Per_Item;
                            order_item.Batch_No = item.ob_order_item.Batch_No;
                            order_item.Serial_No = item.ob_order_item.Serial_No;
                            order_item.Scan_Value = item.ob_order_item.Scan_Value;
                            order_item.Delivered_Quntity = item.ob_order_item.Delivered_Quntity.ToString();
                            sales_order.View_SalesOrder_Item.Add(order_item);
                        }
                        string value = form["command"];
                        string sendOnMail = form["sendmail"];
                        if (value == "Export" || sendOnMail == "Send On Mail")
                        {
                            if (ddl_export != null)
                            {
                                bool mail = false;
                                if (sendOnMail != null) mail = true;
                                string EmailID = form["txt_email"];


                                DataTable header = new DataTable();
                                string colum = " ";
                                for (int i = 0; i < 6; i++)
                                {
                                    header.Columns.Add(colum);
                                    colum = colum + " ";
                                }
                                DataRow erow = header.NewRow();
                                erow[2] = " ";
                                header.Rows.Add(erow);
                                DataRow drow = header.NewRow();
                                drow[1] = "Sales Order No.";
                                drow[2] = sales_order.SalesOrderNo;
                                drow[4] = "Report Taken On";
                                drow[5] = DateTime.Now.ToString("dd MMM yyyy");
                                header.Rows.Add(drow);
                                DataRow brow = header.NewRow();
                                brow[1] = "Client Name";
                                brow[2] = sales_order.name;
                                brow[4] = "Report Taken By";
                                brow[5] = User.Identity.Name;
                                header.Rows.Add(brow);
                                DataRow pbrow = header.NewRow();
                                pbrow[1] = "Date Of Order";
                                pbrow[2] = sales_order.DateOfOrder;
                                header.Rows.Add(pbrow);
                                DataRow epbrow = header.NewRow();
                                epbrow[1] = "Expected Date Of Delivery";
                                epbrow[2] = sales_order.ExpectedDateOfDelivery;
                                header.Rows.Add(epbrow);
                                DataRow aepbrow = header.NewRow();
                                aepbrow[1] = "Actual Date Of Delivery";
                                aepbrow[2] = sales_order.Actual_Delivery_Date;
                                header.Rows.Add(aepbrow);
                                DataRow raepbrow = header.NewRow();
                                raepbrow[1] = "Remarks";
                                raepbrow[2] = sales_order.Remarks;
                                header.Rows.Add(raepbrow);

                                DataRow sraepbrow = header.NewRow();
                                sraepbrow[1] = "Order Status";
                                sraepbrow[2] = sales_order.Status;
                                header.Rows.Add(sraepbrow);

                                DataRow usraepbrow = header.NewRow();
                                usraepbrow[1] = "User Assigned";
                                usraepbrow[2] = sales_order.Assigned_User;
                                header.Rows.Add(usraepbrow);


                                DataRow eerow = header.NewRow();
                                eerow[2] = " ";
                                header.Rows.Add(eerow);

                                DataTable export_dt = cf.CreateTableSalesItems(sales_order.View_SalesOrder_Item);

                                int type = Convert.ToInt32(ddl_export);
                                if (export_dt.Rows.Count > 0)
                                {
                                    int r = cf.Export("SO Detailed Report", header, export_dt, Response, type, mail, EmailID);
                                    if (r == 3) ViewData["Message"] = DisplayMessage.ReportSentOnMail;
                                }
                                else ViewData["Message"] = DisplayMessage.NoRecord;

                            }
                            else ViewData["Message"] = DisplayMessage.SelectExport;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ViewData["Message"] = DisplayMessage.ErrorMessage;
                writelog = new Writelog();
                writelog.write_exception_log(0, "ReportController", "SODetailed", DateTime.Now, ex);
            }
            return View(sales_order);
        }
        #endregion
        #region View Stock Sheet Report
        public ActionResult StockCountSheetSummary(FormCollection form, int? ddl_export, int? ddl_AssignedUsers, string txtSheetName)
        {
            List<View_Stock_Count_Details> lst_count_sheet = new List<View_Stock_Count_Details>();
            try
            {
                cf = new comman_function();
                List<SelectListItem> lst_AllEmployee = cf.GetAllHHTEmployeeList();
                ViewData["AllEmployeeList"] = lst_AllEmployee;
                ViewData["ExportList"] = cf.GetExportList();
              
                var GetStockSheet = m_db.tbl_Stock_Count_Details.OrderByDescending(a => a.ID).ToList();
                if (GetStockSheet != null && ddl_AssignedUsers != null && ddl_AssignedUsers != 0)
                    GetStockSheet = GetStockSheet.Where(a => a.User_Assigned_ID == ddl_AssignedUsers).ToList();
                if (GetStockSheet != null && txtSheetName != "" && txtSheetName != null)
                    GetStockSheet = GetStockSheet.Where(a => a.Stock_Name.ToLower().Contains(txtSheetName.ToLower())).ToList();
                foreach (var item in GetStockSheet)
                {
                    View_Stock_Count_Details count_sheet = new View_Stock_Count_Details();
                    count_sheet.ID = item.ID;
                    count_sheet.Stock_Name = item.Stock_Name;
                    count_sheet.Total_Item = m_db.tbl_Stock_Count_Item_Details.Where(a => a.tbl_Stock_Count_Details_ID == count_sheet.ID).ToList().Count;
                    count_sheet.Date_of_Creation = item.Date_of_Creation.ToString("dd MMM yyy");
                    if (item.User_Assigned_ID != 0)
                    {
                        string nameid = Convert.ToString(item.User_Assigned_ID);
                        var details = m_db.Users.Where(m => m.Id == nameid).FirstOrDefault();
                        if (details != null)
                        {
                            if (details.Name == null)
                            {
                                count_sheet.User_Assigned = " ";
                            }
                            else
                            {
                                count_sheet.User_Assigned = details.Name;
                            }
                        }

                    }
                    else
                    {
                        count_sheet.User_Assigned = " ";
                    }
                    lst_count_sheet.Add(count_sheet);

                }
                string value = form["command"];
                string sendOnMail = form["sendmail"];
                if (value == "Export" || sendOnMail == "Send On Mail")
                {
                    if (ddl_export != null)
                    {
                        bool mail = false;
                        if (sendOnMail != null) mail = true;
                        string EmailID = form["txt_email"];


                        DataTable header = new DataTable();
                        string colum = " ";
                        for (int i = 0; i < 6; i++)
                        {
                            header.Columns.Add(colum);
                            colum = colum + " ";
                        }
                        DataRow erow = header.NewRow();
                        erow[2] = " ";
                        header.Rows.Add(erow);
                        DataRow drow = header.NewRow();
                        drow[1] = "Sheet Name";
                        drow[2] = txtSheetName;
                        drow[4] = "Report Taken On";
                        drow[5] = DateTime.Now.ToString("dd MMM yyyy");
                        header.Rows.Add(drow);
                        DataRow brow = header.NewRow();
                        brow[1] = "Assigned User Name";
                        brow[2] = lst_AllEmployee.Find(a => a.Value == ddl_AssignedUsers.ToString()).Text;
                        brow[4] = "Report Taken By";
                        brow[5] = User.Identity.Name;
                        header.Rows.Add(brow);
                        DataRow eerow = header.NewRow();
                        eerow[2] = " ";
                        header.Rows.Add(eerow);

                        DataTable export_dt = cf.CreateTableStockSheet(lst_count_sheet);

                        int type = Convert.ToInt32(ddl_export);
                        if (export_dt.Rows.Count > 0)
                        {
                            int r = cf.Export("Stock Count Sheet Summary Report", header, export_dt, Response, type, mail, EmailID);
                            if (r == 3) ViewData["Message"] = DisplayMessage.ReportSentOnMail;
                        }
                        else ViewData["Message"] = DisplayMessage.NoRecord;

                    }
                    else ViewData["Message"] = DisplayMessage.SelectExport;
                }
            }
            catch (Exception ex)
            {
                ViewData["Message"] = DisplayMessage.ErrorMessage;
                writelog = new Writelog();
                writelog.write_exception_log(0, "ReportController", "StockCountSheetSummary", DateTime.Now, ex);
            }
            return View(lst_count_sheet);
        }
        public ActionResult StockCountSheetDetailed(FormCollection form, int? ddl_export, int? ddl_StockSheet)
        {
            View_Stock_Count_Details stock_sheet = new View_Stock_Count_Details();
            try
            {
                cf = new comman_function();
                ViewData["ExportList"] = cf.GetExportList();
                ViewData["StockSheetList"] = cf.StockSheetList();
               
                if (ddl_StockSheet != null && ddl_StockSheet != 0)
                {
                    var GetStockCountSheet = m_db.tbl_Stock_Count_Details.Where(a => a.ID == ddl_StockSheet).FirstOrDefault();
                    if (GetStockCountSheet != null)
                    {
                        stock_sheet.ID = GetStockCountSheet.ID;
                        stock_sheet.Stock_Name = GetStockCountSheet.Stock_Name;
                        stock_sheet.Remarks = GetStockCountSheet.Remarks;
                        stock_sheet.Date_of_Creation = GetStockCountSheet.Date_of_Creation.ToString("dd MMM yyy");
                        stock_sheet.User_Assigned = m_db.Users.Where(a => a.Id == GetStockCountSheet.User_Assigned_ID.ToString()).FirstOrDefault().Name;
                        stock_sheet.Stock_Sheet_Items = new List<Stock_Sheet_Items>();
                        var GetOrderItem = (from ob_stock_count_item in m_db.tbl_Stock_Count_Item_Details.Where(a => a.tbl_Stock_Count_Details_ID == stock_sheet.ID)
                                            join ob_Items in m_db.stock_details on ob_stock_count_item.Stock_Item_ID equals ob_Items.ID

                                            select new
                                            {
                                                ob_Items = ob_Items,
                                                ob_stock_count_item = ob_stock_count_item
                                            }).ToList();
                        foreach (var item in GetOrderItem)
                        {

                            Stock_Sheet_Items order_item = new Stock_Sheet_Items();
                            order_item.Item_Name = item.ob_Items.Item_Name;
                            order_item.Batch_No = item.ob_stock_count_item.Batch_No;
                            order_item.Serial_No = item.ob_stock_count_item.Serial_No;
                            order_item.Scan_Value = item.ob_stock_count_item.Scan_Value;
                            stock_sheet.Stock_Sheet_Items.Add(order_item);
                        }
                        string value = form["command"];
                        string sendOnMail = form["sendmail"];
                        if (value == "Export" || sendOnMail == "Send On Mail")
                        {
                            if (ddl_export != null)
                            {
                                bool mail = false;
                                if (sendOnMail != null) mail = true;
                                string EmailID = form["txt_email"];


                                DataTable header = new DataTable();
                                string colum = " ";
                                for (int i = 0; i < 6; i++)
                                {
                                    header.Columns.Add(colum);
                                    colum = colum + " ";
                                }
                                DataRow erow = header.NewRow();
                                erow[2] = " ";
                                header.Rows.Add(erow);
                                DataRow drow = header.NewRow();
                                drow[1] = "Stock Sheet Name";
                                drow[2] = stock_sheet.Stock_Name;
                                drow[4] = "Report Taken On";
                                drow[5] = DateTime.Now.ToString("dd MMM yyyy");
                                header.Rows.Add(drow);
                                DataRow brow = header.NewRow();
                                brow[1] = "User Assigned";
                                brow[2] = stock_sheet.User_Assigned;
                                brow[4] = "Report Taken By";
                                brow[5] = User.Identity.Name;
                                header.Rows.Add(brow);
                                DataRow pbrow = header.NewRow();
                                pbrow[1] = "Created On";
                                pbrow[2] = stock_sheet.Date_of_Creation;
                                header.Rows.Add(pbrow);
                                DataRow epbrow = header.NewRow();
                                epbrow[1] = "Remarks";
                                epbrow[2] = stock_sheet.Remarks;
                                header.Rows.Add(epbrow);

                                DataRow eerow = header.NewRow();
                                eerow[2] = " ";
                                header.Rows.Add(eerow);

                                DataTable export_dt = cf.CreateTableStockSheetItems(stock_sheet.Stock_Sheet_Items);

                                int type = Convert.ToInt32(ddl_export);
                                if (export_dt.Rows.Count > 0)
                                {
                                    int r = cf.Export("Stock Count Sheet Detailed Report", header, export_dt, Response, type, mail, EmailID);
                                    if (r == 3) ViewData["Message"] = DisplayMessage.ReportSentOnMail;
                                }
                                else ViewData["Message"] = DisplayMessage.NoRecord;

                            }
                            else ViewData["Message"] = DisplayMessage.SelectExport;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ViewData["Message"] = DisplayMessage.ErrorMessage;
                writelog = new Writelog();
                writelog.write_exception_log(0, "ReportController", "StockCountSheetDetailed", DateTime.Now, ex);
            }
            return View(stock_sheet);
        }
        #endregion
        #region take Stock  Mismatch Report
        public ActionResult TakeStockMismatch(FormCollection form, int? ddl_export, int? ddl_AssignedUsers, string txtSheetName, DateTime? txt_fromdate, DateTime? txt_todate)
        {
            List<view_missing_inventory> lst_view_missing = new List<view_missing_inventory>();
            try
            {
                cf = new comman_function();
                List<SelectListItem> lst_AllEmployee = cf.GetAllHHTEmployeeList();
                ViewData["AllEmployeeList"] = lst_AllEmployee;
                ViewData["ExportList"] = cf.GetExportList();

                var GetStockMissing = (from obj_missing in m_db.tbl_missing_inventory.Where(a=>a.Case_Status_ID==2)
                                       join obj_inventry in m_db.tbl_inventory on obj_missing.tbl_inventory_ID equals obj_inventry.ID
                                       join obj_stock in m_db.stock_details on obj_inventry.Item_ID equals obj_stock.ID
                                       join obj_stock_count in m_db.tbl_Stock_Count_Details on obj_missing.SO_StockCount_ID equals obj_stock_count.ID
                                       select new
                                        {
                                            obj_missing=obj_missing,
                                            obj_stock = obj_stock,
                                            obj_stock_count = obj_stock_count
                                        }).ToList();



                if (GetStockMissing != null && ddl_AssignedUsers != null && ddl_AssignedUsers != 0)
                    GetStockMissing = GetStockMissing.Where(a => a.obj_stock_count.User_Assigned_ID == ddl_AssignedUsers).ToList();
                if (GetStockMissing != null && txtSheetName != "" && txtSheetName != null)
                    GetStockMissing = GetStockMissing.Where(a => a.obj_stock_count.Stock_Name.ToLower().Contains(txtSheetName.ToLower())).ToList();
                if (GetStockMissing != null)
                {
                    if (txt_fromdate != null && txt_todate!=null)
                    {
                        GetStockMissing = GetStockMissing.Where(a => a.obj_missing.Reported_on.Date >= Convert.ToDateTime(txt_fromdate).Date && a.obj_missing.Reported_on.Date <= Convert.ToDateTime(txt_todate).Date).ToList();
                    }
                    else if (txt_fromdate != null)
                    {
                        GetStockMissing = GetStockMissing.Where(a => a.obj_missing.Reported_on.Date >= Convert.ToDateTime(txt_fromdate).Date).ToList();
                    }
                    else if (txt_todate != null)
                    {
                        GetStockMissing = GetStockMissing.Where(a => a.obj_missing.Reported_on.Date <= Convert.ToDateTime(txt_todate).Date).ToList();
                    }
                }
                
                foreach (var item in GetStockMissing)
                {
                    view_missing_inventory missing_item = new view_missing_inventory();
                    missing_item.ID = item.obj_missing.ID;
                    missing_item.Item_Name = item.obj_stock.Item_Name;
                    missing_item.Stock_Name = item.obj_stock_count.Stock_Name;
                    missing_item.System_Quantity = item.obj_missing.Actual_Quantity;
                    missing_item.Reported_Quantity = item.obj_missing.Reported_Quantity;
                    missing_item.Remarks = item.obj_missing.Remarks;
                    missing_item.Action_Taken = item.obj_missing.Action_Taken;
                    missing_item.Reported_on = item.obj_missing.Reported_on.ToString("dd MMM yyy");
                    if (item.obj_stock_count.User_Assigned_ID != 0)
                    {
                        string nameid = Convert.ToString(item.obj_stock_count.User_Assigned_ID);
                        var details = m_db.Users.Where(m => m.Id == nameid).FirstOrDefault();
                        if (details != null)
                        {
                            if (details.Name == null)
                            {
                                missing_item.User_Assigned = " ";
                            }
                            else
                            {
                                missing_item.User_Assigned = details.Name;
                            }
                        }

                    }
                    else
                    {
                        missing_item.User_Assigned = " ";
                    }
                    lst_view_missing.Add(missing_item);

                }
                string value = form["command"];
                string sendOnMail = form["sendmail"];
                if (value == "Export" || sendOnMail == "Send On Mail")
                {
                    if (ddl_export != null)
                    {
                        bool mail = false;
                        if (sendOnMail != null) mail = true;
                        string EmailID = form["txt_email"];


                        DataTable header = new DataTable();
                        string colum = " ";
                        for (int i = 0; i < 6; i++)
                        {
                            header.Columns.Add(colum);
                            colum = colum + " ";
                        }
                        DataRow erow = header.NewRow();
                        erow[2] = " ";
                        header.Rows.Add(erow);
                        DataRow drow = header.NewRow();
                        drow[1] = "Sheet Name";
                        drow[2] = txtSheetName;
                        drow[4] = "Report Taken On";
                        drow[5] = DateTime.Now.ToString("dd MMM yyyy");
                        header.Rows.Add(drow);
                        DataRow brow = header.NewRow();
                        brow[1] = "Assigned User Name";
                        brow[2] = lst_AllEmployee.Find(a => a.Value == ddl_AssignedUsers.ToString()).Text;
                        brow[4] = "Report Taken By";
                        brow[5] = User.Identity.Name;
                        header.Rows.Add(brow);
                        string fromDate = "-";
                        if (txt_fromdate != null)
                            fromDate = Convert.ToDateTime(txt_fromdate).ToString("dd MMM yyyy");
                        DataRow fbrow = header.NewRow();
                        fbrow[1] = "From Date";
                        fbrow[2] = fromDate;
                        header.Rows.Add(fbrow);
                        string ToDate = "-";
                        if (txt_todate != null)
                            ToDate = Convert.ToDateTime(txt_todate).ToString("dd MMM yyyy");
                        DataRow eerow = header.NewRow();
                        eerow[2] = " ";
                        header.Rows.Add(eerow);

                        DataTable export_dt = cf.CreateTableStockMismatch(lst_view_missing);

                        int type = Convert.ToInt32(ddl_export);
                        if (export_dt.Rows.Count > 0)
                        {
                            int r = cf.Export("Take Stock Mismatch Report", header, export_dt, Response, type, mail, EmailID);
                            if (r == 3) ViewData["Message"] = DisplayMessage.ReportSentOnMail;
                        }
                        else ViewData["Message"] = DisplayMessage.NoRecord;

                    }
                    else ViewData["Message"] = DisplayMessage.SelectExport;
                }
            }
            catch (Exception ex)
            {
                ViewData["Message"] = DisplayMessage.ErrorMessage;
                writelog = new Writelog();
                writelog.write_exception_log(0, "ReportController", "TakeStockMismatch", DateTime.Now, ex);
            }
            return View(lst_view_missing);
        }
        #endregion
        #region SO Discrepency Report
        public ActionResult SODiscrepencyReport(FormCollection form, int? ddl_export, int? ddl_AssignedUsers, string txtSheetName, DateTime? txt_fromdate, DateTime? txt_todate)
        {
            List<view_missing_inventory> lst_view_missing = new List<view_missing_inventory>();
            try
            {
                cf = new comman_function();
                List<SelectListItem> lst_AllEmployee = cf.GetAllHHTEmployeeList();
                ViewData["AllEmployeeList"] = lst_AllEmployee;
                ViewData["ExportList"] = cf.GetExportList();

                var GetStockMissing = (from obj_missing in m_db.tbl_missing_inventory.Where(a => a.Case_Status_ID == 1)
                                       join obj_so in m_db.Sales_Order_Details on obj_missing.SO_StockCount_ID equals obj_so.ID
                                       join obj_customer in m_db.Customer_Details on obj_so.Customer_ID equals obj_customer.ID
                                       join obj_so_item in m_db.Sales_Order_Item_Details on obj_missing.SO_StockCount_Item_DetailsID equals obj_so_item.ID
                                       join obj_stock in m_db.stock_details on obj_so_item.Item_ID equals obj_stock.ID
                                       select new
                                       {
                                           obj_missing = obj_missing,
                                           obj_stock = obj_stock,
                                           obj_so = obj_so,
                                           obj_customer = obj_customer
                                       }).ToList();



                if (GetStockMissing != null && ddl_AssignedUsers != null && ddl_AssignedUsers != 0)
                    GetStockMissing = GetStockMissing.Where(a => a.obj_so.Assigned_User_ID == ddl_AssignedUsers).ToList();
                if (GetStockMissing != null && txtSheetName != "" && txtSheetName != null)
                    GetStockMissing = GetStockMissing.Where(a => a.obj_so.SalesOrderNo.ToLower().Contains(txtSheetName.ToLower())).ToList();
                if (GetStockMissing != null)
                {
                    if (txt_fromdate != null && txt_todate != null)
                    {
                        GetStockMissing = GetStockMissing.Where(a => a.obj_missing.Reported_on.Date >= Convert.ToDateTime(txt_fromdate).Date && a.obj_missing.Reported_on.Date <= Convert.ToDateTime(txt_todate).Date).ToList();
                    }
                    else if (txt_fromdate != null)
                    {
                        GetStockMissing = GetStockMissing.Where(a => a.obj_missing.Reported_on.Date >= Convert.ToDateTime(txt_fromdate).Date).ToList();
                    }
                    else if (txt_todate != null)
                    {
                        GetStockMissing = GetStockMissing.Where(a => a.obj_missing.Reported_on.Date <= Convert.ToDateTime(txt_todate).Date).ToList();
                    }
                }

                foreach (var item in GetStockMissing)
                {
                    view_missing_inventory missing_item = new view_missing_inventory();
                    missing_item.ID = item.obj_missing.ID;
                    missing_item.Item_Name = item.obj_stock.Item_Name;
                    missing_item.Stock_Name = item.obj_so.SalesOrderNo;//so number
                    missing_item.Customer_Name = item.obj_customer.name;
                    missing_item.System_Quantity = item.obj_missing.Actual_Quantity;
                    missing_item.Reported_Quantity = item.obj_missing.Reported_Quantity;
                    missing_item.Remarks = item.obj_missing.Remarks;
                    missing_item.Action_Taken = item.obj_missing.Action_Taken;
                    missing_item.Reported_on = item.obj_missing.Reported_on.ToString("dd MMM yyy");
                    if (item.obj_so.Assigned_User_ID != 0)
                    {
                        string nameid = Convert.ToString(item.obj_so.Assigned_User_ID);
                        var details = m_db.Users.Where(m => m.Id == nameid).FirstOrDefault();
                        if (details != null)
                        {
                            if (details.Name == null)
                            {
                                missing_item.User_Assigned = " ";
                            }
                            else
                            {
                                missing_item.User_Assigned = details.Name;
                            }
                        }

                    }
                    else
                    {
                        missing_item.User_Assigned = " ";
                    }
                    lst_view_missing.Add(missing_item);

                }
                string value = form["command"];
                string sendOnMail = form["sendmail"];
                if (value == "Export" || sendOnMail == "Send On Mail")
                {
                    if (ddl_export != null)
                    {
                        bool mail = false;
                        if (sendOnMail != null) mail = true;
                        string EmailID = form["txt_email"];


                        DataTable header = new DataTable();
                        string colum = " ";
                        for (int i = 0; i < 6; i++)
                        {
                            header.Columns.Add(colum);
                            colum = colum + " ";
                        }
                        DataRow erow = header.NewRow();
                        erow[2] = " ";
                        header.Rows.Add(erow);
                        DataRow drow = header.NewRow();
                        drow[1] = "SO No.";
                        drow[2] = txtSheetName;
                        drow[4] = "Report Taken On";
                        drow[5] = DateTime.Now.ToString("dd MMM yyyy");
                        header.Rows.Add(drow);
                        DataRow brow = header.NewRow();
                        brow[1] = "Assigned User Name";
                        brow[2] = lst_AllEmployee.Find(a => a.Value == ddl_AssignedUsers.ToString()).Text;
                        brow[4] = "Report Taken By";
                        brow[5] = User.Identity.Name;
                        header.Rows.Add(brow);

                        string fromDate = "-";
                         if (txt_fromdate != null)
                             fromDate = Convert.ToDateTime(txt_fromdate).ToString("dd MMM yyyy");
                        DataRow fbrow = header.NewRow();
                        fbrow[1] = "From Date";
                        fbrow[2] = fromDate;
                        header.Rows.Add(fbrow);
                        string ToDate = "-";
                        if (txt_todate != null)
                            ToDate = Convert.ToDateTime(txt_todate).ToString("dd MMM yyyy");
                        DataRow tfbrow = header.NewRow();
                        tfbrow[1] = "To Date";
                        tfbrow[2] = ToDate;
                        header.Rows.Add(tfbrow);

                        DataRow eerow = header.NewRow();
                        eerow[2] = " ";
                        header.Rows.Add(eerow);

                        DataTable export_dt = cf.CreateTableDiscrepency(lst_view_missing);

                        int type = Convert.ToInt32(ddl_export);
                        if (export_dt.Rows.Count > 0)
                        {
                            int r = cf.Export("SO Discrepency Report", header, export_dt, Response, type, mail, EmailID);
                            if (r == 3) ViewData["Message"] = DisplayMessage.ReportSentOnMail;
                        }
                        else ViewData["Message"] = DisplayMessage.NoRecord;

                    }
                    else ViewData["Message"] = DisplayMessage.SelectExport;
                }
            }
            catch (Exception ex)
            {
                ViewData["Message"] = DisplayMessage.ErrorMessage;
                writelog = new Writelog();
                writelog.write_exception_log(0, "ReportController", "TakeStockMismatch", DateTime.Now, ex);
            }
            return View(lst_view_missing);
        }
        #endregion
    }
}