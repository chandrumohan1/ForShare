﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WDC.Models;

namespace WDC.Controllers
{
    public class UploadController : Controller
    {
        ApplicationDbContext m_db = new ApplicationDbContext();
        comman_function cf = new comman_function();
        private string Excel03ConString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Extended Properties='Excel 8.0;HDR={1}'";
        private string Excel07ConString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties='Excel 8.0;HDR={1}'";
        public ActionResult UploadInventry(HttpPostedFileBase file, FormCollection frm)
        {
            List<ShowMessage> list_count = new List<ShowMessage>();
            return View(list_count);
        }
        [HttpPost]
        public ActionResult UploadInventry(HttpPostedFileBase file)
        {
            List<ShowMessage> list_count = new List<ShowMessage>();
            try
            {
                if (file != null)
                {
                    if (file.ContentLength > 0)
                    {
                        string filePath = string.Concat(Path.GetFileNameWithoutExtension(file.FileName), DateTime.Now.ToString("yyyyMMddHHmmssfff"), Path.GetExtension(file.FileName)
            );
                         //Path.GetFileName(file.FileName);
                        string fileLocation = System.IO.Path.Combine(Server.MapPath("~/UploadExcel"), filePath);
                        if (System.IO.File.Exists(fileLocation))
                        {
                            System.IO.File.Delete(fileLocation);
                        }
                        //string _path = Path.Combine(Server.MapPath("~/UploadedFiles"), _FileName);
                        file.SaveAs(fileLocation);
                        string extension = Path.GetExtension(filePath);
                        string header = "Yes";
                        string connectionstring;
                        connectionstring = string.Empty;

                        switch (extension)
                        {
                            case ".xls": //Excel 97-03
                                connectionstring = string.Format(Excel03ConString, fileLocation, header);
                                break;

                            case ".xlsx": //Excel 07
                                connectionstring = string.Format(Excel07ConString, fileLocation, header);
                                break;
                        }
                        FillDataTableIN FillData = new FillDataTableIN();
                        FillData = cf.ConvertXSLXtoDataTableIN(connectionstring);

                        int a_stock = 0;
                        int u_stock = 0;
                        int a_vender = 0;
                        int u_vender = 0;
                        int a_venderItem = 0;
                        int u_venderItem = 0;

                       
                        bool pick_data = insert_into_asset_master_details(FillData, fileLocation, out a_stock, out u_stock, out a_vender, out u_vender, out a_venderItem, out u_venderItem);
                        if (pick_data)
                        {
                            int total_asset = (u_stock + u_stock);

                            list_count.Add(new ShowMessage() { Message = "Total Stock Added :" + a_stock });
                            list_count.Add(new ShowMessage() { Message = "--------------------------------------"});
                            //list_count.Add(new ShowMessage() { Message = "Total Stock Updated     " + u_stock});
                            //list_count.Add(new ShowMessage() { Message = "---------------------------------------"});
                            list_count.Add(new ShowMessage() { Message = "Total Vendor Added : " + a_vender});
                            list_count.Add(new ShowMessage() { Message = "---------------------------------------"});
                            list_count.Add(new ShowMessage() { Message = "Total Vendor Updated : " + u_vender});
                            list_count.Add(new ShowMessage() { Message = "---------------------------------------"});
                            list_count.Add(new ShowMessage() { Message = "Total Vendor Item Added : " + a_venderItem});
                            //list_count.Add(new ShowMessage() { Message = "---------------------------------------"});
                           // list_count.Add(new ShowMessage() { Message = "Total Vendor Item Updated  " + u_venderItem });
                            ViewBag.Message = "File Uploaded Successfully!!";
                        }
                        else
                        {
                           ViewBag.Message = "Excel has not been Successfully Uploaded !!!";
                        }

                    }
                    
                }
                return View(list_count);
            }
            catch
            {
                ViewBag.Message = "File upload failed!!";
                return View(list_count);
            } 
        }
        public bool insert_into_asset_master_details(FillDataTableIN dt, string getfileName,out int a_stock,out int u_stock,  out int a_vender, out int u_vender, out int a_venderItem,out int u_venderItem)
        {
            bool ret = true;
            a_vender = 0;
            u_vender = 0;
            a_venderItem = 0;
            u_venderItem = 0;
            a_stock = 0;
            u_stock = 0;
            if (dt != null)
            {

                try
                {
                    int ii = 0;
                    foreach (DataRow InventryRow in dt.inventry_tbl.Rows)
                    {
                        ii++;
                        if (ii < 4)
                            continue;
                        string Status = Convert.ToString(InventryRow[0]);
                        string item_no = Convert.ToString(InventryRow[1]);
                        string last_order_date = Convert.ToString(InventryRow[2]);
                        string item_name = Convert.ToString(InventryRow[3]);
                        string vendor = Convert.ToString(InventryRow[4]);
                        string location = Convert.ToString(InventryRow[5]);
                        string description = Convert.ToString(InventryRow[6]);
                        string costpre_item = Convert.ToString(InventryRow[7]);
                        string stock_quantity = Convert.ToString(InventryRow[8]);
                        string total_value = Convert.ToString(InventryRow[9]);
                        string reorder_level = Convert.ToString(InventryRow[10]);
                        string days_per_reorder = Convert.ToString(InventryRow[11]);
                        string item_reorder_quantity = Convert.ToString(InventryRow[12]);
                        string item_discontinued = Convert.ToString(InventryRow[13]);
                        string sub_location = "";
                        float ReorderLevel = 0;
                        if (reorder_level != "")
                            ReorderLevel = float.Parse(reorder_level);
                        if (location != "")
                        {
                            string[] loc = location.Split(',');
                            location = loc[0];
                            if (loc.Length > 1)
                                sub_location = loc[1];
                        }

                        if (string.IsNullOrEmpty(Convert.ToString(item_name)) && string.IsNullOrEmpty(Convert.ToString(item_no)))
                            break;
                        int StatusID = 1;
                        if (item_discontinued == "Yes")
                            StatusID = 4;
                        else StatusID = GetStockStatus(Status);
                        int stock_action;
                        int vendor_action;
                        int vendoeItem_action;
                        int StockID = GetStock(item_name, StatusID, item_no, stock_quantity, location, sub_location, ReorderLevel, "", costpre_item, out stock_action);
                        int VendorID = CreateVender(vendor, "NA", "NA", "NA", "NA", "NA", "NA", "NA", "NA", "NA", "NA", out vendor_action);
                        CreateVendorItem(VendorID, StockID, item_name, "0", "0", "", out vendoeItem_action);
                        if (stock_action == 1)
                            a_stock++;
                        //else u_stock++; stock can not update
                        if (vendor_action == 1)
                            a_vender++;
                        else
                            u_vender++;
                        if (vendoeItem_action == 1)
                            a_venderItem++;
                        else
                            u_venderItem++;
                    }
                    int vi = 0;
                    foreach (DataRow vendorRows in dt.vendor_tbl.Rows)
                    {
                        vi++;
                        if (vi < 5)
                            continue;
                        string Vendorname = Convert.ToString(vendorRows[0]);
                        string item_name = Convert.ToString(vendorRows[1]);
                        if (string.IsNullOrEmpty(Convert.ToString(Vendorname)) && string.IsNullOrEmpty(Convert.ToString(item_name)))
                            break;
                        string weblink = Convert.ToString(vendorRows[2]);
                        string Description = Convert.ToString(vendorRows[3]);
                        string cost = Convert.ToString(vendorRows[4]);
                        string leadtime = Convert.ToString(vendorRows[5]);
                        string contactname = Convert.ToString(vendorRows[6]);
                        string email = Convert.ToString(vendorRows[7]);
                        string phone = Convert.ToString(vendorRows[8]);
                        string fax = Convert.ToString(vendorRows[9]);
                        string address = Convert.ToString(vendorRows[10]);
                        string city = Convert.ToString(vendorRows[11]);
                        string state = Convert.ToString(vendorRows[12]);
                        string zip = Convert.ToString(vendorRows[13]);
                        string country = Convert.ToString(vendorRows[14]);
                        int stock_action;
                        int vendor_action;
                        int vendoeItem_action;
                        int VendorID = CreateVender(Vendorname, weblink, contactname, email, phone, fax, address, country, state, city, zip, out stock_action);
                        int StockID = GetStock(item_name, 1, "NA", "0", "", "", 0, Description,"0", out vendor_action);
                        CreateVendorItem(VendorID, StockID, item_name, cost, leadtime, Description, out vendoeItem_action);

                        if (stock_action == 1)
                            a_stock++;
                        //u_stock++; Stock Can update
                        if (vendor_action == 1)
                            a_vender++;
                        else
                            u_vender++;
                        if (vendoeItem_action == 1)
                            a_venderItem++;
                        else
                            u_venderItem++;
                    }
                    

                    try
                    {
                        Excel_Upload_Details ExcelUpload = new Excel_Upload_Details();
                        ExcelUpload.Total_Count = dt.inventry_tbl.Rows.Count;
                        ExcelUpload.File_Name = getfileName;
                        ExcelUpload.User_ID = 1;
                        ExcelUpload.Uploaded_On = DateTime.Now;
                        m_db.Excel_Upload_Details.Add(ExcelUpload);
                        m_db.SaveChanges();

                    }
                    catch (Exception e1)
                    {
                       
                    }
                   
                    
                }
                catch (Exception e)
                {

                   

                }
            }

            return ret;
        }
        private int GetCountry(string CountryName)
        {
            int CountryId=0;
            if (CountryName != "NA")
            {
                var GetCountry = m_db.tbl_Country.Where(a => a.countryname.ToLower().Contains(CountryName)).Where(a => a.parentid == 0).FirstOrDefault();
                if (GetCountry == null)
                {
                    tbl_Country country = new tbl_Country();
                    country.countryname = CountryName;
                    country.parentid = 0;
                    m_db.tbl_Country.Add(country);
                    m_db.SaveChanges();
                    CountryId = country.id;

                }
                else
                {
                    CountryId = GetCountry.id;
                }
            }
            return CountryId;
        }
        private int GetStockStatus(string status)
        {
            int StatusID = 0;
            var getStatus = m_db.m_stock_status.Where(a => a.Status.ToLower() == status.ToLower()).FirstOrDefault();
            if (getStatus != null)
            {
                StatusID = getStatus.ID;
            }
            else
            {
                m_stock_status stockstatus = new m_stock_status();
                stockstatus.Status = status;
                m_db.m_stock_status.Add(stockstatus);
                m_db.SaveChanges();
                StatusID = stockstatus.ID;
            }

            return StatusID;
        }
        private int GetLocation(string Location)
        {
            int LocID = 0;
            if (Location != "")
            {
                string chk_loc = Location.Replace(" ", String.Empty);
                var GetL = m_db.Location_Details.Where(a => a.Area.Replace(" ", String.Empty).ToLower() == chk_loc.ToLower()&&a.Parent_ID==0).FirstOrDefault();
                if (GetL != null)
                {
                    LocID = Convert.ToInt32(GetL.ID);
                }
                else
                {
                    Location_Details location = new Location_Details();
                    location.Area = Location;
                    location.Parent_ID = 0;
                    location.Date_of_Creation = DateTime.Now;
                    m_db.Location_Details.Add(location);
                    m_db.SaveChanges();
                    LocID = Convert.ToInt32(location.ID);
                }
            }
            return LocID; 
        }
        private int GetSubLocation(string SubLocation,int ParentID)
        {
            int LocID = 0;
            if (SubLocation != "")
            {
                string chk_loc = SubLocation.Replace(" ", String.Empty);
                var GetL = m_db.Location_Details.Where(a => a.Area.Replace(" ", String.Empty).ToLower() == chk_loc.ToLower()&&a.Parent_ID==ParentID).FirstOrDefault();
                if (GetL != null)
                {
                    LocID = Convert.ToInt32(GetL.ID);
                }
                else
                {
                    Location_Details location = new Location_Details();
                    location.Area = SubLocation;
                    location.Parent_ID = ParentID;
                    location.Date_of_Creation = DateTime.Now;
                    m_db.Location_Details.Add(location);
                    m_db.SaveChanges();
                    LocID = Convert.ToInt32(location.ID);
                }
            }
            return LocID;
        }
        private int GetStock(string ItemName, int Status, string Item_No, string Quantity, string Location, string subLocation, float ReOrdrLevel, string Description, string cost_per_item,out int Action)
        {
            int StockID = 0;
            Action = 0;
            stock_details stock = new stock_details();
            var getStock = m_db.stock_details.Where(a => a.Item_Name.ToLower() == ItemName.ToLower()).FirstOrDefault();
            if (getStock == null)
            {

                stock.Description = Description;
                stock.m_stock_status_id = Status;
                stock.Item_Name = ItemName;
                stock.Item_No = Item_No;
                stock.m_Stock_type_ID = 1;
                stock.m_Stock_Unit_ID = 1;
                //stock.Batch_No = "NA";
                //stock.Serial_No = "NA";
                if (Quantity!="")
                stock.Current_Stock = float.Parse(Quantity);
                int LocationID = GetLocation(Location);
                stock.Location_ID = LocationID;
                stock.Sub_Location_ID = GetSubLocation(subLocation, LocationID);
                stock.Reorder_Level = ReOrdrLevel;
                float Cost = 0;
                if (cost_per_item != "")
                    cost_per_item = cost_per_item.Replace('$', ' ');
                if (cost_per_item != "") Cost = float.Parse(cost_per_item);
                stock.Cost_per_Item = Cost;
                stock.Date_of_Creation = DateTime.Now;
                stock.Created_By = 1;
                m_db.stock_details.Add(stock);
                m_db.SaveChanges();
                StockID = Convert.ToInt32(stock.ID);
                Action = 1;
            }
            else
            {
                StockID = Convert.ToInt32(getStock.ID);
            }
            return StockID;
        }
        private int CreateVender(string Vendorname, string weblink, string contactname, string email, string phone, string fax, string address, string country, string state, string city, string zip, out int Action)
        {
            Action = 0;
            int VendorID = 0;
            var GetVendor = m_db.Vendor_Details.Where(a => a.Vendor_Name.ToLower() == Vendorname.ToLower()).FirstOrDefault();
            if (GetVendor != null)
            {
                if (weblink!="NA")
                GetVendor.Website_link = weblink;
                if (contactname != "NA")
                GetVendor.Contact_Person_Name = contactname;
                if (email != "NA")
                GetVendor.Email_ID = email;
                if (phone != "NA")
                GetVendor.Mobile = phone;
                if (fax != "NA")
                GetVendor.Fax = fax;
                if (address != "NA")
                GetVendor.Address = address;
                if (country != "NA")
                GetVendor.m_Country_ID = GetCountry(country);
                if (state != "NA")
                GetVendor.State = state;
                if (city != "NA")
                GetVendor.City = city;
                if (zip != "NA")
                GetVendor.ZIP = zip;
                m_db.Entry(GetVendor).State=EntityState.Modified;
                m_db.SaveChanges();
                VendorID =Convert.ToInt32(GetVendor.ID);
            }
            else
            {
                Vendor_Details Vendor = new Vendor_Details();
                Vendor.Vendor_Name = Vendorname;
                Vendor.Website_link = weblink;
                Vendor.Contact_Person_Name = contactname;
                if (email == "NA") email = Vendorname + "@a.c";
                Vendor.Email_ID = email;
                Vendor.Mobile = phone;
                Vendor.Fax = fax;
                Vendor.Address = address;
                Vendor.m_Country_ID = GetCountry(country);
                Vendor.State = state;
                Vendor.City = city;
                Vendor.ZIP = zip;
                Vendor.Created_By = 1;
                Vendor.Date_of_Creation = DateTime.Now;
                m_db.Vendor_Details.Add(Vendor);
                m_db.SaveChanges();
                VendorID =Convert.ToInt32(Vendor.ID);
                Action = 1;
            }
            return VendorID;
        }
        private int CreateVendorItem(int? VenderID, int StockID, string ItemName, string Cost, string LeadTime, string Description, out int Action)
        {
            Action = 0;
            int ItemID = 0;
            stock_details stock = new stock_details();
            var GetItem = m_db.Vendor_Products.Where(a => a.Product_ID == StockID).Where(a => a.Vendor_ID == VenderID).FirstOrDefault();
            if (GetItem == null)
            {
                Vendor_Products item = new Vendor_Products();
                item.Vendor_ID = Convert.ToInt32(VenderID);
                float cost = 0;
                int leadtime = 0;
                item.Product_ID = StockID;
                item.Item_No = "";
                if (Cost != "")
                    Cost = Cost.Replace('$', ' ');
                if (Cost != "") cost = float.Parse(Cost);
                item.Cost = cost;
                if (LeadTime != "") leadtime = Convert.ToInt32(leadtime);
                item.Lead_Time = leadtime;
                item.Description = Description;
                item.Date_of_Creation = DateTime.Now;
                m_db.Vendor_Products.Add(item);
                m_db.SaveChanges();
                ItemID = Convert.ToInt32(item.ID);
                Action = 1;
            }
            else
                ItemID = Convert.ToInt32(GetItem.ID);
            return ItemID;
        }
    }
   
}