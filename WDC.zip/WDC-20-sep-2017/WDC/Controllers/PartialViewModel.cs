﻿namespace WDC.Controllers
{
    internal class PartialViewModel
    {
        private object model;

        public PartialViewModel(object model)
        {
            this.model = model;
        }
    }
}