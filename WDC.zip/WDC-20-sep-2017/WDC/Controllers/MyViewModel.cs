﻿using System;

namespace WDC.Controllers
{
    internal class MyViewModel
    {
        public DateTime DateOfPurchase { get; set; }
    }
}