﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using WDC.Models;
using Microsoft.AspNet.Identity;

namespace WDC.Controllers
{
     [Authorize]
    public class StockController : Controller
    {
        ApplicationDbContext m_db = new ApplicationDbContext();
        comman_function cf = null;
        Writelog writelog = null;
        #region Stock
        // GET: Stock
        public ActionResult CreateStock(int? ID)
        {
            cf=new comman_function();
            ViewData["ListStockType"] = cf.GetStockType();
            ViewData["ListStockUnit"] = cf.GetStockUnit();
            ViewData["ListStockStatus"] = cf.GetStockStatus();
            ViewData["ListLocationList"] = cf.GetLocationList();
            
            if (ID != 0 && ID != null)
            {
                var getStock = m_db.stock_details.Where(a => a.ID == ID).FirstOrDefault();
                int LocationID = 0;
                if (getStock.Location_ID != null)
                    LocationID = Convert.ToInt32(getStock.Location_ID);
                ViewData["ListSubLocationList"] = cf.GetSubLocationList(LocationID);
                return View(getStock);

            }
            else
            {
                ViewData["ListSubLocationList"] = cf.GetSubLocationList(0);
            }
            return View();
        }
        public JsonResult GetSubLocation(int loc_id)
        {
            string result = "";
            if (loc_id != 0)
            {
                var SubLocation = m_db.Location_Details.Where(a => a.Parent_ID == loc_id).ToList();
                JavaScriptSerializer javaScriptSerializer = new JavaScriptSerializer();
                result = javaScriptSerializer.Serialize(SubLocation);
            }
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult CreateStock(stock_details stock)
        {
            int LocationID = 0;
            if (ModelState.IsValid)
            {
                var getStock = m_db.stock_details.Where(a => a.ID == stock.ID).FirstOrDefault();
                if (getStock == null)
                {
                    stock.Created_By = 1;
                    stock.Date_of_Creation = DateTime.Now;
                    m_db.stock_details.Add(stock);
                    m_db.SaveChanges();
                    ViewData["MessageID"] = 1;
                    ViewData["Message"] = DisplayMessage.StockCreated;
                }
                else
                {
                    getStock.Description = stock.Description;
                    getStock.m_stock_status_id = stock.m_stock_status_id;
                    getStock.Item_Name = stock.Item_Name;
                    getStock.Item_No = stock.Item_No;
                    getStock.m_Stock_type_ID = stock.m_Stock_type_ID;
                    getStock.m_Stock_Unit_ID = stock.m_Stock_Unit_ID;
                    //getStock.Batch_No = stock.Batch_No;
                    //getStock.Serial_No = stock.Serial_No;
                    getStock.Current_Stock = stock.Current_Stock;
                    getStock.Location_ID = stock.Location_ID;
                    getStock.Sub_Location_ID = stock.Sub_Location_ID;
                    getStock.Reorder_Level = stock.Reorder_Level;
                    getStock.Cost_per_Item = stock.Cost_per_Item;
                    m_db.Entry(getStock).State = EntityState.Modified;
                    m_db.SaveChanges();
                    ViewData["MessageID"] = 2;
                    ViewData["Message"] = DisplayMessage.StockUpdated;
                }
            }
            else
            {
                if (stock.Location_ID!=null)
                LocationID = Convert.ToInt32(stock.Location_ID);
            }
            cf = new comman_function();
            ViewData["ListStockType"] = cf.GetStockType();
            ViewData["ListStockUnit"] = cf.GetStockUnit();
            ViewData["ListStockStatus"] = cf.GetStockStatus();
            ViewData["ListLocationList"] = cf.GetLocationList();
            ViewData["ListSubLocationList"] = cf.GetSubLocationList(LocationID);
            return View(stock);
        }
        //public ActionResult ViewStock()
        //{
        //    cf = new comman_function();
        //    //ViewData["ListStockType"] = cf.GetStockType();
        //    //ViewData["ListStockUnit"] = cf.GetStockUnit();
        //    ViewData["ListStockStatus"] = cf.GetStockStatus();
        //    //ViewData["ListLocationList"] = cf.GetLocationList();
        //    //ViewData["ListLocationList"] = cf.GetLocationList();
        //    //ViewData["ListSubLocationList"] = cf.GetSubLocationList(LocationID);
        //     List<Viewstock_details> list = new List<Viewstock_details>();
        //     var getStock = (from obj_stock in m_db.stock_details
        //                     join obj_type in m_db.m_Stock_Type on obj_stock.m_Stock_type_ID equals obj_type.ID
        //                     join obj_unit in m_db.m_Stock_Unit on obj_stock.m_Stock_Unit_ID equals obj_unit.ID
        //                     join obj_status in m_db.m_stock_status on obj_stock.m_stock_status_id equals obj_status.ID
        //                     select new {
        //                         obj_stock = obj_stock,
        //                         obj_type = obj_type,
        //                         obj_unit = obj_unit,
        //                         obj_status = obj_status
        //                     }).ToList();


        //     foreach(var item in getStock)
        //     {
        //         Viewstock_details ViewStock = new Viewstock_details();
        //         ViewStock.ID = item.obj_stock.ID;
        //         ViewStock.Description = item.obj_stock.Description;
        //         ViewStock.Status = item.obj_status.Status;
        //         ViewStock.Item_Name = item.obj_stock.Item_Name;
        //         ViewStock.Item_No = item.obj_stock.Item_No;
        //         ViewStock.Stock_type = item.obj_type.Stock_Type;
        //         ViewStock.Stock_Unit = item.obj_unit.Unit;
        //         string Location = "";//item.obj_stock.Location;
        //        // if (item.obj_stock.Sub_Location != "")
        //            // Location += "," + item.obj_stock.Sub_Location;
        //         ViewStock.Location = Location;
        //         list.Add(ViewStock);
        //     }
            
        //     return View(list);
        // }



        public ActionResult ViewStock(string txtItemNo, int? ddl_statuslist, int? ddl_locationlist, int? ddl_Sublocationlist)
        {
            int LocationID = 0;
            cf = new comman_function();
            ViewData["ListStockStatus"] = cf.GetStockStatus();
            ViewData["ListLocationList"] = cf.GetLocationList();
            ViewData["ListSubLocationList"] = cf.GetSubLocationList(LocationID);
            List<Viewstock_details> list = new List<Viewstock_details>();
            var getStock = (from obj_stock in m_db.stock_details
                            join obj_type in m_db.m_Stock_Type on obj_stock.m_Stock_type_ID equals obj_type.ID
                            join obj_location in m_db.Location_Details on obj_stock.Location_ID equals obj_location.ID
                            into loc
                            from obloc in loc.DefaultIfEmpty()
                            join obj_sublocation in m_db.Location_Details on obj_stock.Sub_Location_ID equals obj_sublocation.ID into sloc
                            from subloc in sloc.DefaultIfEmpty()
                            join obj_status in m_db.m_stock_status on obj_stock.m_stock_status_id equals obj_status.ID
                            select new
                            {
                                obj_stock = obj_stock,
                                obj_type = obj_type,
                                obj_location = obloc,
                                obj_sublocation = subloc,
                                obj_status = obj_status
                            }).ToList();

            if (getStock != null)
             {
                 if (ddl_statuslist != null && ddl_statuslist != 0)
                 {
                     getStock = getStock.Where(a => a.obj_stock.m_stock_status_id == ddl_statuslist).ToList();
                 }
             }
            if (getStock != null)
            {
                if (ddl_locationlist != null && ddl_locationlist != 0)
                {
                    getStock = getStock.Where(a => a.obj_stock.Location_ID == ddl_locationlist).ToList();
                }
            }
            if (getStock != null)
            {
                if (ddl_Sublocationlist != null && ddl_Sublocationlist != 0)
                {
                    getStock = getStock.Where(a => a.obj_stock.Sub_Location_ID == ddl_Sublocationlist).ToList();
                }
            }
            if (getStock != null)
            {
                if (txtItemNo != null && txtItemNo != "")
                {
                    getStock = getStock.Where(a => a.obj_stock.Item_No.Contains(txtItemNo)).ToList();
                }
            }
            var GetBarcode = m_db.m_barcode_setting.Where(a => a.m_Status_ID == 1).FirstOrDefault();

            
           
            foreach (var item in getStock)
            {
                Viewstock_details ViewStock = new Viewstock_details();
                string barcodeString = "No";
                string field1 = "NA";
                string field2 = "NA";
                string field3 = "NA";
                var F1 = item.obj_stock.GetType().GetProperty(GetBarcode.Firest_Field).GetValue(item.obj_stock, null);
                if (F1 != null && F1 != "") field1 = F1.ToString();
                if (GetBarcode.Firest_Field.Contains("Date"))
                {
                    DateTime date = Convert.ToDateTime(field1);
                    field1 = date.ToString("ddMMyyyy");
                }
                var F2 = item.obj_stock.GetType().GetProperty(GetBarcode.Second_Field).GetValue(item.obj_stock, null);
                if (F2 != null && F2 != "") field2 = F2.ToString();
                if (GetBarcode.Second_Field.Contains("Date"))
                {
                    if (field2 != "NA")
                    {
                        DateTime date = Convert.ToDateTime(field2);
                        field2 = date.ToString("ddMMyyyy");
                    }
                }
                var F3 = item.obj_stock.GetType().GetProperty(GetBarcode.Third_Field).GetValue(item.obj_stock, null);
                if (F3 != null && F3 != "") field3 = F3.ToString();
                if (GetBarcode.Third_Field.Contains("Date"))
                {
                    if (field3 != "NA")
                    {
                        DateTime date = Convert.ToDateTime(field3);
                        field3 = date.ToString("ddMMyyyy");
                    }

                }
                barcodeString = GetBarcode.Prefix + " " + field1 + " " + field2 + " " + field3;
                ViewStock.barcodeImage = barcodeString;
                ViewStock.ID = item.obj_stock.ID;
                ViewStock.Description = item.obj_stock.Description;
                ViewStock.Status = item.obj_status.Status;
                ViewStock.Item_Name = item.obj_stock.Item_Name;
                ViewStock.Item_No = item.obj_stock.Item_No;
                ViewStock.Stock_type = item.obj_type.Stock_Type;
                if (item.obj_location != null)
                {
                    ViewStock.Location = item.obj_location.Area;
                    if (item.obj_sublocation != null)
                    {
                        ViewStock.Location = item.obj_location.Area + "/" + item.obj_sublocation.Area;
                    }
                }
                
                //string Location = "";//item.obj_stock.Location;
                // if (item.obj_stock.Sub_Location != "")
                // Location += "," + item.obj_stock.Sub_Location;
                
                list.Add(ViewStock);
            }

            return View(list);
        }


        public JsonResult DeleteStock(int id)
        {
            RetMessage message = new RetMessage();
            var getStock = m_db.stock_details.Where(a => a.ID == id).FirstOrDefault();
            if (getStock!=null)
            {
                m_db.stock_details.Remove(getStock);
                m_db.SaveChanges();
                message.ID = 1;
                message.Message = DisplayMessage.StockDeleted;
            }
            return Json(message, JsonRequestBehavior.AllowGet);

        }
        #endregion
        #region Reorder Level
        public ActionResult ReorderLevel()
        {
            List<Viewstock_details> list = new List<Viewstock_details>();
            var getStock = (from obj_stock in m_db.stock_details.Where(a => a.m_stock_status_id != 4)
                            join obj_type in m_db.m_Stock_Type on obj_stock.m_Stock_type_ID equals obj_type.ID
                            join obj_unit in m_db.m_Stock_Unit on obj_stock.m_Stock_Unit_ID equals obj_unit.ID
                            join obj_status in m_db.m_stock_status on obj_stock.m_stock_status_id equals obj_status.ID
                            select new
                            {
                                obj_stock = obj_stock,
                                obj_type = obj_type,
                                obj_unit = obj_unit,
                                obj_status = obj_status
                            }).ToList();


            foreach (var item in getStock)
            {
                Viewstock_details ViewStock = new Viewstock_details();
                ViewStock.ID = item.obj_stock.ID;
                ViewStock.Description = item.obj_stock.Description;
                ViewStock.Status = item.obj_status.Status;
                ViewStock.Item_Name = item.obj_stock.Item_Name;
                ViewStock.Item_No = item.obj_stock.Item_No;
                ViewStock.Stock_type = item.obj_type.Stock_Type;
                ViewStock.Stock_Unit = item.obj_unit.Unit;
                ViewStock.Reorder_Level = item.obj_stock.Reorder_Level;
                ViewStock.Current_Stock = item.obj_stock.Current_Stock;
                
                if (ViewStock.Reorder_Level >= ViewStock.Current_Stock)
                list.Add(ViewStock);
            }
            return View(list);
        }
        #endregion
        #region TakeStock
        public ActionResult TakeStock(FormCollection frm, int? ddl_Location, int? ddl_Sub_Location, string txt_item_no, string txt_item_name)
        {
            string Command = frm["command"];
            
            cf = new comman_function();
            ViewData["ListLocationList"] = cf.GetLocationList();
            int LocationID = 0;
            ViewData["ListSubLocationList"] = cf.GetSubLocationList(LocationID);
            List<Viewstock_details> list = new List<Viewstock_details>();
            if (Command == "Search")
            {
                if (ddl_Location != null || ddl_Sub_Location != null || txt_item_no != "" || txt_item_name != "")
                {
                    var getStock = (from obj_stock in m_db.stock_details.Where(a => a.m_stock_status_id != 4)
                                    join obj_type in m_db.m_Stock_Type on obj_stock.m_Stock_type_ID equals obj_type.ID
                                    join obj_unit in m_db.m_Stock_Unit on obj_stock.m_Stock_Unit_ID equals obj_unit.ID
                                    join obj_status in m_db.m_stock_status on obj_stock.m_stock_status_id equals obj_status.ID
                                    select new
                                    {
                                        obj_stock = obj_stock,
                                        obj_type = obj_type,
                                        obj_unit = obj_unit,
                                        obj_status = obj_status
                                    }).ToList();
                    if (txt_item_no != "")
                        getStock = getStock.Where(a => a.obj_stock.Item_No.ToLower().Contains(txt_item_no.ToLower())).ToList();
                    if (txt_item_name != "")
                        getStock = getStock.Where(a => a.obj_stock.Item_Name.ToLower().Contains(txt_item_name.ToLower())).ToList();
                    if (ddl_Location != null && ddl_Location!=0)
                        getStock = getStock.Where(a => a.obj_stock.Location_ID == ddl_Location).ToList();
                    if (ddl_Sub_Location != null && ddl_Sub_Location != 0)
                        getStock = getStock.Where(a => a.obj_stock.Sub_Location_ID == ddl_Sub_Location).ToList();

                    foreach (var item in getStock)
                    {
                        Viewstock_details ViewStock = new Viewstock_details();
                        ViewStock.ID = item.obj_stock.ID;
                        ViewStock.Description = item.obj_stock.Description;
                        ViewStock.Status = item.obj_status.Status;
                        ViewStock.Item_Name = item.obj_stock.Item_Name;
                        ViewStock.Item_No = item.obj_stock.Item_No;
                        ViewStock.Stock_type = item.obj_type.Stock_Type;
                        ViewStock.Stock_Unit = item.obj_unit.Unit;
                        ViewStock.Reorder_Level = item.obj_stock.Reorder_Level;
                        ViewStock.Current_Stock = item.obj_stock.Current_Stock;
                        list.Add(ViewStock);
                    }
                }
                else
                {
                    ViewData["Message"] = "Please select atleast one parameter!";
                }
            }
            return View(list);
        }

        public JsonResult ActionStock(float quantity,int type,int id)
        {
            RetMessage message = new RetMessage();
            try
            {
                var GetStock = m_db.stock_details.Where(a => a.ID == id).FirstOrDefault();
                if (GetStock != null)
                {
                    Stock_History history = new Stock_History();
                    if (type == 1)
                    {
                        history.Action = "Add Quantity :+" + quantity;
                        GetStock.Current_Stock = GetStock.Current_Stock + quantity;
                    }
                    else
                    {
                        history.Action = "subtract Quantity:-" + quantity;
                        GetStock.Current_Stock = GetStock.Current_Stock - quantity;
                    }
                    
                    history.m_Source_ID = 1;
                    history.Stock_ID = id;
                    history.UserID = Convert.ToInt32(User.Identity.GetUserId());
                    
                    history.Date_of_Creation = DateTime.Now;
                    m_db.Stock_History.Add(history);
                    m_db.SaveChanges();
                    message.ID = 1;
                    message.Message = DisplayMessage.StockUpdated;
                }
            }
            catch (Exception ex)
            {
                message.ID = 0;
                message.Message = "Error";
                writelog = new Writelog();
                writelog.write_exception_log(0, "StockController", "ActionStock", DateTime.Now, ex);
            }
            return Json(message, JsonRequestBehavior.AllowGet);
        }
        #endregion

         //Search by Status
        //public ActionResult ViewStatusStock(int ddl_statuslist)
        //{
        //    cf = new comman_function();
        //    List<Viewstock_details> list = new List<Viewstock_details>();
        //    var getStock = (from obj_stock in m_db.stock_details
        //                    join obj_type in m_db.m_Stock_Type on obj_stock.m_Stock_type_ID equals obj_type.ID
        //                    join obj_unit in m_db.m_Stock_Unit on obj_stock.m_Stock_Unit_ID equals obj_unit.ID
        //                    join obj_status in m_db.m_stock_status on obj_stock.m_stock_status_id equals obj_status.ID
        //                    select new
        //                    {
        //                        obj_stock = obj_stock,
        //                        obj_type = obj_type,
        //                        obj_unit = obj_unit,
        //                        obj_status = obj_status
        //                    }).ToList();

        //    if (getStock != null)
        //    {
        //        if (ddl_statuslist != null && ddl_statuslist != 0)
        //        {
        //            getStock = getStock.Where(a => a.obj_stock.m_stock_status_id == ddl_statuslist).ToList();
        //        }
        //    }
            
        //    foreach (var item in getStock)
        //    {
        //        Viewstock_details ViewStock = new Viewstock_details();
        //        ViewStock.ID = item.obj_stock.ID;
        //        ViewStock.Description = item.obj_stock.Description;
        //        ViewStock.Status = item.obj_status.Status;
        //        ViewStock.Item_Name = item.obj_stock.Item_Name;
        //        ViewStock.Item_No = item.obj_stock.Item_No;
        //        ViewStock.Stock_type = item.obj_type.Stock_Type;
        //        ViewStock.Stock_Unit = item.obj_unit.Unit;
        //        string Location = "";//item.obj_stock.Location;
        //        // if (item.obj_stock.Sub_Location != "")
        //        // Location += "," + item.obj_stock.Sub_Location;
        //        ViewStock.Location = Location;
        //        list.Add(ViewStock);
        //    }

        //    return View(list);
        //}
    }
}