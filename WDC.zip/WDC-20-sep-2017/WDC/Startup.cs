﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(WDC.Startup))]
namespace WDC
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
