﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WDC.Models;
using Newtonsoft.Json;
using System.Data;
using System.Web.UI.WebControls;
using System.IO;
using System.Web.UI;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using WDC.Controllers;


namespace WDC.Models
{
    public class IDAtomationBarCode
    {
        public static string BarcodeImageGenerator(string Code)
        {
            byte[] BarCode;
            string BarCodeImage = "";
            if (Code != null)
            {
                //Read in the parameters
                //GenerateBarcodeImage.aspx?d=038000356216&h=150&w=300&bc=&fc=000000&t=Code 128&il=False&if=PNG&align=c
                string strData = Code; //System.Web.HttpContext.Current.Request.QueryString["d"];
                int imageHeight = 80; //Convert.ToInt32(System.Web.HttpContext.Current.Request.QueryString["h"]);
                int imageWidth = 400; //Convert.ToInt32(System.Web.HttpContext.Current.Request.QueryString["w"]);
                string Forecolor = "000000";// System.Web.HttpContext.Current.Request.QueryString["fc"];
                string Backcolor = ""; //System.Web.HttpContext.Current.Request.QueryString["bc"];
               
                string strImageFormat = "png";// System.Web.HttpContext.Current.Request.QueryString["if"].ToLower().Trim();
                string strAlignment = "c";// System.Web.HttpContext.Current.Request.QueryString["align"].ToLower().Trim();

                BarcodeLib.TYPE type = BarcodeLib.TYPE.UNSPECIFIED;

                string str = "Code 128";
                switch (str) //(System.Web.HttpContext.Current.Request.QueryString["t"].Trim())
                {

                    case "UPC-A": type = BarcodeLib.TYPE.UPCA; break;
                    case "UPC-E": type = BarcodeLib.TYPE.UPCE; break;
                    case "UPC 2 Digit Ext": type = BarcodeLib.TYPE.UPC_SUPPLEMENTAL_2DIGIT; break;
                    case "UPC 5 Digit Ext": type = BarcodeLib.TYPE.UPC_SUPPLEMENTAL_5DIGIT; break;
                    case "EAN-13": type = BarcodeLib.TYPE.EAN13; break;
                    case "JAN-13": type = BarcodeLib.TYPE.JAN13; break;
                    case "EAN-8": type = BarcodeLib.TYPE.EAN8; break;
                    case "ITF-14": type = BarcodeLib.TYPE.ITF14; break;
                    case "Codabar": type = BarcodeLib.TYPE.Codabar; break;
                    case "PostNet": type = BarcodeLib.TYPE.PostNet; break;
                    case "Bookland-ISBN": type = BarcodeLib.TYPE.BOOKLAND; break;
                    case "Code 11": type = BarcodeLib.TYPE.CODE11; break;
                    case "Code 39": type = BarcodeLib.TYPE.CODE39; break;
                    case "Code 39 Extended": type = BarcodeLib.TYPE.CODE39Extended; break;
                    case "Code 93": type = BarcodeLib.TYPE.CODE93; break;
                    case "LOGMARS": type = BarcodeLib.TYPE.LOGMARS; break;
                    case "MSI": type = BarcodeLib.TYPE.MSI_Mod10; break;
                    case "Interleaved 2 of 5": type = BarcodeLib.TYPE.Interleaved2of5; break;
                    case "Standard 2 of 5": type = BarcodeLib.TYPE.Standard2of5; break;
                    case "Code 128": type = BarcodeLib.TYPE.CODE128; break;
                    case "Code 128-A": type = BarcodeLib.TYPE.CODE128A; break;
                    case "Code 128-B": type = BarcodeLib.TYPE.CODE128B; break;
                    case "Code 128-C": type = BarcodeLib.TYPE.CODE128C; break;
                    case "Telepen": type = BarcodeLib.TYPE.TELEPEN; break;
                    case "FIM (Facing Identification Mark)": type = BarcodeLib.TYPE.FIM; break;
                    case "Pharmacode": type = BarcodeLib.TYPE.PHARMACODE; break;
                    default: break;
                }//switch

                System.Drawing.Image barcodeImage = null;
                try
                {
                    BarcodeLib.Barcode b = new BarcodeLib.Barcode();
                    if (type != BarcodeLib.TYPE.UNSPECIFIED)
                    {
                        // b.IncludeLabel = bIncludeLabel;
                        b.IncludeLabel = true;

                        //alignment
                        switch (strAlignment.ToLower().Trim())
                        {
                            case "c": b.Alignment = BarcodeLib.AlignmentPositions.CENTER;
                                break;
                            case "r": b.Alignment = BarcodeLib.AlignmentPositions.RIGHT;
                                break;
                            case "l": b.Alignment = BarcodeLib.AlignmentPositions.LEFT;
                                break;
                            default: b.Alignment = BarcodeLib.AlignmentPositions.CENTER;
                                break;
                        }//switch

                        if (Forecolor.Trim() == "" && Forecolor.Trim().Length != 6)
                            Forecolor = "000000";
                        if (Backcolor.Trim() == "" && Backcolor.Trim().Length != 6)
                            Backcolor = "FFFFFF";


                        // var d = @"data:image/gif;base64," + Convert.ToBase64String(File.ReadAllBytes(Server.MapPath(@"/images/your_image.gif")));

                        //===== Encoding performed here =====

                        barcodeImage = b.Encode(type, strData.Trim(), System.Drawing.ColorTranslator.FromHtml("#" + Forecolor), System.Drawing.ColorTranslator.FromHtml("#" + Backcolor), imageWidth, imageHeight);
                        //===================================

                        //===== Static Encoding performed here =====
                        //barcodeImage = BarcodeLib.Barcode.DoEncode(type, this.txtData.Text.Trim(), this.chkGenerateLabel.Checked, this.btnForeColor.BackColor, this.btnBackColor.BackColor);
                        //==========================================


                        // var d = @"data:image/gif;base64," + Convert.ToBase64String(File.ReadAllBytes(Server.MapPath(@"/images/your_image.gif")));

                        // Response.ContentType = "image/" + strImageFormat;
                        System.IO.MemoryStream MemStream = new System.IO.MemoryStream();

                        switch (strImageFormat)
                        {
                            case "gif": barcodeImage.Save(MemStream, ImageFormat.Gif); break;
                            case "jpeg": barcodeImage.Save(MemStream, ImageFormat.Jpeg); break;
                            case "png": barcodeImage.Save(MemStream, ImageFormat.Png); break;
                            case "bmp": barcodeImage.Save(MemStream, ImageFormat.Bmp); break;
                            case "tiff": barcodeImage.Save(MemStream, ImageFormat.Tiff); break;
                            default: break;
                        }//switch


                        BarCode = MemStream.GetBuffer();
                        // BarCodeImage = BarCode != null ? "data:image/png;base64," + Convert.ToBase64String((byte[])BarCode) : "";
                        BarCodeImage = BarCode != null ? "" + Convert.ToBase64String((byte[])BarCode) : "";

                        // string path = Convert.ToString(HttpContext.Current.Server.MapPath(@"~/ImageFolder/" + strData));

                        System.Drawing.Image image = SaveByteArrayAsImage("setpath", BarCodeImage);
                        BarCodeImage = MergeImage(image, strData);
                        // MemStream.WriteTo(Response.OutputStream);


                    }//if
                }//try
                catch (Exception ex)
                {
                    //TODO: find a way to return this to display the encoding error message
                }//catch
                finally
                {
                    if (barcodeImage != null)
                    {
                        //Clean up / Dispose...
                        barcodeImage.Dispose();
                    }
                }//finally
            }//if
            return BarCodeImage;

        }






        private static System.Drawing.Image SaveByteArrayAsImage(string fullOutputPath, string base64String)
        {
            byte[] bytes = Convert.FromBase64String(base64String);

            System.Drawing.Image image;
            using (MemoryStream ms = new MemoryStream(bytes))
            {
                image = System.Drawing.Image.FromStream(ms);
            }

            // image.Save(fullOutputPath, System.Drawing.Imaging.ImageFormat.Png);

            return image;
        }







        public static string MergeImage(System.Drawing.Image bar_img, string str_data)
        {
            System.Drawing.Image oracle_image;
            try
            {
                //IBS Logo
                string path = Convert.ToString(HttpContext.Current.Server.MapPath(@"~/images/check.png"));
                oracle_image = System.Drawing.Image.FromFile(path);

            }
            catch (Exception ex)
            {
                return null;
            }

            System.Drawing.Image sony_image;
            try
            {
                //client logo
                string get_path = Convert.ToString(HttpContext.Current.Server.MapPath(@"~/images/check.png"));
                sony_image = System.Drawing.Image.FromFile(get_path);
            }
            catch (Exception ex)
            {
                return null;
            }
            // Bitmap bt = MergeTwoImages(bar_img, oracle_image, sony_image);
            string bt = MergeTwoImages(bar_img, oracle_image, sony_image);
            
            return bt;
        }

        //public static Bitmap MergeTwoImages(System.Drawing.Image firstImage, System.Drawing.Image secondImage, System.Drawing.Image thirdImage)
        public static string MergeTwoImages(System.Drawing.Image firstImage, System.Drawing.Image secondImage, System.Drawing.Image thirdImage)
        {


            int outputImageWidth = firstImage.Width > secondImage.Width ? firstImage.Width : secondImage.Width;
            //outputImageWidth = outputImageWidth > thirdImage.Width ? outputImageWidth : thirdImage.Width;
            int outputImageHeight = firstImage.Height + secondImage.Height + 1;// +thirdImage.Height + 1;

            outputImageWidth = firstImage.Width + secondImage.Width + thirdImage.Width;

            int heightfactor = thirdImage.Height;
            if (secondImage.Height > thirdImage.Height)
                heightfactor = secondImage.Height;

            outputImageHeight = firstImage.Height + heightfactor;

            Bitmap outputImage = new Bitmap(firstImage.Width, firstImage.Height, System.Drawing.Imaging.PixelFormat.Format32bppArgb);//.Format32bppArgb);




            using (Graphics graphics = Graphics.FromImage(outputImage))
            {
                graphics.Clear(Color.White);
                /* graphics.DrawImage(firstImage, new Rectangle(new Point(), firstImage.Size),
                     new Rectangle(new Point(), firstImage.Size), GraphicsUnit.Pixel);
                 graphics.DrawImage(secondImage, new Rectangle(new Point(0, firstImage.Height + 1), secondImage.Size),
                     new Rectangle(new Point(), secondImage.Size), GraphicsUnit.Pixel);*/
                graphics.DrawImage(firstImage, new Rectangle(new Point(secondImage.Width, 0), firstImage.Size),
                   new Rectangle(new Point(), firstImage.Size), GraphicsUnit.Pixel);
                graphics.DrawImage(firstImage, 0, 0, outputImage.Width, outputImage.Height);
                //graphics.DrawImage(secondImage, new Rectangle(new Point(0, firstImage.Height + 1), secondImage.Size),
                //    new Rectangle(new Point(), secondImage.Size), GraphicsUnit.Pixel);
                //graphics.DrawImage(thirdImage, new Rectangle(new Point(firstImage.Width + secondImage.Width, firstImage.Height), thirdImage.Size),
                //  new Rectangle(new Point(), thirdImage.Size), GraphicsUnit.Pixel);
                //graphics.DrawImage(fourtbackgroundImage, new Rectangle(new Point(1, fourtbackgroundImage.Height + 1), fourtbackgroundImage.Size),
                // new Rectangle(new Point(), fourtbackgroundImage.Size), GraphicsUnit.Pixel);
            }
            byte[] BarCode;
            string BarCodeImage;
            using (MemoryStream Mmst = new MemoryStream())
            {
                outputImage.Save(Mmst, ImageFormat.Jpeg);
                BarCode = Mmst.GetBuffer();
                BarCodeImage = BarCode != null ? "data:image/jpg;base64," + Convert.ToBase64String((byte[])BarCode) : "";
                //return BarCodeImage;
            }
            return BarCodeImage;
        }
        
    }
}