﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace WDC.Models
{
    public class RetMessage
    {
        public int ID { get; set; }
        public string Message { get; set; }
    }
    public class m_Email_Setting
    {
        public int ID { get; set; }
        [Required(ErrorMessage = "Enter SMPT Server !")]
        public string SMPTServer { get; set; }
        [Required(ErrorMessage = "Enter SMPT Port!")]
        public string SMPTPort { get; set; }
        [Required(ErrorMessage = "Enter SMPT User Name")]
        public string UserName { get; set; }
        [Required(ErrorMessage = "Enter SMPT Password !")]
        public string Password { get; set; }
        [Display(Name = "Confirm new password")]
        [Compare("Password", ErrorMessage = "The SMPT password and confirmation SMPT password do not match.")]
        public string ConfirmPassword { get; set; }
        public bool SSL { get; set; }
        public int m_Status_ID { get; set; }
        public DateTime Date_of_Creation { get; set; }
    }
   
    public class m_barcode_setting
    {
        public int ID { get; set; }
        public string Prefix { get; set; }
        public string Firest_Field { get; set; }
        public string Second_Field { get; set; }
        public string Third_Field { get; set; }
        public int m_Status_ID { get; set; }
        public DateTime Date_of_Creation { get; set; }
    }

    public class UserProfile
    {
        public string Id { get; set; }
        public string UserName { get; set; }
        [Required(ErrorMessage = "Enter Employee Email !")]
        [EmailAddress]
        public string Email { get; set; }
        [Required(ErrorMessage = "Enter Employee Name !")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Enter Employee Code !")]
        public string Code { get; set; }
        public string Password { get; set; }
        public int? Is_for_Mobile_Device { get; set; }
        public int? Is_Active { get; set; }
        public string Photo { get; set; }
    }
    public class tbl_Country
    {
        public int id { get; set; }
        public string countryname { get; set; }
        public int parentid { get; set; }
    }
    public class m_stock_status
    {
        public int ID { get; set; }
        public string Status { get; set; }
        public int m_status_id { get; set; }
    }
    public class stock_details
    {
        public int? ID { get; set; }
        [Required(ErrorMessage="Enter Stock Item No.!")]
        public string Item_No { get; set; }
        [Required(ErrorMessage = "Enter Stock Item Name!")]
        public string Item_Name { get; set; }
        public string Description { get; set; }
        [Required(ErrorMessage = "Select Stock Type!")]
        public int m_Stock_type_ID { get; set; }
        public int? Location_ID { get; set; }
        public int? Sub_Location_ID { get; set; }
        [Required(ErrorMessage = "Select Stock Unit!")]
        public int m_Stock_Unit_ID { get; set; }
        [Required(ErrorMessage = "Select Stock Status!")]
        public int m_stock_status_id { get; set; }
        [Required(ErrorMessage = "Enter Stock Reorder level!")]
        public float Reorder_Level { get; set; }
        public float Current_Stock { get; set; }
        public float Cost_per_Item { get; set; }
        public int Created_By { get; set; }
        public DateTime Date_of_Creation { get; set; }
    }

    public class m_Stock_Type
    {
        public int ID { get; set; }
        [Required(ErrorMessage = "Enter Stock Type!")]
        public string Stock_Type { get; set; }
        public int m_Status_ID { get; set; }
    }
    public class m_Stock_Unit
    {
        public int? ID { get; set; }
        [Required(ErrorMessage = "Enter Stock Unit!")]
        public string Unit { get; set; }
        public int? m_Status_ID { get; set; }
    }
    public class tbl_inventory
    {
        public int ID { get; set; }
        public int Item_ID { get; set; }
        public int tbl_Purchase_Order_ID { get; set; }
        public string Batch_No { get; set; }
        public string Serial_No { get; set; }
        public int Quantity { get; set; }
        public int SO_StockCount_ID { get; set; }
        public int Case_Status_ID { get; set; }
        public DateTime Last_Update { get; set; }
        public int Verified { get; set; }
    }
    public class tbl_missing_inventory
    {
        public int ID { get; set; }
        public int User_ID { get; set; }
        public int tbl_inventory_ID { get; set; }
        public int SO_StockCount_ID { get; set; }
        public int SO_StockCount_Item_DetailsID { get; set; }
        public int Case_Status_ID { get; set; }
        public float Actual_Quantity { get; set; }
        public float Reported_Quantity { get; set; }
        public string Remarks { get; set; }
        public string Action_Taken { get; set; }
        public DateTime Reported_on { get; set; }
    }
    public class view_missing_inventory
    {
        public int ID { get; set; }
        public string Stock_Name { get; set; }
        public string Customer_Name { get; set; }
        public string User_Assigned { get; set; }
        public int tbl_inventory_ID { get; set; }
        public int SO_StockCount_ID { get; set; }
        public string Item_Name { get; set; }
        public int Case_Status_ID { get; set; }
        public float System_Quantity { get; set; }
        public float Reported_Quantity { get; set; }
        public string Remarks { get; set; }
        public string Action_Taken { get; set; }
        public string Reported_on { get; set; }
    }
    public class Viewstock_details
    {
        public int? ID { get; set; }
        public string Item_No { get; set; }
        public string Item_Name { get; set; }
        public string Description { get; set; }
        public string Stock_type { get; set; }
        public string Stock_Unit { get; set; }
        public string Status { get; set; }
        public string Location { get; set; }
        public float Reorder_Level { get; set; }
        public float Current_Stock { get; set; }
        public string Created_By { get; set; }
        public string barcodeImage { get; set; }
        public DateTime Date_of_Creation { get; set; }
    }
    public class tbl_Stock_Count_Details
    {
        public int ID { get; set; }
        public string Stock_Name { get; set; }
        public int User_Assigned_ID { get; set; }
        public DateTime Date_of_Creation { get; set; }
        public string Remarks { get; set; }
        public int m_Status_ID { get; set; }
    }
    public class tbl_Stock_Count_Item_Details
    {
        public int ID { get; set; }
        public int tbl_Stock_Count_Details_ID { get; set; }
        public int Stock_Item_ID { get; set; }
        public DateTime Date_of_Creation { get; set; }
        public float? Quntity { get; set; }
        public string Batch_No { get; set; }
        public string Serial_No { get; set; }
        public string Scan_Value { get; set; }
    }
    public class View_Stock_Count_Details
    {
        public int ID { get; set; }
        public string Stock_Name { get; set; }
        public string User_Assigned { get; set; }
        public string Date_of_Creation { get; set; }
        public string Status { get; set; }
        public string Remarks { get; set; }
        public int Total_Item { get; set; }
        public List<Stock_Sheet_Items> Stock_Sheet_Items { get; set; }
    }
    public class Stock_Sheet_Items
    {
        public string Item_Name { get; set; }
        public float? Quntity { get; set; }
        public string Batch_No { get; set; }
        public string Serial_No { get; set; }
        public string Scan_Value { get; set; }
    }
    public class Vendor_Details
    {
        //  [Key]
        //[DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        public Int32? ID { get; set; }
        [Required(ErrorMessage="Enter Vender Name!")]
        public string Vendor_Name { get; set; }
        public string Website_link { get; set; }
        [Required(ErrorMessage = "Enter Contact Person Name!")]
        public string Contact_Person_Name { get; set; }
        [EmailAddress]
        [Required(ErrorMessage = "Enter Email ID!")]
        [Display(Name = "Email ID")]
        public string Email_ID { get; set; }
        [Required(ErrorMessage = "Enter Phone No.!")]
        [Display(Name="Phone No.")]
        public string Mobile { get; set; }
        public string Fax { get; set; }
        [Required(ErrorMessage = "Enter Mailing Address!")]
        public string Address { get; set; }
        [Required(ErrorMessage = "Select Country!")]
        public int m_Country_ID { get; set; }
        public string State { get; set; }
        public string City { get; set; }
        public string ZIP { get; set; }
        public int Created_By { get; set; }
        public DateTime Date_of_Creation { get; set; }
    }
    public class Vendor_Products
    {
        public Int32? ID { get; set; }
        public int Vendor_ID { get; set; }
        [Required(ErrorMessage = "Select Product Name!")]
        public int Product_ID { get; set; }
        public String Item_No { get; set; }
        public string Description { get; set; }
        [Required(ErrorMessage = "Enter Cost!")]
        public float Cost { get; set; }
        [Required(ErrorMessage = "Enter Lead Time!")]
        [Display(Name = "Lead Time")]
        public int Lead_Time { get; set; }
        public DateTime Date_of_Creation { get; set; }
    }
    public class ViewVendor_Products
    {
        public Int32? ID { get; set; }
        public int Vendor_ID { get; set; }
        public string Product_Name { get; set; }
        public string Item_No { get; set; }
        public string Description { get; set; }
        public float Cost { get; set; }
        public int Lead_Time { get; set; }
        public DateTime Date_of_Creation { get; set; }
    }
    public class ViewVendor_Details
    { 
        public Int32? ID { get; set; }
        
        public string Vendor_Name { get; set; }
        public string Website_link { get; set; }
        public string Contact_Person_Name { get; set; }
      
        public string Email_ID { get; set; }
      
        public string Mobile { get; set; }
        public string Fax { get; set; }
      
        public string Address { get; set; }

        public string Country { get; set; }
        public string State { get; set; }
        public string City { get; set; }
        public string ZIP { get; set; }
        public string Created_By { get; set; }
        public DateTime Date_of_Creation { get; set; }
    }
    public class Location_Details
    {
        public int? ID { get; set; }
        [Required(ErrorMessage="Enter Location")]
        public string Area { get; set; }
        public int Parent_ID { get; set; }
        public DateTime Date_of_Creation { get; set; }
    }
    public class ShowMessage
    {
        public int ID { get; set; }
        public string Message { get; set; }
    }
    public class Excel_Upload_Details
    {
        public int ID { get; set; }
        public string File_Name { get; set; }
        public int User_ID { get; set; }
        public int Total_Count { get; set; }
        public DateTime Uploaded_On { get; set; }
    }
    public class ShowDasboard
    {
        public int Employees { get; set; }
        public int Stocks { get; set; }
        public int Vendor { get; set; }
        public int Items { get; set; }
        public int Reorder_Level { get; set; }
    }

    public class Exception_History
    {
        public int id { get; set; }
        public int? user_id { get; set; }
        public string source_file { get; set; }
        public string page { get; set; }
        public string exception { get; set; }
        public DateTime exception_date { get; set; }
    }
    
   
    public class Master_Modification_History
    {
        public int ID { get; set; }
        public int? DB_ID { get; set; }
        public string Master_Type { get; set; }
        public int m_Master_Action_Type { get; set; }
        public string Current_Value { get; set; }
        public string New_Value { get; set; }
        public DateTime Change_Date { get; set; }
    }
    public class m_Master_Action
    {
        public int ID { get; set; }
        public string Action { get; set; }
    }
    public class MyProfile
    {
        public string ID { get; set; }
        [Required(ErrorMessage="Please Enter Name!")]
        public string Name { get; set; }
        public string Photo { get; set; }
    }
    public class m_Source
    {
        public int ID { get; set; }
        public string Source { get; set; }
    }
    public class Stock_History
    {
        public int ID { get; set; }
        public int Stock_ID { get; set; }
        public string Action { get; set; }
        public int UserID { get; set; }
        public int m_Source_ID { get; set; }
        public DateTime Date_of_Creation { get; set;}
    }
    public class Customer_Details
    {
        public int? ID { get; set; }
        public string name { get; set; }
        public string ContactPerson { get; set; }
        public string Phone_No { get; set; }
        public string Email_ID { get; set; }
        public string Address { get; set; }
        public int Is_Active { get; set; }
        public DateTime Created_On { get; set; }
    }
    public class tbl_Sales_Order_Status
    {
        public int ID { get; set; }
        public string Status { get; set; }
    }
    public class Sales_Order_Details
    {
        public int ID { get; set; }
        public int Customer_ID { get; set; }
        public DateTime DateOfOrder { get; set; }
        public DateTime ExpectedDateOfDelivery { get; set; }
        public string SalesOrderNo { get; set; }
        public int tbl_Sales_Order_Status_ID { get; set; }
        public int? Assigned_User_ID { get; set; }
        public DateTime? Actual_Delivery_Date { get; set; }
        public string Remarks { get; set; }
    }
    public class Sales_Order_Item_Details
    {
         public int sales_Order_Detail_ID { get; set; }
         public int ID { get; set; }
         public int  Item_ID { get; set; }
         public float Quantity { get; set; }
         public float Cost_Per_Item { get; set; }
         public string Batch_No { get; set; }
         public string Serial_No { get; set; }
         public string Scan_Value { get; set; }
         public float? Delivered_Quntity { get; set; }
    }
  
    public class ViewSales_Order_Detail
    {
        public int ID { get; set; }
        public string name { get; set; }
        public int Customer_ID { get; set; }
        public string DateOfOrder { get; set; }
        public string ExpectedDateOfDelivery { get; set; }
        public string SalesOrderNo { get; set; }
        public string Actual_Delivery_Date { get; set; }
        public string Status { get; set; }
        public int Phone_Status { get; set; }
        public string Assigned_User { get; set; }
        public string Remarks { get; set; }
        public int Total_Items { get; set; }
        public List<View_SalesOrder_Item> View_SalesOrder_Item { get; set; }
    }
    public class View_SalesOrder_Item
    {
        public int ID { get; set; }
        public int Item_ID { get; set; }
        public string Item_Name { get; set; }
        public float Quantity { get; set; }
        public float Cost_Per_Item { get; set; }
        public int SO_ID { get; set; }
        public string Batch_No { get; set; }
        public string Serial_No { get; set; }
        public string Scan_Value { get; set; }
        public string Delivered_Quntity { get; set; }
    }
    public class Vender_Details
    {
        public int ID { get; set; }
        public string Vender_Name { get; set; }
        public string Website_Link { get; set; }
        public string Contact_Person_Name { get; set; }
        public string Email_ID { get; set; }
        public string Mobile { get; set; }
        public int Fax { get; set; }
        public DateTime Address { get; set; }
        public string m_Country_ID { get; set; }
        public string State { get; set; }
        public string City { get; set; }
        public string ZIP { get; set; }
        public int Created_By { get; set; }
        public DateTime Date_Of_Creation { get; set; }
    }
    public class Vender_Product
    {
        public int ID { get; set; }
        public int Vendor_ID { get; set; }
        public int Product_ID { get; set; }
    }
   
    public class tbl_Purchase_Order_Status
    {
        public int ID { get; set; }
        public string Status { get; set; }
    }
    public class PurchaseOrder_Details
    {
        public int ID { get; set; }
        public int Vender_ID { get; set; }
        public DateTime Expected_Received_Date { get; set; }
        public DateTime DateOfPurchase { get; set; }
        public string Purchase_Order_Number { get; set; }
        public float tbl_Purchase_Order_Status_ID { get; set; }
        public float CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime? Actual_Received_Date { get; set; }
        public int? Assigned_User_ID { get; set; }
        public string Remarks { get; set; }
    }
    public class purchase_order_item_details
    {
        public int ID { get; set; }
        public int Created_By { get; set; }
        public int Purchase_Order_Details_ID { get; set; }
        public int Item_ID { get; set; }
        public float Quantity { get; set; }
        public float Cost_Per_Item { get; set; }
        public DateTime Created_On { get; set; }
        public string Batch_No { get; set; }
        public string Serial_No { get; set; }
        public string Scan_Value { get; set; }
        public float? Rcd_Quntity { get; set; }
    }
    public class View_PurchaseOrder_Details
    {
        public int ID { get; set; }
        public int Vendor_ID { get; set; }
        public string Vendor_Name { get; set; }
        public string Purchase_Order_Number { get; set; }
        public string DateOfPurchase { get; set; }
        public string Expected_Received_Date { get; set; }
        public string Actual_Received_Date { get; set; }
        public string Assigned_User { get; set; }
        public string Status { get; set; }
        public int Phone_Status { get; set; }
        public string Remarks { get; set; }
        public int Total_Items { get; set; }
        public List<View_PurchaseOrder_Item> View_PurchaseOrder_Item { get; set;}
    }
    public class View_PurchaseOrder_Item
    {
        public int ID { get; set; }
        public int Item_ID { get; set; }
        public string Item_Name { get; set; }
        public int Vender_ID { get; set; }
        public int PO_ID { get; set; }
        public float Quantity { get; set; }
        public float Cost_Per_Item { get; set; }
        public string Batch_No { get; set; }
        public string Serial_No { get; set; }
        public string Scan_Value { get; set; }
        public string Rcd_Quntity { get; set; }
    }
    public class m_Report_Color
    {
        public int ID { get; set; }
        [Required(ErrorMessage = "Enter Header Text Color !")]
        public string HeaderRow_ForColor { get; set; }
        [Required(ErrorMessage = "Enter Header Background Color !")]
        public string HeaderRow_BackColor { get; set; }
        [Required(ErrorMessage = "Enter Alternate Row Background Color !")]
        public string RowStyle_BackColor { get; set; }
        public int m_Status_ID { get; set; }
        public DateTime Date_of_Creation { get; set; }
    }
    //API Class Start
    public class GetStockWithLocation
    {
        public List<stock_details> stock{get;set;}
        public List<Location_Details> location { get; set; }
    }
    public class StockCountDetails
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public int Status { get; set; }
        public int Phone_Status { get; set; }
        public string Remarks { get; set; }
        public List<Items> Items { get; set; }
    }
    public class Items
    {
        public int? ID { get; set; }
        public int Item_ID { get; set; }
        public string Item_Name { get; set; }
        public string Item_No { get; set; }
        public int Stock_ID { get; set; }
        public string Quntity { get; set; }
        public string Batch_No { get; set; }
        public string Serial_No { get; set; }
        public string Scan_Value { get; set; }
    }
    public class RetPOMessage
    {
        public int PO_ID { get; set; }
        public string PO_Number { get; set; }
        public bool Status { get; set; }
        public string Message { get; set; }
    }
    public class RetSOMessage
    {
        public int SO_ID { get; set; }
        public string SO_Number { get; set; }
        public bool Status { get; set; }
        public string Message { get; set; }
    }
    public class RetStokCountMessage
    {
        public int Stok_Count_ID { get; set; }
        public string Sheet_Name { get; set; }
        public bool Status { get; set; }
        public string Message { get; set; }
    }
    //API Class End
}