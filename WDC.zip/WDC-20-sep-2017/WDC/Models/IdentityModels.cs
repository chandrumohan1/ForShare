﻿using System.Data.Entity;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using System.ComponentModel.DataAnnotations.Schema;

namespace WDC.Models
{
    // You can add profile data for the user by adding more properties to your ApplicationUser class, please visit http://go.microsoft.com/fwlink/?LinkID=317594 to learn more.


    public class ApplicationUser : IdentityUser
    {
        public async Task<ClaimsIdentity> GenerateUserIdentityAsync(UserManager<ApplicationUser> manager)
        {
            // Note the authenticationType must match the one defined in CookieAuthenticationOptions.AuthenticationType
            var userIdentity = await manager.CreateIdentityAsync(this, DefaultAuthenticationTypes.ApplicationCookie);
            // Add custom user claims here
            return userIdentity;
        }
        public string Password { get; set; }
        public string Photo { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
        public int? Is_for_Mobile_Device { get; set; }
        public int? Is_Active { get; set; }
    }   
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext()
            : base("DefaultConnection", throwIfV1Schema: false)
        {
           
        }
        public DbSet<m_Email_Setting> m_Email_Setting { get; set; }
        public DbSet<m_barcode_setting> m_barcode_setting { get; set; }
        public DbSet<m_Report_Color> m_Report_Color { get; set; }
        public DbSet<m_Stock_Type> m_Stock_Type{get;set;}
        public DbSet<m_Stock_Unit> m_Stock_Unit { get; set; }
        public DbSet<stock_details> stock_details { get; set; }
        public DbSet<tbl_Country> tbl_Country { get; set; }
        public DbSet<Vendor_Details> Vendor_Details { get; set; }
        public DbSet<Vendor_Products> Vendor_Products { get; set; }
        public DbSet<m_stock_status> m_stock_status { get; set; }
        public DbSet<Excel_Upload_Details> Excel_Upload_Details { get; set; }
        public DbSet<Exception_History> Exception_History { get; set; }
        public DbSet<Master_Modification_History> Master_Modification_History { get; set; }
        public DbSet<m_Master_Action> m_Master_Action { get; set; }
        public DbSet<Location_Details> Location_Details { get; set; }
        public DbSet<Stock_History> Stock_History { get; set; }
        //public DbSet<test1> test1 { get; set; }
        public DbSet<Customer_Details> Customer_Details { get; set; }
        public DbSet<PurchaseOrder_Details> PurchaseOrder_Details { get; set; }
        public DbSet<purchase_order_item_details> purchase_order_item_details { get; set; }
        public DbSet<Sales_Order_Item_Details> Sales_Order_Item_Details { get; set; }
        public DbSet<Sales_Order_Details> Sales_Order_Details { get; set; }
        public DbSet<tbl_Purchase_Order_Status> tbl_Purchase_Order_Status { get; set; }
        public DbSet<tbl_Sales_Order_Status> tbl_Sales_Order_Status { get; set; }
        public DbSet<tbl_Stock_Count_Details> tbl_Stock_Count_Details { get; set; }
        public DbSet<tbl_Stock_Count_Item_Details> tbl_Stock_Count_Item_Details { get; set; }
        public DbSet<tbl_inventory> tbl_inventory { get; set; }
        public DbSet<tbl_missing_inventory> tbl_missing_inventory { get; set; }

        public static ApplicationDbContext Create()
        {
            return new ApplicationDbContext();
        }
    }
}